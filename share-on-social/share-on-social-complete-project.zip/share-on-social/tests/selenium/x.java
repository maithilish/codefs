package com.example.tests;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class X {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "http://localhost/";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testX() throws Exception {
    driver.get(baseUrl + "/basic-locker-test/");
    // ERROR: Caught exception [ERROR: Unsupported command [waitForPopUp | _blank | 30000]]
    driver.findElement(By.id("Email")).clear();
    driver.findElement(By.id("Email")).sendKeys("maithidev");
    driver.findElement(By.id("Passwd")).clear();
    driver.findElement(By.id("Passwd")).sendKeys("oops@300");
    driver.findElement(By.id("signIn")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectFrame | oauth2relay1963087859 | ]]
    // ERROR: Caught exception [ERROR: Unsupported command [waitForPopUp | pmh2067040507 | 30000]]
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | name=I1_1417003264529 | ]]
    driver.findElement(By.xpath("//div[@id='shareboxPlaceholderDiv']/div[2]/div/div[2]/table/tbody/tr/td/div")).click();
    // ERROR: Caught exception [ERROR: Unsupported command [selectWindow | null | ]]
    assertEquals("basic locker test sample text", driver.findElement(By.id("test-sos-content-13")).getText());
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
