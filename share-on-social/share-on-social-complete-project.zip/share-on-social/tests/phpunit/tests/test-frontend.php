<?php

class Test_Frontend extends WP_UnitTestCase {

    var $frontend;

    var $parent_post_id;

    var $child_post_id;

    var $sos;

    public function setUp () {
        parent::setUp();
        
        global $post;
        
        require_once ('admin/class-sos.php');
        $this->sos = new Sos();
        Util::set_activate_plugins_cap( true );
        $this->sos->create_basic_locker();
        Util::set_activate_plugins_cap( false );
        
        // create frontend - don't call setup()
        $this->frontend = new Sos_Frontend();
        
        // add global options and create test pages - parent and child
        $options = array(
                'gplusclientid' => 'test_gplusclientid',
                'fbappid' => 'test_fbappid'
        );
        add_option( 'sos_common_options', $options );
        $this->create_posts();
        
        // set global $post to child page
        $post = get_post( $this->child_post_id );
        setup_postdata( $post );
        
        remove_shortcode( $this->frontend->sos_shortcode ); // just a clean up
                                                            
        // require extra test shortcode to test do_shortcode in
                                                            // enable_sos_shortcode()
        add_shortcode( 'test-shortcode', 
                array(
                        $this,
                        'enable_test_shortcode'
                ) );
        
        $user_id = $this->add_user( 'testuser1' );
        wp_set_current_user( $user_id );
    }

    public function teardown () {
        parent::teardown();
        unload_textdomain( 'sos-domain' );
        
        wp_deregister_script( 'sos_script' );
        wp_deregister_script( 'sos_script_fb' );
        wp_deregister_script( 'sos_script_gplus' );
        
        Util::set_activate_plugins_cap( false );
    }

    public function test_sos_setup () {
        // before setup
        $this->assertFalse( 
                Util::has_action( 'wp_enqueue_scripts', $this->frontend, 
                        'add_sos_scripts' ) );
        $this->assertFalse( shortcode_exists( $this->frontend->sos_shortcode ) );
        
        // tests after setup
        $this->frontend->setup();
        
        $this->assertTrue( 
                Util::has_action( 'wp_enqueue_scripts', $this->frontend, 
                        'add_sos_scripts' ) );
        $this->assertTrue( shortcode_exists( $this->frontend->sos_shortcode ) );
    }

    public function test_add_sos_scripts () {
        // if no shortcode test for register
        $this->frontend->add_sos_scripts();
        
        $this->assertTrue( wp_style_is( 'sos_style', 'registered' ) );
        $this->assertTrue( wp_script_is( 'sos_script', 'registered' ) );
        
        $this->assertFalse( wp_style_is( 'sos_style', 'enqueued' ) );
        $this->assertFalse( wp_script_is( 'sos_script', 'enqueued' ) );
        $this->assertFalse( wp_script_is( 'sos_script_fb', 'enqueued' ) );
        $this->assertFalse( wp_script_is( 'sos_script_gplus', 'enqueued' ) );
        
        // if shortcode exists then test for register and enqueue
        $this->frontend->setup();
        $this->frontend->add_sos_scripts();
        
        $this->assertTrue( wp_style_is( 'sos_style', 'enqueued' ) );
        $this->assertTrue( wp_script_is( 'sos_script', 'enqueued' ) );
        $this->assertTrue( wp_script_is( 'sos_script_fb', 'enqueued' ) );
        $this->assertTrue( wp_script_is( 'sos_script_gplus', 'enqueued' ) );
    }

    public function test_localized_script () {
        global $wp_scripts;
        
        // no shortcode
        $this->frontend->add_sos_scripts();
        
        $data = $wp_scripts->get_data( 'sos_script', 'data' );
        $data = substr( $data, strpos( $data, '{' ) - 1, 
                strpos( $data, '}' ) + 1 );
        $sos_data = json_decode( $data, true );
        $this->assertNull( $sos_data );
        
        // add shortcode and test localized
        $this->frontend->setup();
        $this->frontend->add_sos_scripts();
        
        $data = $wp_scripts->get_data( 'sos_script', 'data' );
        $data = substr( $data, strpos( $data, '{' ) - 1, 
                strpos( $data, '}' ) + 1 );
        $sos_data = json_decode( $data, true );
        $this->assertCount( 3, $sos_data );
        
        $this->assertarrayHasKey( 'ajax_url', $sos_data );
        $this->assertarrayHasKey( 'nonce', $sos_data );
        $this->assertarrayHasKey( 'gplus_client_id', $sos_data );
        $this->assertSame( $sos_data[ 'ajax_url' ], 
                'http://localhost/wp-admin/admin-ajax.php' );
        
        // wp_verify_nonce returns 1 or 2 when valid else false
        $this->assertSame( 1, 
                wp_verify_nonce( $sos_data[ 'nonce' ], 'sos-save-stat' ) );
        
        $this->assertSame( $sos_data[ 'gplus_client_id' ], 
                'test_gplusclientid' );
    }

    public function test_fb_sdk_url () {
        global $wp_scripts;
        
        // shortcode not exists
        $this->frontend->add_sos_scripts();
        $this->assertFalse( 
                isset( $wp_scripts->registered[ 'sos_script_fb' ] ) );
        
        // add shortcode and test sdk url
        $this->frontend->setup();
        $this->frontend->add_sos_scripts();
        
        $url = $wp_scripts->registered[ 'sos_script_fb' ]->src;
        $this->assertSame( $url, 
                'http://connect.facebook.net/en_US/all.js#xfbml=1&appId=test_fbappid&version=v2.0' );
    }

    public function test_gplus_sdk_url () {
        global $wp_scripts;
        
        // shortcode not exists
        $this->frontend->add_sos_scripts();
        $this->assertFalse( 
                isset( $wp_scripts->registered[ 'sos_script_gplus' ] ) );
        
        // add shortcode and test sdk url
        $this->frontend->setup();
        $this->frontend->add_sos_scripts();
        
        $url = $wp_scripts->registered[ 'sos_script_gplus' ]->src;
        $this->assertSame( $url, 'https://apis.google.com/js/plusone.js' );
    }

    public function test_sanitize_share_props () {
        $share_props = $this->frontend->sanitize_share_props( "test name", 
                "http://example.org", 0 );
        
        $this->assertarrayHasKey( 'share_name', $share_props );
        $this->assertarrayHasKey( 'share_target', $share_props );
        $this->assertarrayHasKey( 'share_target_id', $share_props );
        
        $this->assertSame( 0, $share_props[ 'share_target_id' ] );
        
        // test share name sanitize
        $this->assertSame( 'testname', $share_props[ 'share_name' ] );
        $share_props = $this->frontend->sanitize_share_props( 
                "test <?php echo ?>", "http://example.org", 0 );
        $this->assertSame( 'testphpecho', $share_props[ 'share_name' ] );
        
        // test url sanitize
        $share_props = $this->frontend->sanitize_share_props( "test", 
                "http://example.org", 0 );
        $this->assertSame( 'http://example.org', 
                $share_props[ 'share_target' ] );
        $share_props = $this->frontend->sanitize_share_props( "test", 
                "https://example.org", 0 );
        $this->assertSame( 'https://example.org', 
                $share_props[ 'share_target' ] );
        $share_props = $this->frontend->sanitize_share_props( "test", 
                "ftp://example.org", 0 );
        $this->assertSame( '', $share_props[ 'share_target' ] ); // ftp not
                                                                     // allowed
    }

    public function test_get_share_target_id () {
        global $post;
        
        $result = $this->frontend->get_share_target_id( 'page' );
        $this->assertSame( $this->child_post_id, $result );
        
        $result = $this->frontend->get_share_target_id( 'site' );
        $this->assertSame( 0, $result );
        
        $result = $this->frontend->get_share_target_id( 'parent' );
        $this->assertSame( $this->parent_post_id, $result );
        
        $post = get_post( $this->parent_post_id ); // parent of top level is
                                                   // site
        $result = $this->frontend->get_share_target_id( 'parent' );
        $this->assertSame( 0, $result );
        
        $post = get_post( 0 );
        $result = $this->frontend->get_share_target_id( 'parent' );
        $this->assertSame( 0, $result );
        
        $post = get_post( $this->child_post_id ); // reset
    }

    public function test_get_share_props_target_page () {
        $locker_id = 'basic';
        $basic_locker_post_id = Util::get_post_id( 'sos', 'locker_id', 
                $locker_id );
        update_post_meta( $basic_locker_post_id, 'share_target', 'page' );
        
        $share_props = $this->frontend->get_share_props( $locker_id, '', '' );
        $this->assertCount( 3, $share_props );
        $this->assertSame( 'child-test-page', $share_props[ 'share_name' ] );
        $this->assertSame( 'http://localhost/?page_id=' . $this->child_post_id, 
                $share_props[ 'share_target' ] );
        $this->assertSame( $this->child_post_id, 
                $share_props[ 'share_target_id' ] );
    }

    public function test_get_share_props_target_parent () {
        $locker_id = 'basic';
        $basic_locker_post_id = Util::get_post_id( 'sos', 'locker_id', 
                $locker_id );
        update_post_meta( $basic_locker_post_id, 'share_target', 'parent' );
        
        $share_props = $this->frontend->get_share_props( $locker_id, '', '' );
        $this->assertCount( 3, $share_props );
        $this->assertSame( 'child-test-page', $share_props[ 'share_name' ] );
        $this->assertSame( 
                'http://localhost/?page_id=' . $this->parent_post_id, 
                $share_props[ 'share_target' ] );
        $this->assertSame( $this->parent_post_id, 
                $share_props[ 'share_target_id' ] );
    }

    public function test_get_share_props_target_site () {
        $locker_id = 'basic';
        $basic_locker_post_id = Util::get_post_id( 'sos', 'locker_id', 
                $locker_id );
        update_post_meta( $basic_locker_post_id, 'share_target', 'site' );
        
        $share_props = $this->frontend->get_share_props( $locker_id, '', '' );
        $this->assertCount( 3, $share_props );
        $this->assertSame( 'child-test-page', $share_props[ 'share_name' ] );
        $this->assertSame( 'http://localhost', $share_props[ 'share_target' ] );
        $this->assertSame( 0, $share_props[ 'share_target_id' ] );
    }

    public function test_get_share_props_target_page_userdefined () {
        $locker_id = 'basic';
        $basic_locker_post_id = Util::get_post_id( 'sos', 'locker_id', 
                $locker_id );
        update_post_meta( $basic_locker_post_id, 'share_target', 'page' );
        
        $share_props = $this->frontend->get_share_props( $locker_id, 
                'test-share-name', 'http://codedrops.in/' );
        $this->assertCount( 3, $share_props );
        $this->assertSame( 'test-share-name', $share_props[ 'share_name' ] );
        $this->assertSame( 'http://codedrops.in/', 
                $share_props[ 'share_target' ] );
        $this->assertSame( 'na', $share_props[ 'share_target_id' ] );
    }

    public function test_get_share_props_target_parent_userdefined () {
        $locker_id = 'basic';
        $basic_locker_post_id = Util::get_post_id( 'sos', 'locker_id', 
                $locker_id );
        update_post_meta( $basic_locker_post_id, 'share_target', 'parent' );
        
        $share_props = $this->frontend->get_share_props( $locker_id, 
                'test-share-name', 'http://codedrops.in/' );
        $this->assertCount( 3, $share_props );
        $this->assertSame( 'test-share-name', $share_props[ 'share_name' ] );
        $this->assertSame( 'http://codedrops.in/', 
                $share_props[ 'share_target' ] );
        $this->assertSame( 'na', $share_props[ 'share_target_id' ] );
    }

    public function test_get_share_props_target_site_userdefined () {
        $locker_id = 'basic';
        $basic_locker_post_id = Util::get_post_id( 'sos', 'locker_id', 
                $locker_id );
        update_post_meta( $basic_locker_post_id, 'share_target', 'site' );
        
        $share_props = $this->frontend->get_share_props( $locker_id, 
                'test-share-name', 'http://codedrops.in/' );
        $this->assertCount( 3, $share_props );
        $this->assertSame( 'test-share-name', $share_props[ 'share_name' ] );
        $this->assertSame( 'http://codedrops.in/', 
                $share_props[ 'share_target' ] );
        $this->assertSame( 'na', $share_props[ 'share_target_id' ] );
    }

    public function test_get_locker () {
        $locker_id = 'basic';
        $locker = $this->frontend->get_locker( $locker_id );
        
        $this->assertSame( 6, count( $locker ) );
        $this->assertarrayHasKey( 'locker_id', $locker );
        $this->assertarrayHasKey( 'share_target', $locker );
        $this->assertarrayHasKey( 'locker_text', $locker );
        $this->assertarrayHasKey( 'shareon_fb', $locker );
        $this->assertarrayHasKey( 'shareon_gplus', $locker );
        $this->assertarrayHasKey( 'shareon_twitter', $locker );
        
        $this->assertSame( 'basic', $locker[ 'locker_id' ] );
        $this->assertSame( 'page', $locker[ 'share_target' ] );
        $this->assertSame( '1', $locker[ 'shareon_fb' ] );
        $this->assertSame( '1', $locker[ 'shareon_gplus' ] );
        $this->assertSame( '1', $locker[ 'shareon_twitter' ] );
        $this->assertTrue( is_string( $locker[ 'locker_text' ] ) );
    }

    public function test_get_meta_data () {
        $locker_id = 'basic';
        $result = $this->frontend->get_meta_data( $locker_id, 'share_target' );
        $this->assertSame( 'page', $result );
        
        $result = $this->frontend->get_meta_data( $locker_id, 'locker_id' );
        $this->assertSame( 'basic', $result );
        
        $locker_id = 'unknown';
        $result = $this->frontend->get_meta_data( $locker_id, 'share_target' );
        $this->assertSame( '', $result );
    }

    public function test_get_share_button_no_appid () {
        $enabled = 1;
        $appid_set = false;
        
        $shareon = 'fb';
        $share_name = 'test';
        $icon = 'test.jpg';
        $prefix = 10;
        
        $expected = "";
        $result = $this->frontend->get_share_button( $shareon, $share_name, 
                $icon, $enabled, $appid_set, $prefix );
        $this->assertSame( $expected, $result );
    }

    public function test_get_share_button_not_enabled () {
        $enabled = 0;
        $appid_set = true;
        
        $shareon = 'fb';
        $share_name = 'test';
        $icon = 'test.jpg';
        $prefix = 10;
        
        $expected = "";
        $result = $this->frontend->get_share_button( $shareon, $share_name, 
                $icon, $enabled, $appid_set, $prefix );
        $this->assertSame( $expected, $result );
    }

    public function test_get_share_button_fb () {
        $enabled = 1;
        $appid_set = true;
        
        $shareon = 'fb';
        $share_name = 'test';
        $icon = 'test.jpg';
        $prefix = 10;
        
        $expected = <<< EOD
<span id="fb_10-test" class="share-locker fb-test">
    <img src="test.jpg" style="display: inline-block;" >
</span>
EOD;
        $result = $this->frontend->get_share_button( $shareon, $share_name, 
                $icon, $enabled, $appid_set, $prefix );
        $this->assertSame( trim( $expected ), trim( $result ) );
    }

    public function test_get_share_button_gplus () {
        $enabled = 1;
        $appid_set = true;
        
        $shareon = 'gplus';
        $share_name = 'test';
        $icon = 'test.jpg';
        $prefix = 10;
        
        $expected = <<< EOD
<span id="gplus_10-test" class="share-locker gplus-test">
    <img src="test.jpg" style="display: inline-block;" >
</span>
EOD;
        $result = $this->frontend->get_share_button( $shareon, $share_name, 
                $icon, $enabled, $appid_set, $prefix );
        $this->assertSame( trim( $expected ), trim( $result ) );
    }

    public function test_get_share_button_twitter () {
        $enabled = 1;
        $appid_set = true;
        
        $shareon = 'twitter';
        $share_name = 'test';
        $icon = null;
        $prefix = 10;
        
        $expected = <<< EOD
<span id="twitter_10-test" class="share-locker twitter-test">
    
</span>
EOD;
        $result = $this->frontend->get_share_button( $shareon, $share_name, 
                $icon, $enabled, $appid_set, $prefix );
        $this->assertSame( trim( $expected ), trim( $result ) );
    }

    public function test_get_share_span () {
        $share_name = 'test';
        $icon = 'test.jpg';
        $prefix = 30;
        $type = 'fb';
        $share_button = $this->frontend->get_share_span( $share_name, $icon, 
                $prefix, $type );
        $expected = <<<EOD
<span id="fb_30-test" class="share-locker fb-test">
    <img src="test.jpg" style="display: inline-block;" >
</span>
EOD;
        $this->assertSame( trim( $expected ), trim( $share_button ) );
    }

    public function test_construct_share_lockers_html () {
        $locker_id = 'basic';
        $basic_locker_post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        update_post_meta( $basic_locker_post_id, 'share_target', 'site' );
        
        $locker = $this->frontend->get_locker( $locker_id );
        $share_props = $this->frontend->get_share_props( $locker_id, '', '' );
        $share_locker = $this->frontend->construct_share_lockers_html( $locker, 
                $share_props );
        $page_name = 'child-test-page';
        $expected = $this->expected_share_locker( $page_name );
        // echo trim($share_locker);
        $this->assertSame( trim( $expected ), trim( $share_locker ) );
    }

    public function test_get_locked_content () {
        $locked_content = $this->frontend->get_locked_content( 
                'test-share-name', 'test-content', 'test-locker' );
        $expected = <<<EOD
        <div id="test-share-name-sos-content-test-prefix"
             class="sos-hide test-share-name-sos-content" >
            test-content
        </div>
        <div id="test-share-name-sos-locker-test-prefix"
             class="test-share-name-sos-locker" >
            test-locker
        </div>
EOD;
        // echo $locked_content;
        $this->assertSame( trim( $expected ), trim( $locked_content ) );
    }

    public function test_enable_sos_shortcode () {
        $atts = array(
                'name' => 'sos-site',
                'link' => 'http://localhost'
        );
        // shortcode func converts (by do_shortcode() method) test content.
        // [test-shortcode]contents of test-shortcode[test-shortcode] as test
        // content. contents of test-shortcode
        $content = 'test content. [test-shortcode]contents of test-shortcode[test-shortcode]';
        $locker_id = 'basic';
        
        $basic_locker_post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        update_post_meta( $basic_locker_post_id, 'share_target', 'site' );
        
        $page_name = 'sos-site';
        $share_locker = $this->expected_share_locker( $page_name );
        
        $expected = <<<EOD
        <div id="{$page_name}-sos-content-test-prefix"
             class="sos-hide {$page_name}-sos-content" >
            test content. contents of test-shortcode
        </div>
        <div id="{$page_name}-sos-locker-test-prefix"
             class="{$page_name}-sos-locker" >
            $share_locker
        </div>         
EOD;
        
        $locked_content = $this->frontend->enable_sos_shortcode( $atts, 
                $content );
        $this->assertSame( trim( $expected ), trim( $locked_content ) );
    }

    public function test_enable_sos_shortcode_no_atts () {
        $atts = array();
        
        $content = 'test content. [test-shortcode]contents of test-shortcode[test-shortcode]';
        $locker_id = 'basic';
        
        $basic_locker_post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        
        $page_name = 'child-test-page';
        $share_locker = $this->expected_share_locker( $page_name, 
                'http://localhost/?page_id=' . $this->child_post_id );
        
        $expected = <<<EOD
        <div id="{$page_name}-sos-content-test-prefix"
             class="sos-hide {$page_name}-sos-content" >
            test content. contents of test-shortcode
        </div>
        <div id="{$page_name}-sos-locker-test-prefix"
             class="{$page_name}-sos-locker" >
            $share_locker
        </div>
EOD;
        
        $locked_content = $this->frontend->enable_sos_shortcode( $atts, 
                $content );
        $this->assertSame( trim( $expected ), trim( $locked_content ) );
    }

    public function test_dev_mode () {
        $GLOBALS[ 'wp_tests_options' ][ 'sos_test' ] = false;
        
        ob_start();
        $this->frontend->setup();
        $this->frontend->add_sos_scripts();
        $result = ob_get_contents();
        ob_end_clean();
        
        $this->assertTrue( defined( 'DONOTCACHEPAGE' ) );
        $this->assertNotFalse( 
                strpos( $result, 
                        'SOS Dev DEBUG : [ page cache :disabled] [ random' ) );
        
        $GLOBALS[ 'wp_tests_options' ][ 'sos_test' ] = true;
    }

    public function test_collect_debug_data () {
        global $sos_debug_data, $post;
        $id = 'test-id';
        $name = 'test-name';
        $link = 'test-link';
        $post = get_post( $this->child_post_id );
        $share_props = array(
                'test-key' => 'test-value'
        );
        $locker = array(
                'locker_id' => 'test-locker'
        );
        $this->frontend->collect_debug_data( $id, $name, $link, $post, 
                $share_props, $locker );
        $this->assertSame( 0, count( $sos_debug_data ) );
        
        // now enable debug
        $options = get_option( 'sos_common_options' );
        $options[ 'sos_debug' ] = true;
        update_option( 'sos_common_options', $options );
        $this->frontend->collect_debug_data( $id, $name, $link, $post, 
                $share_props, $locker );
        
        $this->assertSame( 1, count( $sos_debug_data ) );
        $this->assertSame( 4, count( $sos_debug_data[ 0 ] ) );
        
        $this->assertSame( $id, 
                $sos_debug_data[ 0 ][ 'user defined' ][ 'locker id' ] );
        $this->assertSame( $name, 
                $sos_debug_data[ 0 ][ 'user defined' ][ 'name' ] );
        $this->assertSame( $link, 
                $sos_debug_data[ 0 ][ 'user defined' ][ 'link' ] );
        $this->assertSame( $share_props, 
                $sos_debug_data[ 0 ][ 'share attributes' ] );
        $this->assertSame( $locker, $sos_debug_data[ 0 ][ 'locker' ] );
        
        $post_props = array(
                'id' => $this->child_post_id,
                'name' => 'child-test-page',
                'type' => 'page',
                'permalink' => 'http://localhost/?page_id=' .
                         $this->child_post_id,
                        'parent' => $this->parent_post_id
        );
        $this->assertSame( $post_props, 
                $sos_debug_data[ 0 ][ 'post attributes' ] );
    }

    private function expected_share_locker ( $page_name, 
            $page_url = 'http://localhost', $prefix = '' ) {
        ($prefix == '') ? $prefix : $prefix .= ' ';
        $text1 = $prefix . 'Content is Locked';
        $text2 = $prefix . 'Share to unlock the content';
        $expected = <<<EOD
<div>&nbsp;
<p style="text-align: center;"><strong>
<span style="font-size: 16pt; color: #993300; font-family: impact,chicago;">
{$text1} !</span></strong></p>
&nbsp;
<p style="text-align: center;">
<span style="font-size: 14pt; color: #993300; font-family: impact,chicago;">
{$text2}.</span></p>
&nbsp;</div>
<div id="fb-root"></div>                	
<div class="share-lockers">
    <span id="fb_test-prefix-{$page_name}" class="share-locker fb-{$page_name}">
    <img src="http://localhost/wp-content/plugins/share-on-social//images/fb-48.png" style="display: inline-block;" >
</span>
    <span class="spacer"></span>
    <span id="gplus_test-prefix-{$page_name}" class="share-locker gplus-{$page_name}">
    <img src="http://localhost/wp-content/plugins/share-on-social//images/gplus-48.png" style="display: inline-block;" >
</span>
    <span class="spacer"></span>
    <span id="twitter_test-prefix-{$page_name}" class="share-locker twitter-{$page_name}">
    
</span>
</div>
<div class="clear"></div>        
<input type="hidden" class="share_name" value="{$page_name}">
<input type="hidden" id="{$page_name}_test-prefix_share_target" 
                        value="{$page_url}">
EOD;
        return $expected;
    }

    private function create_posts () {
        $args = array(
                'post_name' => 'parent test page',
                'post_title' => 'parent test page title',
                'post_status' => 'publish',
                'post_type' => 'page',
                'post_content' => '[share-on-social][/share-on-social]'
        );
        $post_id = $this->factory->post->create( $args );
        $this->parent_post_id = $post_id;
        
        $args = array(
                'post_name' => 'child test page',
                'post_title' => 'child test page title',
                'post_status' => 'publish',
                'post_type' => 'page',
                'post_parent' => $this->parent_post_id,
                'post_content' => '[share-on-social]test-content[/share-on-social]'
        );
        $post_id = $this->factory->post->create( $args );
        $this->child_post_id = $post_id;
    }
    
    // add_shortcode function hence public
    public function enable_test_shortcode ( $atts, $content ) {
        return do_shortcode( $content );
    }

    private function add_user ( $login_name ) {
        $userdata = array(
                'user_login' => $login_name,
                'user_url' => 'localhost',
                'user_pass' => NULL
        );
        return $this->factory->user->create_object( $userdata );
    }
}