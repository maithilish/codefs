<?php

class Test_Sos_Uninstall_Multisite extends WP_UnitTestCase {

    var $user_id;

    var $activator;

    var $sos;

    var $domain = 'localhost';

    public function setup () {
        parent::setup();

        define( 'WP_UNINSTALL_PLUGIN', true );

        require_once 'uninstall.php';

        require_once 'admin/class-activator.php';
        $this->activator = new Sos_Activator();

        require_once 'admin/class-sos.php';
        $this->sos = new Sos();

        // add one more site(blog) to the site
        $this->add_blog( 'test1', 'Test 1' );

        $networkwide = true;

        // can't remove super admin status from default user so create new user
        $this->user_id = $this->add_user( 'testuser' );
        wp_set_current_user( $this->user_id );
        Util::set_admin_role( true );

        // grant super admin and activate to add options
        grant_super_admin( $this->user_id );
        $this->activator->activate( $networkwide );

        // sites
        $sites = get_sites();
        $this->assertCount( 2, $sites );
        $site1 = (array) $sites[ 0 ];
        $site2 = (array) $sites[ 1 ];

        switch_to_blog( $site1[ 'blog_id' ] );
        // create locker and also add extra sos post to test delete sos posts
        $this->sos->create_post_type();
        $this->add_post( 'sos' );
        // add other options
        add_option( 'sos_stats', array() );
        add_option( 'sos_stats_summary', array() );
        add_option( 'sos_common_options', array() );
        restore_current_blog();

        switch_to_blog( $site2[ 'blog_id' ] );
        $this->sos->create_post_type();
        add_option( 'sos_stats', array() );
        add_option( 'sos_stats_summary', array() );
        add_option( 'sos_common_options', array() );
        restore_current_blog();
    }

    public function teardown () {
        parent::teardown();
        unload_textdomain( 'sos-domain' );

        // sites
        $sites = get_sites();
        if( 1 == count($sites)){
            $site = (array) $sites[ 0 ];
            switch_to_blog( $site[ 'blog_id' ] );
            delete_option( 'sos_stats' );
            delete_option( 'sos_stats_summary' );
            delete_option( 'sos_common_options' );
            restore_current_blog();
        }

        if( 2 == count($sites)){
            $site = (array) $sites[ 1 ];
            switch_to_blog( $site[ 'blog_id' ] );
            delete_option( 'sos_stats' );
            delete_option( 'sos_stats_summary' );
            delete_option( 'sos_common_options' );
            restore_current_blog();
        }
    }

    public function test_sos_uninstall_sos_plugin_multisite_by_non_superadmin () {
        // sites
        $sites = get_sites();
        $this->assertCount( 2, $sites );
        $site1 = (array) $sites[ 0 ];
        $site2 = (array) $sites[ 1 ];

        switch_to_blog( $site1[ 'blog_id' ] );
        $this->assertEquals( 2, Util::count_posts( 'sos' ) );
        restore_current_blog();

        switch_to_blog( $site2[ 'blog_id' ] );
        $this->assertEquals( 1, Util::count_posts( 'sos' ) );
        restore_current_blog();

        // uninstall by non super admin
        revoke_super_admin( $this->user_id );
        sos_uninstall_sos_plugin();

        switch_to_blog( $site1[ 'blog_id' ] );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $stats = get_option( 'sos_stats' );
        $this->assertNotFalse( $stats );
        $stats_summary = get_option( 'sos_stats_summary' );
        $this->assertNotFalse( $stats_summary );
        $this->assertEquals( 2, Util::count_posts( 'sos' ) );
        restore_current_blog();

        switch_to_blog( $site2[ 'blog_id' ] );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $stats = get_option( 'sos_stats' );
        $this->assertNotFalse( $stats );
        $stats_summary = get_option( 'sos_stats_summary' );
        $this->assertNotFalse( $stats_summary );
        $this->assertEquals( 1, Util::count_posts( 'sos' ) );
        restore_current_blog();
    }

    public function test_sos_uninstall_sos_plugin_multisite_by_superadmin () {
        // sites
        $sites = get_sites();
        $this->assertCount( 2, $sites );
        $site1 = (array) $sites[ 0 ];
        $site2 = (array) $sites[ 1 ];

        switch_to_blog( $site1[ 'blog_id' ] );
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $stats = get_option( 'sos_stats' );
        $this->assertNotFalse( $stats );
        $stats_summary = get_option( 'sos_stats_summary' );
        $this->assertNotFalse( $stats_summary );
        $this->assertEquals( 2, Util::count_posts( 'sos' ) );
        restore_current_blog();

        switch_to_blog( $site2[ 'blog_id' ] );
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $stats = get_option( 'sos_stats' );
        $this->assertNotFalse( $stats );
        $stats_summary = get_option( 'sos_stats_summary' );
        $this->assertNotFalse( $stats_summary );
        $this->assertEquals( 1, Util::count_posts( 'sos' ) );
        restore_current_blog();

        // uninstall by super adin
        grant_super_admin( $this->user_id );
        sos_uninstall_sos_plugin();

        switch_to_blog( $site1[ 'blog_id' ] );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertFalse( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        $stats = get_option( 'sos_stats' );
        $this->assertFalse( $stats );
        $stats_summary = get_option( 'sos_stats_summary' );
        $this->assertFalse( $stats_summary );
        $this->assertEquals( 0, Util::count_posts( 'sos' ) );
        restore_current_blog();

        switch_to_blog( $site2[ 'blog_id' ] );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertFalse( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        $stats = get_option( 'sos_stats' );
        $this->assertFalse( $stats );
        $stats_summary = get_option( 'sos_stats_summary' );
        $this->assertFalse( $stats_summary );
        $this->assertEquals( 0, Util::count_posts( 'sos' ) );
        restore_current_blog();
    }

    public function test_sos_delete_sos_posts () {
        // sites
        $sites = get_sites();
        $this->assertCount( 2, $sites );
        $site1 = (array) $sites[ 0 ];
        $site2 = (array) $sites[ 1 ];

        // TODO debug why post added to a blog is also get counted in all blogs
        $this->add_post( 'post' );

        switch_to_blog( $site1[ 'blog_id' ] );
        $this->assertEquals( 2, Util::count_posts( 'sos' ) );
        $this->assertEquals( 1, Util::count_posts( 'post' ) );

        sos_delete_sos_posts();

        $this->assertEquals( 0, Util::count_posts( 'sos' ) );
        $this->assertEquals( 1, Util::count_posts( 'post' ) );
        restore_current_blog();

        switch_to_blog( $site2[ 'blog_id' ] );
        $this->assertEquals( 1, Util::count_posts( 'sos' ) );
        $this->assertEquals( 1, Util::count_posts( 'post' ) );

        sos_delete_sos_posts();

        $this->assertEquals( 0, Util::count_posts( 'sos' ) );
        $this->assertEquals( 1, Util::count_posts( 'post' ) );
        restore_current_blog();
    }

    public function test_sos_delete_sos_options () {
        // sites
        $sites = get_sites();
        $this->assertCount( 2, $sites );
        $site1 = (array) $sites[ 0 ];
        $site2 = (array) $sites[ 1 ];

        switch_to_blog( $site1[ 'blog_id' ] );
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $stats = get_option( 'sos_stats' );
        $this->assertNotFalse( $stats );
        $stats_summary = get_option( 'sos_stats_summary' );
        $this->assertNotFalse( $stats_summary );

        sos_delete_sos_options();

        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        $stats = get_option( 'sos_stats' );
        $this->assertFalse( $stats );
        $stats_summary = get_option( 'sos_stats_summary' );
        $this->assertFalse( $stats_summary );
        restore_current_blog();

        switch_to_blog( $site2[ 'blog_id' ] );

        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $stats = get_option( 'sos_stats' );
        $this->assertNotFalse( $stats );
        $stats_summary = get_option( 'sos_stats_summary' );
        $this->assertNotFalse( $stats_summary );

        sos_delete_sos_options();

        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        $stats = get_option( 'sos_stats' );
        $this->assertFalse( $stats );
        $stats_summary = get_option( 'sos_stats_summary' );
        $this->assertFalse( $stats_summary );
        restore_current_blog();
    }

    private function add_post ( $post_type ) {
        $args = array(
                'post_name' => 'test locker',
                'post_title' => 'test locker',
                'post_status' => 'publish',
                'post_type' => $post_type,
                'post_content' => ''
        );
        $post_id = $this->factory->post->create( $args );
    }

    private function add_user ( $login_name ) {
        $userdata = array(
                'user_login' => $login_name,
                'user_url' => $this->domain,
                'user_pass' => NULL
        );
        return $this->factory->user->create_object( $userdata );
    }

    // add blog to multisite
    private function add_blog ( $path, $title ) {
        // $_SERVER[ 'REMOTE_ADDR' ] = $this->domain;
        // use factory to add one more blog to the site
        $args = array(
                'domain' => $this->domain,
                'site_id' => 1,
                'path' => $path,
                'title' => $title
        );
        $this->factory->blog->create_object( $args );
    }
}

