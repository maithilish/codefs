<?php

class Test_Help extends WP_UnitTestCase {

    var $sos_help;

    public function setup () {
        parent::setup();
        
        require_once 'admin/class-help.php';
        $this->sos_help = new Sos_Help();
    }

    public function teardown () {
        parent::teardown();
        unload_textdomain( 'sos-domain' );
    }

    public function test_setup () {
        $this->assertFalse( 
                Util::has_action( 'admin_head', $this->sos_help, 
                        'codex_sos_locker_help_tab' ) );
        
        $this->sos_help->setup();
        
        $this->assertTrue( 
                Util::has_action( 'admin_head', $this->sos_help, 
                        'codex_sos_locker_help_tab' ) );
    }

    public function test_codex_sos_locker_help_tab () {
        global $current_screen;
        $this->assertNull( $current_screen );
        
        // setup admin screen
        $screen = WP_Screen::get( 'admin_head' );
        $current_screen = $screen;
        
        // try to set help tabs - should not set as post type is not sos
        $this->sos_help->codex_sos_locker_help_tab();
        $help_tabs = $this->get_help_tabs( $screen );
        $this->assertCount( 0, $help_tabs );
        
        // set post type as sos
        $screen->post_type = $this->sos_help->post_type;
        
        // set help tabs and test
        $this->sos_help->codex_sos_locker_help_tab();
        $help_tabs = $this->get_help_tabs( $screen );
        
        $this->assertCount( 4, $help_tabs );
        
        $this->assertTrue( isset( $help_tabs[ 'locker_id_tab' ] ) );
        $this->assertTrue( isset( $help_tabs[ 'locker_shareon_tab' ] ) );
        $this->assertTrue( isset( $help_tabs[ 'locker_share_tab' ] ) );
        $this->assertTrue( isset( $help_tabs[ 'locker_text_tab' ] ) );
        
        $this->assertCount( 4, $help_tabs[ 'locker_id_tab' ] );
        $this->assertCount( 4, $help_tabs[ 'locker_shareon_tab' ] );
        $this->assertCount( 4, $help_tabs[ 'locker_share_tab' ] );
        $this->assertCount( 4, $help_tabs[ 'locker_text_tab' ] );
        
        $current_screen = null;
    }

    public function test_locker_id_tab () {
        $tab = $this->sos_help->locker_id_tab();
        $expected = $this->expected_locker_id_tab();
        
        $this->assertCount( 3, $tab );
        $this->assertSame( 'locker_id_tab', $tab[ 'id' ] );
        $this->assertSame( 'Locker ID', $tab[ 'title' ] );
        $this->assertSame( Util::trim_whitespaces( $expected ), 
                Util::trim_whitespaces( $tab[ 'content' ] ) );
    }

    public function test_locker_id_tab_translate () {
        Util::change_locale( 'eo_FR' );
        $tab = $this->sos_help->locker_id_tab();
        $expected = $this->expected_locker_id_tab( 'Espéranto-France' );
        
        $this->assertCount( 3, $tab );
        $this->assertSame( 'locker_id_tab', $tab[ 'id' ] );
        $this->assertSame( 'Espéranto-France Locker ID', $tab[ 'title' ] );
        $this->assertSame( Util::trim_whitespaces( $expected ), 
                Util::trim_whitespaces( $tab[ 'content' ] ) );
    }

    public function test_locker_shareon_tab () {
        $tab = $this->sos_help->locker_shareon_tab();
        $expected = $this->expected_locker_shareon_tab();
        
        $this->assertCount( 3, $tab );
        $this->assertSame( 'locker_shareon_tab', $tab[ 'id' ] );
        $this->assertSame( 'Share On', $tab[ 'title' ] );
        $this->assertSame( Util::trim_whitespaces( $expected ), 
                Util::trim_whitespaces( $tab[ 'content' ] ) );
    }

    public function test_locker_shareon_tab_translate () {
        Util::change_locale( 'eo_FR' );
        $tab = $this->sos_help->locker_shareon_tab();
        $expected = $this->expected_locker_shareon_tab( 'Espéranto-France' );
        
        $this->assertCount( 3, $tab );
        $this->assertSame( 'locker_shareon_tab', $tab[ 'id' ] );
        $this->assertSame( 'Espéranto-France Share On', $tab[ 'title' ] );
        $this->assertSame( Util::trim_whitespaces( $expected ), 
                Util::trim_whitespaces( $tab[ 'content' ] ) );
    }

    public function test_locker_share_tab () {
        $tab = $this->sos_help->locker_share_tab();
        $expected = $this->expected_locker_share_tab();
        
        $this->assertCount( 3, $tab );
        $this->assertSame( 'locker_share_tab', $tab[ 'id' ] );
        $this->assertSame( 'Share [which URL]', $tab[ 'title' ] );
        $this->assertSame( Util::trim_whitespaces( $expected ), 
                Util::trim_whitespaces( $tab[ 'content' ] ) );
    }

    public function test_locker_share_tab_translate () {
        Util::change_locale( 'eo_FR' );
        $tab = $this->sos_help->locker_share_tab();
        $expected = $this->expected_locker_share_tab( 'Espéranto-France' );
        
        $this->assertCount( 3, $tab );
        $this->assertSame( 'locker_share_tab', $tab[ 'id' ] );
        $this->assertSame( 'Espéranto-France Share [which URL]', 
                $tab[ 'title' ] );
        $this->assertSame( Util::trim_whitespaces( $expected ), 
                Util::trim_whitespaces( $tab[ 'content' ] ) );
    }

    public function test_locker_text_tab () {
        $tab = $this->sos_help->locker_text_tab();
        $expected = $this->expected_locker_text_tab();
        
        $this->assertCount( 3, $tab );
        $this->assertSame( 'locker_text_tab', $tab[ 'id' ] );
        $this->assertSame( 'Display Text', $tab[ 'title' ] );
        $this->assertSame( Util::trim_whitespaces( $expected ), 
                Util::trim_whitespaces( $tab[ 'content' ] ) );
    }

    public function test_locker_text_tab_translate () {
        Util::change_locale( 'eo_FR' );
        $tab = $this->sos_help->locker_text_tab();
        $expected = $this->expected_locker_text_tab( 'Espéranto-France' );
        
        $this->assertCount( 3, $tab );
        $this->assertSame( 'locker_text_tab', $tab[ 'id' ] );
        $this->assertSame( 'Espéranto-France Display Text', $tab[ 'title' ] );
        $this->assertSame( Util::trim_whitespaces( $expected ), 
                Util::trim_whitespaces( $tab[ 'content' ] ) );
    }

    public function test_get_tab () {
        $tab = $this->sos_help->get_tab( 'test id', 'test title', 
                'test content' );
        $this->assertCount( 3, $tab );
        $this->assertSame( 'test id', $tab[ 'id' ] );
        $this->assertSame( 'test title', $tab[ 'title' ] );
        $this->assertSame( 'test content', $tab[ 'content' ] );
    }
    
    // use reflection to access private WP_Screen::_help_tabs
    private function get_help_tabs ( $screen ) {
        $cr = new ReflectionClass( get_class( $screen ) );
        $cr_help_tabs = $cr->getProperty( '_help_tabs' );
        $cr_help_tabs->setAccessible( true );
        $help_tabs = $cr_help_tabs->getValue( $screen );
        return $help_tabs;
    }

    private function expected_locker_id_tab ( $lang_str = '' ) {
        $lang_str == '' ? $lang_str : $lang_str .= ' ';
        $html = <<<EOD
        <h3>{$lang_str}Locker ID</h3>
        <p>{$lang_str}Enter a uniquie ID for the locker. {$lang_str}Both name and number are allowed as the id. </p>
        <p>{$lang_str}Use some descriptive name as locker id which is easy to remember</p>
EOD;
        return $html;
    }

    private function expected_locker_shareon_tab ( $lang_str = '' ) {
        $lang_str == '' ? $lang_str : $lang_str .= ' ';
        $html = <<<EOD
        <h3>{$lang_str}Share On</h3>
		<p>{$lang_str}Select the Share buttons to show in the locker</p>        
EOD;
        return $html;
    }

    private function expected_locker_share_tab ( $lang_str = '' ) {
        $lang_str == '' ? $lang_str : $lang_str .= ' ';
        $html = <<<EOD
        <h3>{$lang_str}Share [which URL]</h3>
		<ul>
		<li>{$lang_str}Page - to share the Post/Page URL where locker shortcode is placed</li>
		<li>{$lang_str}Parent Page - to share the Parent Page of the page where locker shortcode is placed</li>
		<li>{$lang_str}Site - to share the URL of the site</li>
		</ul>
		<h4>{$lang_str}Overriding the share specified at locker level</h4>
		<p>{$lang_str}You may also specifiy Share URL in the shortcode using link attribute. {$lang_str}For example shortcode [share-on-social name="my-locker" link="http://example.org"] {$lang_str} overrides page,parent or site setting done at locker level and share example.org</p>
		<p>{$lang_str}Use this feature to share an internal or external URL that is not related to a page/post</p>
EOD;
        return $html;
    }

    private function expected_locker_text_tab ( $lang_str = '' ) {
        $lang_str == '' ? $lang_str : $lang_str .= ' ';
        $html = <<<EOD
	    <h3>{$lang_str}Display Text</h3>
		<p>{$lang_str}Visual Editor allows you to design useful message for each locker. </p>
EOD;
        return $html;
    }
}
