<?php

class Test_Sos_Activator extends WP_UnitTestCase {

    var $activator;

    var $sos;

    public function setup () {
        parent::setup();
        
        // create sos post type
        require_once 'admin/class-sos.php';
        $this->sos = new Sos();
        
        require_once 'admin/class-activator.php';
        $this->activator = new Sos_Activator();
    }

    public function teardown () {
        parent::teardown();
        unload_textdomain( 'sos-domain' );
        delete_option( 'sos_common_options' );
        Util::set_activate_plugins_cap( false );
    }
    
    // test whether activation and deactivation hooks are registered correctly
    // in $wp_filter
    public function test_setup () {
        global $wp_filter;
        
        $act_key = 'activate_share-on-social/share-on-social.php';
        $deact_key = 'deactivate_share-on-social/share-on-social.php';
        $links_key = 'plugin_action_links';
        
        // hooks should not exist in $wp_filter at present
        $this->assertarrayNotHasKey( $act_key, $wp_filter );
        $this->assertarrayNotHasKey( $deact_key, $wp_filter );
        $this->assertarrayNotHasKey( $links_key, $wp_filter );
        
        // register hooks
        $this->activator->setup();
        
        // test Sos_Activator->activate() function is registered
        $this->assertarrayHasKey( $act_key, $wp_filter );
        $this->assertTrue( 
                Util::has_obj( 'Sos_Activator', $wp_filter[ $act_key ] ) );
        $this->assertTrue( 
                Util::has_value( 'activate', $wp_filter[ $act_key ] ) );
        
        // test Sos_Activator->deactivate() function is registered
        $this->assertarrayHasKey( $deact_key, $wp_filter );
        $this->assertTrue( 
                Util::has_obj( 'Sos_Activator', $wp_filter[ $deact_key ] ) );
        $this->assertTrue( 
                Util::has_value( 'deactivate', $wp_filter[ $deact_key ] ) );
        
        $this->assertarrayHasKey( $links_key, $wp_filter );
        $this->assertTrue( 
                Util::has_obj( 'Sos_Activator', $wp_filter[ $links_key ] ) );
        $this->assertTrue( 
                Util::has_value( 'action_links', $wp_filter[ $links_key ] ) );
        
        $obj_id = spl_object_hash( $this->activator );
        $priority = 10;
        $expected = 2; // accepted_args field
        $result = $wp_filter[ $links_key ][ $priority ][ $obj_id . 'action_links' ][ 'accepted_args' ];
        $this->assertSame( $expected, $result );
    }

    function test_activate_without_cap () {
        
        // create locker
        Util::set_activate_plugins_cap( true );
        $this->sos->create_post_type();
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        
        // no option
        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        
        // try to activate without cap
        $networkwide = false;
        Util::set_activate_plugins_cap( false );
        $this->activator->activate( $networkwide );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        
        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
    }

    function test_activate_with_cap () {
        // create locker
        Util::set_activate_plugins_cap( true );
        $this->sos->create_post_type();
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        
        // no option
        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        
        // activate with cap
        $networkwide = false;
        Util::set_activate_plugins_cap( true );
        $this->activator->activate( $networkwide );
        
        // test locker deleted by activate
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertFalse( isset( $post_id ) );
        
        // test options
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $this->assertCount( 1, $options );
        $this->assertSame( SOS_VERSION, $options[ 'version' ] );
    }

    function test_deactivate_without_cap () {
        $networkwide = false;
        // create locker
        Util::set_activate_plugins_cap( true );
        $this->sos->create_post_type();
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        
        // add options
        $this->activator->add_settings();
        
        // try to deactivate without cap
        Util::set_activate_plugins_cap( false );
        $this->activator->deactivate( $networkwide );
        
        // test locker
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        
        // test options
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $this->assertCount( 1, $options );
        $this->assertSame( SOS_VERSION, $options[ 'version' ] );
    }

    function test_deactivate_with_cap () {
        $networkwide = false;
        // create locker
        Util::set_activate_plugins_cap( true );
        $this->sos->create_post_type();
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        
        // add options
        $this->activator->add_settings();
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        
        // try to deactivate with cap
        Util::set_activate_plugins_cap( true );
        $this->activator->deactivate( $networkwide );
        
        // test locker deleted
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertFalse( isset( $post_id ) );
        
        // test options not deleted
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $this->assertCount( 1, $options );
        $this->assertSame( SOS_VERSION, $options[ 'version' ] );
    }

    function test_action_links () {
        $links = array();
        $file = 'plugin-x/plugin.php';
        $links = $this->activator->action_links( $links, $file );
        $this->assertCount( 0, $links );
        
        $file = 'share-on-social/share-on-social.php';
        $links = $this->activator->action_links( $links, $file );
        $expected = '<a href="http://localhost/wp-admin/edit.php?post_type=sos&page=sos_settings_page">Settings</a>';
        $this->assertCount( 1, $links );
        $this->assertSame( $expected, $links[ 0 ] );
        
        // test whether array_unshift is called
        $links = array(
                'http://example.org'
        );
        $links = $this->activator->action_links( $links, $file );
        $this->assertCount( 2, $links );
        $this->assertSame( $expected, $links[ 0 ] );
        $this->assertSame( 'http://example.org', $links[ 1 ] );
    }

    public function test_add_settings () {
        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        
        $this->activator->add_settings();
        
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $this->assertCount( 1, $options );
        $this->assertSame( SOS_VERSION, $options[ 'version' ] );
    }

    private function add_blog ( $path, $title ) {
        // use factory to add one more blog to the site
        $args = array(
                'domain' => 'localhost',
                'site_id' => 1,
                'path' => $path,
                'title' => $title
        );
        $this->factory->blog->create_object( $args );
    }

    private function add_user ( $login_name ) {
        $userdata = array(
                'user_login' => $login_name,
                'user_url' => 'localhost',
                'user_pass' => NULL
        );
        return $this->factory->user->create_object( $userdata );
    }
}

