<?php

class Test_Sos_Admin extends WP_UnitTestCase {

    var $sos_admin;

    public function setup () {
        parent::setup();
        
        require_once 'admin/class-admin.php';
        $this->sos_admin = new Sos_Admin();
    }

    public function teardown () {
        parent::teardown();
    }

    public function test_no_setup () {
        // test for absense
        // sos action
        $action = Util::get_action( 'init' );
        $this->assertFalse( Util::has_obj( 'Sos', $action ) );
        $this->assertFalse( Util::has_value( 'create_post_type', $action ) );
        
        // sos_options action
        $action = Util::get_action( 'admin_menu' );
        $this->assertFalse( Util::has_obj( 'Sos_Options', $action ) );
        $this->assertFalse( 
                Util::has_value( 'register_settings_page', $action ) );
        
        // sos_ajax action
        $action = Util::get_action( 'wp_ajax_save-stats' );
        $this->assertNull( $action );
        
        // sos_help action
        $action = Util::get_action( 'admin_head' );
        $this->assertFalse( Util::has_obj( 'Sos_Help', $action ) );
        $this->assertFalse( 
                Util::has_value( 'codex_sso_locker_help_tab', $action ) );
        
        global $wp_object_cache;
        $cache = $wp_object_cache->cache;
        $this->assertCount( 0, $cache );
    }

    public function test_setup () {
        // call sos_admin setup and test whether all its parts are setup
        $this->sos_admin->setup();
        
        // test for sos action
        $action = Util::get_action( 'init' );
        $this->assertTrue( Util::has_obj( 'Sos', $action ) );
        $this->assertTrue( Util::has_value( 'create_post_type', $action ) );
        
        // sos_options action
        $action = Util::get_action( 'admin_menu' );
        $this->assertTrue( Util::has_obj( 'Sos_Options', $action ) );
        $this->assertTrue( 
                Util::has_value( 'register_settings_page', $action ) );
        
        // sos_ajax action
        $action = Util::get_action( 'wp_ajax_save-stats' );
        $this->assertTrue( Util::has_obj( 'Sos_Ajax', $action ) );
        $this->assertTrue( Util::has_value( 'save_stats', $action ) );
        
        // sos_help action
        $action = Util::get_action( 'admin_head' );
        $this->assertTrue( Util::has_obj( 'Sos_Help', $action ) );
        $this->assertTrue( 
                Util::has_value( 'codex_sos_locker_help_tab', $action ) );
        
        // check whether cache is primed
        global $wp_object_cache;
        $cache = $wp_object_cache->cache;
        
        if ( false == is_multisite() ) {
            $this->assertCount( 1, $cache );
            $this->assertarrayHasKey( 'options', $cache );
            $this->assertarrayHasKey( 'alloptions', $cache[ 'options' ] );
            $this->assertarrayHasKey( 'notoptions', $cache[ 'options' ] );
        } else {
            $this->assertCount( 1, $cache );
            $this->assertarrayHasKey( 'options', $cache );
            $this->assertarrayHasKey( '1:alloptions', $cache[ 'options' ] );
            $this->assertarrayHasKey( '1:notoptions', $cache[ 'options' ] );
        }
    }
}
