<?php

class Test_Share_On_Social extends WP_UnitTestCase {
    
    /*
     * when backupGlobals="true" in phpunit.xml, plugin.php tries to run
     * shutdown hook in the end and encounters mysql error. So remove the
     * shudown hook. we can't do this in teardown() as globals are restored by
     * phpunit after the class
     */
    public static function tearDownAfterClass () {
        remove_action( 'shutdown', 'Sos_Helper::output_debug_data' );
    }

    function test_sos_active () {
        $this->assertTrue( 
                is_plugin_active( 'share-on-social/share-on-social.php' ) );
        $this->assertEquals( 1, get_current_user_id() ); // admin
    }

    function test_textdomain_loaded () {
        $this->assertFalse( is_textdomain_loaded( 'sos-domain' ) );
        
        global $locale;
        $locale = 'eo_FR';
        
        setup_sos_plugin();
        
        $this->assertTrue( is_textdomain_loaded( 'sos-domain' ) );
    }

    public function test_constants () {
        $this->assertSame( SOS_NAME, 'share-on-social' );
        $this->assertSame( SOS_VERSION, '1.0.0' );
        $this->assertSame( SOS_DEV, true );
        
        $url = str_replace( 'tests/phpunit/tests/', '', 
                trailingslashit( plugin_dir_url( __FILE__ ) ) );
        $this->assertSame( SOS_URL, $url );
        
        $path = str_replace( 'tests/phpunit/tests/', '', 
                plugin_dir_path( __FILE__ ) );
        $this->assertSame( SOS_PATH, $path );
        
        $this->assertSame( SOS_PLUGIN_BASENAME, 
                'share-on-social/share-on-social.php' );
        $this->assertSame( SOS_PLUGIN_FILE, $path . 'share-on-social.php' );
        $this->assertSame( TD, 'sos-domain' );
    }

    public function test_includes_for_frontend () {
        $included_files = get_included_files();
        
        $file = SOS_PATH . 'frontend/class-frontend.php';
        $this->assertContains( $file, $included_files );
        
        $file = SOS_PATH . 'include/class-helper.php';
        $this->assertContains( $file, $included_files );
    }

    public function test_actions_for_frontend () {
        // has_action returns false or priority of the action
        $this->assertTrue( 
                has_action( 'shutdown', 'Sos_Helper::output_debug_data' ) == true );
        $this->assertTrue( 
                has_action( 'plugins_loaded', 'load_sos_frontend' ) == true );
    }
    
    /*
     * Frontend is default loaded by bootloader. It is tested by previous two
     * tests. For code coverage of setup_sos_plugin(), we again test explictly.
     */
    public function test_setup_for_frontend () {
        $included_files = get_included_files();
        
        // common to admin and frontend - already added
        $this->assertTrue( 
                has_action( 'shutdown', 'Sos_Helper::output_debug_data' ) >= 0 );
        
        $file = SOS_PATH . 'include/class-helper.php';
        $this->assertContains( $file, $included_files );
        
        // already set by bootloader so remove
        remove_action( 'shutdown', 'Sos_Helper::output_debug_data' );
        remove_action( 'plugins_loaded', 'load_sos_frontend' );
        
        $this->assertFalse( 
                has_action( 'shutdown', 'Sos_Helper::output_debug_data' ) == true );
        $this->assertFalse( 
                has_action( 'plugins_loaded', 'load_sos_frontend' ) == true );
        
        // now call setup - no screen is set so is_admin() is false
        setup_sos_plugin();
        
        // test whether removed actions are added by setup
        $this->assertTrue( 
                has_action( 'shutdown', 'Sos_Helper::output_debug_data' ) == true );
        $this->assertTrue( 
                has_action( 'plugins_loaded', 'load_sos_frontend' ) == true );
    }
    
    /*
     * admin stuff not added by default by setup_sos_plugin() as is_admin() is
     * false. We test admin by calling setup_sos_plugin() by setting up a admin
     * screen
     */
    public function test_setup_for_admin () {
        $included_files = get_included_files();
        
        // common to admin and frontend - already added
        $this->assertTrue( 
                has_action( 'shutdown', 'Sos_Helper::output_debug_data' ) == true );
        
        $file = SOS_PATH . 'include/class-helper.php';
        $this->assertContains( $file, $included_files );
        
        // includes and actions specific to admin - test for not exists
        $file = SOS_PATH . 'admin/class-admin.php';
        $this->assertNotContains( $file, $included_files );
        
        $file = SOS_PATH . 'frontend/class-ajax.php';
        $this->assertNotContains( $file, $included_files );
        
        $file = SOS_PATH . 'frontend/class-activator.php';
        $this->assertNotContains( $file, $included_files );
        
        $file = SOS_PATH . 'frontend/class-sos.php';
        $this->assertNotContains( $file, $included_files );
        
        $this->assertFalse( has_action( 'plugins_loaded', 'load_sos_admin' ) );
        
        $action = Util::get_action( 
                'activate_share-on-social/share-on-social.php' );
        $this->assertNull( $action );
        
        $action = Util::get_action( 
                'deactivate_share-on-social/share-on-social.php' );
        $this->assertNull( $action );
        
        // setup admin screen to make is_admin() as true
        
        global $current_screen;
        $this->assertNull( $current_screen );
        
        $screen = WP_Screen::get( 'admin_init' );
        $current_screen = $screen;
        
        // now call setup
        setup_sos_plugin();
        
        // test for admin stuff
        $included_files = get_included_files();
        
        $file = SOS_PATH . 'admin/class-admin.php';
        $this->assertContains( $file, $included_files );
        
        $file = SOS_PATH . 'admin/class-ajax.php';
        $this->assertContains( $file, $included_files );
        
        $file = SOS_PATH . 'include/class-helper.php';
        $this->assertContains( $file, $included_files );
        
        $file = SOS_PATH . 'admin/class-activator.php';
        $this->assertContains( $file, $included_files );
        
        $file = SOS_PATH . 'admin/class-sos.php';
        $this->assertContains( $file, $included_files );
        
        $this->assertTrue( 
                has_action( 'plugins_loaded', 'load_sos_admin' ) == true );
        
        $this->assertTrue( 
                has_action( 'shutdown', 'Sos_Helper::output_debug_data' ) == true );
        
        // test for activator
        $action = Util::get_action( 
                'activate_share-on-social/share-on-social.php' );
        $this->assertCount( 1, $action );
        $this->assertTrue( Util::has_obj( 'Sos_Activator', $action ) );
        $this->assertTrue( Util::has_Value( 'activate', $action ) );
        
        $action = Util::get_action( 
                'deactivate_share-on-social/share-on-social.php' );
        $this->assertCount( 1, $action );
        $this->assertTrue( Util::has_obj( 'Sos_Activator', $action ) );
        $this->assertTrue( Util::has_Value( 'deactivate', $action ) );
        
        // revert back the screen
        $current_screen = null;
    }

    public function test_load_admin () {
        $action = Util::get_action( 'admin_notices' );
        $this->assertFalse( Util::has_obj( 'Sos', $action ) );
        $this->assertFalse( Util::has_Value( 'sos_admin_notice', $action ) );
        
        load_sos_admin();
        
        $action = Util::get_action( 'admin_notices' );
        $this->assertFalse( Util::has_obj( 'Sos', $action ) );
        $this->assertFalse( Util::has_Value( 'sos_admin_notice', $action ) );
        
        $GLOBALS[ 'wp_tests_options' ][ 'sos_test' ] = false;
        load_sos_admin();
        
        $action = Util::get_action( 'admin_notices' );
        $this->assertTrue( Util::has_obj( 'Sos', $action ) );
        $this->assertTrue( Util::has_Value( 'sos_admin_notice', $action ) );
        
        $GLOBALS[ 'wp_tests_options' ][ 'sos_test' ] = true;
    }

    public function test_load_frontend () {
        $action = Util::get_action( 'wp_enqueue_scripts' );
        $this->assertFalse( Util::has_obj( 'Sos_Frontend', $action ) );
        $this->assertFalse( Util::has_Value( 'add_sos_scripts', $action ) );
        
        load_sos_frontend();
        
        $action = Util::get_action( 'wp_enqueue_scripts' );
        $this->assertFalse( Util::has_obj( 'Sos_Frontend', $action ) );
        $this->assertFalse( Util::has_Value( 'add_sos_scripts', $action ) );
        
        $GLOBALS[ 'wp_tests_options' ][ 'sos_test' ] = false;
        
        load_sos_frontend();
        
        $action = Util::get_action( 'wp_enqueue_scripts' );
        $this->assertTrue( Util::has_obj( 'Sos_Frontend', $action ) );
        $this->assertTrue( Util::has_Value( 'add_sos_scripts', $action ) );
        
        $GLOBALS[ 'wp_tests_options' ][ 'sos_test' ] = true;
    }
}
