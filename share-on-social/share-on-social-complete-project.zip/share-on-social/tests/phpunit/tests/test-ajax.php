<?php

/**
*  !!!! ONLY FOR AJAX CALL !!!!
*  
* Tests for the Ajax calls to save and get sos stats. 
* For speed, non ajax calls of class-ajax.php are tested in test-ajax-others.php
* Ajax tests are not marked risky when run in separate processes and wp_debug 
* disabled. But, this makes tests slow so non ajax calls are kept separate
* 
* @group ajax
* @runTestsInSeparateProcesses
*  
*/
class Test_Sos_Ajax extends WP_Ajax_UnitTestCase {

    var $sos_ajax;

    public function setup () {
        parent::setup();
        
        require_once 'admin/class-ajax.php';
        $this->sos_ajax = new Sos_Ajax();
        
        wp_set_current_user( 1 );
    }

    public function teardown () {
        parent::teardown();
        unload_textdomain( 'sos-domain' );
    }

    public function test_save_stats_no_option () {
        $stats = get_option( 'sos_stats' );
        $this->assertFalse( $stats );
    }

    public function test_save_stats_no_nonce () {
        global $_POST;
        $_POST[ 'type' ] = 'fb';
        $_POST[ 'share_name' ] = 'test';
        
        try {
            $this->sos_ajax->setup();
            $this->_handleAjax( 'save-stats' );
        } catch (WPAjaxDieStopException $e) {}
        
        $this->assertTrue( isset( $e ) );
        $this->assertEquals( '-1', $e->getMessage() );
        $this->assertFalse( get_option( 'sos_stats' ) );
    }

    public function test_save_stats_invalid_nonce () {
        global $_POST;
        $_POST[ 'type' ] = 'fb';
        $_POST[ 'share_name' ] = 'test';
        $_POST[ '_wpnonce' ] = wp_create_nonce( 'invalid-nonce' );
        
        try {
            $this->sos_ajax->setup();
            $this->_handleAjax( 'save-stats' );
        } catch (WPAjaxDieStopException $e) {}
        
        $this->assertTrue( isset( $e ) );
        $this->assertEquals( '-1', $e->getMessage() );
        $this->assertFalse( get_option( 'sos_stats' ) );
    }

    public function test_save_stats_valid_nonce () {
        global $_POST;
        $_POST[ 'type' ] = 'fb';
        $_POST[ 'share_name' ] = 'test';
        $_POST[ '_wpnonce' ] = wp_create_nonce( 'sos-save-stat' );
        
        try {
            $this->sos_ajax->setup();
            $this->_handleAjax( 'save-stats' );
        } catch (WPAjaxDieStopException $e) {}
        
        $this->assertTrue( isset( $e ) );
        $this->assertEquals( '1', $e->getMessage() );
        $stats = get_option( 'sos_stats' );
        $this->assertCount( 1, $stats );
        
        $stat = $stats[ 0 ];
        $this->assertSame( 'fb', $stat[ 'type' ] );
        $this->assertSame( 'test', $stat[ 'share_name' ] );
    }

    public function test_save_stats_values_not_set () {
        global $_POST;
        // type,share-name not set
        $_POST[ '_wpnonce' ] = wp_create_nonce( 'sos-save-stat' );
        try {
            $this->sos_ajax->setup();
            $this->_handleAjax( 'save-stats' );
        } catch (WPAjaxDieStopException $e) {}
        $this->assertTrue( isset( $e ) );
        $this->assertEquals( '-1', $e->getMessage() );
        $this->assertFalse( get_option( 'sos_stats' ) );
        
        // type not set
        $_POST[ 'share-name' ] = 'test';
        $_POST[ '_wpnonce' ] = wp_create_nonce( 'sos-save-stat' );
        try {
            $this->sos_ajax->setup();
            $this->_handleAjax( 'save-stats' );
        } catch (WPAjaxDieStopException $e) {}
        $this->assertTrue( isset( $e ) );
        $this->assertEquals( '-1', $e->getMessage() );
        $this->assertFalse( get_option( 'sos_stats' ) );
        
        // share-name not set
        $_POST[ 'type' ] = 'fb';
        $_POST[ '_wpnonce' ] = wp_create_nonce( 'sos-save-stat' );
        try {
            $this->sos_ajax->setup();
            $this->_handleAjax( 'save-stats' );
        } catch (WPAjaxDieStopException $e) {}
        $this->assertTrue( isset( $e ) );
        $this->assertEquals( '-1', $e->getMessage() );
        $this->assertFalse( get_option( 'sos_stats' ) );
    }

    public function test_save_stat_stats () {
        global $_POST;
        $_POST[ 'type' ] = 'fb';
        $_POST[ 'share_name' ] = 'test';
        $_POST[ '_wpnonce' ] = wp_create_nonce( 'sos-save-stat' );
        
        try {
            $this->sos_ajax->setup();
            $this->_handleAjax( 'save-stats' );
        } catch (WPAjaxDieStopException $e) {}
        
        $this->assertTrue( isset( $e ) );
        $this->assertEquals( '1', $e->getMessage() );
        
        $stats = get_option( 'sos_stats' );
        $this->assertCount( 1, $stats );
        
        $stat = $stats[ 0 ];
        
        $this->assertSame( 'fb', $stat[ 'type' ] );
        $this->assertSame( 'test', $stat[ 'share_name' ] );
    }

    public function test_save_stat_summary () {
        global $_POST;
        $_POST[ 'type' ] = 'fb';
        $_POST[ 'share_name' ] = 'test';
        $_POST[ '_wpnonce' ] = wp_create_nonce( 'sos-save-stat' );
        
        $summary = get_option( 'sos_stats_summary' );
        $this->assertFalse( $summary );
        
        try {
            $this->sos_ajax->setup();
            $this->_handleAjax( 'save-stats' );
        } catch (WPAjaxDieStopException $e) {}
        
        $this->assertTrue( isset( $e ) );
        $this->assertEquals( '1', $e->getMessage() );
        
        $summary = get_option( 'sos_stats_summary' );
        $this->assertCount( 1, $summary );
        $this->assertSame( 1, $summary[ 'fb' ] );
    }

    public function test_get_stats_no_nonce () {
        try {
            $this->sos_ajax->setup();
            $this->_handleAjax( 'get-stats' );
        } catch (WPAjaxDieStopException $e) {}
        
        $this->assertTrue( isset( $e ) );
        $this->assertEquals( '-1', $e->getMessage() );
    }

    public function test_get_stats_invalid_nonce () {
        global $_POST;
        $_POST[ '_wpnonce' ] = wp_create_nonce( 'invalid-nonce' );
        
        try {
            $this->sos_ajax->setup();
            $this->_handleAjax( 'get-stats' );
        } catch (WPAjaxDieStopException $e) {}
        
        $this->assertTrue( isset( $e ) );
        $this->assertEquals( '-1', $e->getMessage() );
    }

    public function test_get_stats_valid_nonce () {
        global $_POST;
        $_POST[ '_wpnonce' ] = wp_create_nonce( 'sos-get-stats' );
        
        try {
            $this->sos_ajax->setup();
            $this->_handleAjax( 'get-stats' );
        } catch (WPAjaxDieStopException $e) {}
        
        $this->assertTrue( isset( $e ) );
        $result = $e->getMessage();
        $expected = '{"cols":[{"label":"Date","type":"date"},{"label":"Facebook","type":"number"},{"label":"GPlus","type":"number"},{"label":"Twitter","type":"number"}]}';
        $this->assertSame( $expected, $result );
    }

    public function test_get_stats_no_stat () {
        global $_POST;
        $_POST[ '_wpnonce' ] = wp_create_nonce( 'sos-get-stats' );
        
        try {
            $this->sos_ajax->setup();
            $this->_handleAjax( 'get-stats' );
        } catch (WPAjaxDieStopException $e) {}
        
        $this->assertTrue( isset( $e ) );
        $result = $e->getMessage();
        $expected = '{"cols":[{"label":"Date","type":"date"},{"label":"Facebook","type":"number"},{"label":"GPlus","type":"number"},{"label":"Twitter","type":"number"}]}';
        $this->assertSame( $expected, $result );
    }

    public function test_get_stats_single_stat () {
        global $_POST;
        $_POST[ '_wpnonce' ] = wp_create_nonce( 'sos-get-stats' );
        
        $test_stats = $this->get_test_stats();
        $stats[] = $test_stats[ 0 ];
        add_option( 'sos_stats', $stats );
        
        try {
            $this->sos_ajax->setup();
            $this->_handleAjax( 'get-stats' );
        } catch (WPAjaxDieStopException $e) {}
        
        $this->assertTrue( isset( $e ) );
        $result = $e->getMessage();
        $expected = '{"cols":[{"label":"Date","type":"date"},{"label":"FB","type":"number"}],"rows":[{"c":[{"v":"Date(2014,9,29)"},{"v":1}]}]}';
        $this->assertSame( $expected, $result );
    }

    public function test_get_stats_single_stat_translate () {
        Util::change_locale( 'eo_FR' );
        
        global $_POST;
        $_POST[ '_wpnonce' ] = wp_create_nonce( 'sos-get-stats' );
        
        $test_stats = $this->get_test_stats();
        $stats[] = $test_stats[ 0 ];
        add_option( 'sos_stats', $stats );
        
        try {
            $this->sos_ajax->setup();
            $this->_handleAjax( 'get-stats' );
        } catch (WPAjaxDieStopException $e) {}
        
        $this->assertTrue( isset( $e ) );
        $result = $e->getMessage();
        $expected = '{"cols":[{"label":"Esp\u00e9ranto-France Date","type":"date"},{"label":"FB","type":"number"}],"rows":[{"c":[{"v":"Date(2014,9,29)"},{"v":1}]}]}';
        $this->assertSame( $expected, $result );
    }

    public function test_get_stats_multi_stat () {
        global $_POST;
        $_POST[ '_wpnonce' ] = wp_create_nonce( 'sos-get-stats' );
        
        $stats = $this->get_test_stats();
        add_option( 'sos_stats', $stats );
        
        try {
            $this->sos_ajax->setup();
            $this->_handleAjax( 'get-stats' );
        } catch (WPAjaxDieStopException $e) {}
        
        $this->assertTrue( isset( $e ) );
        $result = $e->getMessage();
        $expected = '{"cols":[{"label":"Date","type":"date"},{"label":"FB","type":"number"},{"label":"GPlus","type":"number"},{"label":"Twitter","type":"number"}],"rows":[{"c":[{"v":"Date(2014,9,29)"},{"v":2},{"v":1},{"v":0}]},{"c":[{"v":"Date(2014,9,28)"},{"v":2},{"v":2},{"v":0}]},{"c":[{"v":"Date(2014,9,27)"},{"v":0},{"v":0},{"v":1}]}]}';
        $this->assertSame( $expected, $result );
    }

    public function test_get_stats_summary_invalid_nonce () {
        global $_POST;
        $_POST[ '_wpnonce' ] = wp_create_nonce( 'invalid-nonce' );
        
        try {
            $this->sos_ajax->setup();
            $this->_handleAjax( 'get-stats-summary' );
        } catch (WPAjaxDieStopException $e) {}
        
        $this->assertTrue( isset( $e ) );
        $this->assertEquals( '-1', $e->getMessage() );
    }

    public function test_get_stats_summary_valid_nonce () {
        global $_POST;
        $_POST[ '_wpnonce' ] = wp_create_nonce( 'sos-get-stats-summary' );
        
        try {
            $this->sos_ajax->setup();
            $this->_handleAjax( 'get-stats-summary' );
        } catch (WPAjaxDieStopException $e) {}
        
        $this->assertTrue( isset( $e ) );
        $result = $e->getMessage();
        $expected = '{"cols":[{"label":"Share On","type":"string"},{"label":"Total","type":"number"}]}';
        $this->assertSame( $expected, $result );
    }

    public function test_get_stats_summary_no_stat () {
        global $_POST;
        $_POST[ '_wpnonce' ] = wp_create_nonce( 'sos-get-stats-summary' );
        
        try {
            $this->sos_ajax->setup();
            $this->_handleAjax( 'get-stats-summary' );
        } catch (WPAjaxDieStopException $e) {}
        
        $this->assertTrue( isset( $e ) );
        $result = $e->getMessage();
        $expected = '{"cols":[{"label":"Share On","type":"string"},{"label":"Total","type":"number"}]}';
        $this->assertSame( $expected, $result );
    }

    public function test_get_stats_summary () {
        global $_POST;
        $_POST[ '_wpnonce' ] = wp_create_nonce( 'sos-get-stats-summary' );
        
        $summary[ 'fb' ] = 10;
        $summary[ 'gplus' ] = 20;
        $summary[ 'twitter' ] = 30;
        add_option( 'sos_stats_summary', $summary );
        
        try {
            $this->sos_ajax->setup();
            $this->_handleAjax( 'get-stats-summary' );
        } catch (WPAjaxDieStopException $e) {}
        
        $this->assertTrue( isset( $e ) );
        $result = $e->getMessage();
        $expected = '{"cols":[{"label":"Share On","type":"string"},{"label":"Total","type":"number"}],"rows":[{"c":[{"v":"FB"},{"v":10}]},{"c":[{"v":"GPlus"},{"v":20}]},{"c":[{"v":"Twitter"},{"v":30}]}]}';
        $this->assertSame( $expected, $result );
    }

    public function test_get_stats_summary_translate () {
        Util::change_locale( 'eo_FR' );
        
        global $_POST;
        $_POST[ '_wpnonce' ] = wp_create_nonce( 'sos-get-stats-summary' );
        
        $summary[ 'fb' ] = 10;
        $summary[ 'gplus' ] = 20;
        $summary[ 'twitter' ] = 30;
        add_option( 'sos_stats_summary', $summary );
        
        try {
            $this->sos_ajax->setup();
            $this->_handleAjax( 'get-stats-summary' );
        } catch (WPAjaxDieStopException $e) {}
        
        $this->assertTrue( isset( $e ) );
        $result = $e->getMessage();
        $expected = '{"cols":[{"label":"Esp\u00e9ranto-France Share On","type":"string"},{"label":"Esp\u00e9ranto-France Total","type":"number"}],"rows":[{"c":[{"v":"FB"},{"v":10}]},{"c":[{"v":"GPlus"},{"v":20}]},{"c":[{"v":"Twitter"},{"v":30}]}]}';
        $this->assertSame( $expected, $result );
    }

    private function get_test_stats () {
        $stats[] = array(
                'date' => '1414586000',
                'type' => 'fb',
                'share_name' => 'test share 1'
        );
        $stats[] = array(
                'date' => '1414586100',
                'type' => 'fb',
                'share_name' => 'test share 1'
        );
        $stats[] = array(
                'date' => '1414586300',
                'type' => 'gplus',
                'share_name' => 'test share 1'
        );
        $stats[] = array(
                'date' => '1414499600',
                'type' => 'gplus',
                'share_name' => 'test share 2'
        );
        $stats[] = array(
                'date' => '1414499700',
                'type' => 'gplus',
                'share_name' => 'test share 2'
        );
        $stats[] = array(
                'date' => '1414499800',
                'type' => 'fb',
                'share_name' => 'test share 2'
        );
        $stats[] = array(
                'date' => '1414499900',
                'type' => 'fb',
                'share_name' => 'test share 2'
        );
        $stats[] = array(
                'date' => '1414370000',
                'type' => 'twitter',
                'share_name' => 'test share 3'
        );
        return $stats;
    }
}
