<?php

class Test_Sos extends WP_UnitTestCase {

    var $sos;

    public function setup () {
        parent::setup();
        
        require_once 'admin/class-sos.php';
        $this->sos = new Sos();
    }

    public function teardown () {
        parent::teardown();
        unload_textdomain( 'sos-domain' );
        Util::set_activate_plugins_cap( false );
    }

    public function test_setup () {
        
        // test for absense of sos actions
        $this->assertFalse( 
                Util::has_action( 'admin_notices', $this->sos, 
                        'sos_admin_notice' ) );
        $this->assertFalse( 
                Util::has_action( 'init', $this->sos, 'create_post_type' ) );
        $this->assertFalse( 
                Util::has_action( 'save_post', $this->sos, 'save_post' ) );
        $this->assertFalse( 
                Util::has_action( 'admin_head', $this->sos, 
                        'hide_minor_publish' ) );
        
        // test for filters
        $this->assertFalse( 
                Util::has_filter( 'post_updated_messages', $this->sos, 
                        'filter_published_message' ) );
        $this->assertFalse( 
                Util::has_filter( 'manage_posts_custom_column', $this->sos, 
                        'render_post_columns' ) );
        $this->assertFalse( 
                Util::has_filter( 'manage_edit-sos_columns', $this->sos, 
                        'set_post_columns' ) );
        
        // add sos actions
        $this->sos->setup();
        
        // test for presence of sos actions
        $this->assertTrue( 
                Util::has_action( 'admin_notices', $this->sos, 
                        'sos_admin_notice' ) );
        $this->assertTrue( 
                Util::has_action( 'init', $this->sos, 'create_post_type' ) );
        $this->assertTrue( 
                Util::has_action( 'save_post', $this->sos, 'save_post' ) );
        $this->assertTrue( 
                Util::has_action( 'admin_head', $this->sos, 
                        'hide_minor_publish' ) );
        // test for filters
        $this->assertTrue( 
                Util::has_filter( 'post_updated_messages', $this->sos, 
                        'filter_published_message' ) );
        $this->assertTrue( 
                Util::has_filter( 'manage_posts_custom_column', $this->sos, 
                        'render_post_columns' ) );
        $this->assertTrue( 
                Util::has_filter( 'manage_edit-sos_columns', $this->sos, 
                        'set_post_columns' ) );
    }

    public function test_create_post_type () {
        global $wp_post_types;
        
        if ( isset( $wp_post_types[ 'sos' ] ) ) {
            unset( $wp_post_types[ 'sos' ] );
        }
        $this->assertarrayNotHasKey( 'sos', $wp_post_types );
        
        // register post type
        $this->sos->create_post_type();
        $this->assertarrayHasKey( 'sos', $wp_post_types );
        
        $sos_type = $wp_post_types[ 'sos' ];
        $this->assertFalse( $sos_type->public );
        $this->assertFalse( $sos_type->hierarchical );
        $this->assertTrue( $sos_type->exclude_from_search );
        $this->assertFalse( $sos_type->publicly_queryable );
        $this->assertTrue( $sos_type->has_archive );
        
        $this->assertSame( 15, $sos_type->menu_position );
        $this->assertTrue( $sos_type->show_ui );
        $this->assertTrue( $sos_type->show_in_menu );
        $this->assertTrue( $sos_type->show_in_admin_bar );
        $this->assertFalse( $sos_type->show_in_nav_menus );
        $this->assertSame( SOS_URL . '/images/sos-icon.png', 
                $sos_type->menu_icon );
    }

    public function test_create_post_type_create_locker () {
        global $wp_post_types;
        
        if ( isset( $wp_post_types[ 'sos' ] ) ) {
            unset( $wp_post_types[ 'sos' ] );
        }
        $this->assertarrayNotHasKey( 'sos', $wp_post_types );
        
        // test no basic locker
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $locker = get_post( $post_id );
        $this->assertFalse( isset( $locker ) );
        
        // register post type
        Util::set_activate_plugins_cap( true );
        $this->sos->create_post_type();
        $this->assertarrayHasKey( 'sos', $wp_post_types );
        
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $locker = get_post( $post_id );
        $this->assertTrue( isset( $locker ) );
    }

    public function test_create_post_type_create_locker_multiple_times () {
        global $wp_post_types;
        
        if ( isset( $wp_post_types[ 'sos' ] ) ) {
            unset( $wp_post_types[ 'sos' ] );
        }
        $this->assertarrayNotHasKey( 'sos', $wp_post_types );
        
        $this->assertSame( 0, Util::count_posts( 'sos' ) );
        
        // register post type
        Util::set_activate_plugins_cap( true );
        $this->sos->create_post_type();
        $this->assertarrayHasKey( 'sos', $wp_post_types );
        
        $this->sos->create_post_type();
        $this->assertarrayHasKey( 'sos', $wp_post_types );
        
        $this->sos->create_post_type();
        $this->assertarrayHasKey( 'sos', $wp_post_types );
        
        $this->assertEquals( 1, Util::count_posts( 'sos' ) );
        
        // test basic locker
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $locker = get_post( $post_id );
        $this->assertTrue( isset( $locker ) );
    }

    function test_create_basic_locker_without_cap () {
        $this->sos->create_basic_locker();
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $locker = get_post( $post_id );
        $this->assertFalse( isset( $locker ) );
    }

    function test_create_basic_locker_with_cap () {
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $locker = get_post( $post_id );
        $this->assertFalse( isset( $locker ) );
        
        Util::set_activate_plugins_cap( true );
        $this->sos->create_basic_locker();
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $locker = get_post( $post_id );
        $this->assertTrue( isset( $locker ) );
        $this->assertSame( 'basic', $locker->post_name );
        $this->assertSame( 'Basic Locker', $locker->post_title );
        $this->assertSame( 'publish', $locker->post_status );
        $this->assertSame( 'sos', $locker->post_type );
        $this->assertSame( 'basic', 
                get_post_meta( $post_id, 'locker_id', true ) );
        $this->assertSame( '1', get_post_meta( $post_id, 'shareon_fb', true ) );
        $this->assertSame( '1', 
                get_post_meta( $post_id, 'shareon_gplus', true ) );
        $this->assertSame( '1', 
                get_post_meta( $post_id, 'shareon_twitter', true ) );
        $this->assertSame( 'page', 
                get_post_meta( $post_id, 'share_target', true ) );
        
        // test locale strings
        $this->assertSame( trim( $this->get_locker_text( '' ) ), 
                trim( get_post_meta( $post_id, 'locker_text', true ) ) );
        
        // change locale and test
        Util::change_locale( 'eo_FR' );
        $this->assertSame( 
                trim( $this->get_locker_text( 'Espéranto-France' ) ), 
                trim( $this->sos->basic_text() ) );
    }

    public function test_basic_text () {
        // test locale strings
        $this->assertSame( trim( $this->get_locker_text() ), 
                trim( $this->sos->basic_text() ) );
        
        // change locale and test
        Util::change_locale( 'eo_FR' );
        $this->assertSame( 
                trim( $this->get_locker_text( 'Espéranto-France' ) ), 
                trim( $this->sos->basic_text() ) );
    }

    public function test_post_type_supports () {
        global $_wp_post_type_features;
        
        $this->sos->create_post_type();
        $this->assertarrayHasKey( 'sos', $_wp_post_type_features );
        
        $sos_supports = $_wp_post_type_features[ 'sos' ];
        $this->assertCount( 1, $sos_supports );
        $this->assertarrayHasKey( 'title', $sos_supports );
    }

    public function test_post_type_taxonomies () {
        global $wp_post_types;
        $this->sos->create_post_type();
        $this->assertarrayHasKey( 'sos', $wp_post_types );
        $sos_type = $wp_post_types[ 'sos' ];
        $tax = $sos_type->taxonomies;
        
        $this->assertTrue( isset( $tax ) );
        $this->assertCount( 1, $tax );
        $this->assertSame( '', $tax[ 0 ] );
    }

    public function test_meta_box_cb () {
        global $wp_post_types;
        $this->sos->create_post_type();
        $this->assertarrayHasKey( 'sos', $wp_post_types );
        $sos_type = $wp_post_types[ 'sos' ];
        $meta_box = $sos_type->register_meta_box_cb;
        
        $this->assertTrue( isset( $meta_box ) );
        $this->assertCount( 2, $meta_box );
        $this->assertTrue( Util::has_obj( 'Sos', $meta_box ) );
        $this->assertTrue( Util::has_value( 'setup_meta_boxes', $meta_box ) );
        
        $this->assertSame( 'sos', $meta_box[ 0 ]->post_type );
        $this->assertSame( null, $meta_box[ 0 ]->messages );
    }

    public function test_labels () {
        global $wp_post_types;
        $this->sos->create_post_type();
        $this->assertarrayHasKey( 'sos', $wp_post_types );
        $sos_type = $wp_post_types[ 'sos' ];
        $labels = $sos_type->labels;
        
        $this->assertSame( 'Sos Lockers', $labels->name );
        $this->assertSame( 'Sos Locker', $labels->singular_name );
        $this->assertSame( 'Share on Social', $labels->menu_name );
        $this->assertSame( 'Add New', $labels->add_new );
        $this->assertSame( 'Add New Locker', $labels->add_new_item );
        $this->assertSame( 'Edit', $labels->edit );
        $this->assertSame( 'Edit Locker', $labels->edit_item );
        $this->assertSame( 'New Locker', $labels->new_item );
        $this->assertSame( 'Lockers', $labels->all_items );
        $this->assertSame( '', $labels->view );
        $this->assertSame( '', $labels->view_item );
    }

    public function test_labels_translation () {
        global $wp_post_types;
        Util::change_locale( 'eo_FR' );
        $this->sos->create_post_type();
        $this->assertarrayHasKey( 'sos', $wp_post_types );
        $sos_type = $wp_post_types[ 'sos' ];
        $labels = $sos_type->labels;
        
        $this->assertSame( 'Espéranto-France Sos Lockers', $labels->name );
        $this->assertSame( 'Espéranto-France Sos Locker', 
                $labels->singular_name );
        $this->assertSame( 'Espéranto-France Share on Social', 
                $labels->menu_name );
        $this->assertSame( 'Espéranto-France Add New', $labels->add_new );
        $this->assertSame( 'Espéranto-France Add New Locker', 
                $labels->add_new_item );
        $this->assertSame( 'Espéranto-France Edit', $labels->edit );
        $this->assertSame( 'Espéranto-France Edit Locker', $labels->edit_item );
        $this->assertSame( 'Espéranto-France New Locker', $labels->new_item );
        $this->assertSame( 'Espéranto-France Lockers', $labels->all_items );
        $this->assertSame( '', $labels->view );
        $this->assertSame( '', $labels->view_item );
    }

    public function test_set_post_columns () {
        $columns = $this->sos->set_post_columns( null );
        $this->assertCount( 5, $columns );
        $this->assertSame( '<input type="checkbox" />', $columns[ 'cb' ] );
        $this->assertSame( 'Locker Title', $columns[ 'title' ] );
        $this->assertSame( 'Locker ID', $columns[ 'locker_id' ] );
        $this->assertSame( 'Created by', $columns[ 'author' ] );
        $this->assertSame( 'Date', $columns[ 'date' ] );
    }

    public function test_set_post_columns_translations () {
        Util::change_locale( 'eo_FR' );
        $columns = $this->sos->set_post_columns( null );
        $this->assertCount( 5, $columns );
        $this->assertSame( '<input type="checkbox" />', $columns[ 'cb' ] );
        $this->assertSame( 'Espéranto-France Locker Title', 
                $columns[ 'title' ] );
        $this->assertSame( 'Espéranto-France Locker ID', 
                $columns[ 'locker_id' ] );
        $this->assertSame( 'Espéranto-France Created by', $columns[ 'author' ] );
        $this->assertSame( 'Espéranto-France Date', $columns[ 'date' ] );
    }

    public function test_setup_meta_boxes_normal () {
        global $wp_meta_boxes;
        $this->assertFalse( isset( $wp_meta_boxes ) ); // wp_meta_boxes is not
                                                       // set
        
        $this->sos->setup_meta_boxes( null );
        $this->assertarrayHasKey( 'sos', $wp_meta_boxes );
        $high = $wp_meta_boxes[ 'sos' ][ 'normal' ][ 'high' ];
        $this->assertCount( 3, $high );
        $this->assertFalse( $high[ 'slider_sectionid' ] );
        $this->assertFalse( $high[ 'layout_sectionid' ] );
        $this->assertarrayHasKey( 'locker_meta_box', $high );
        $mb = $high[ 'locker_meta_box' ];
        $this->assertSame( 'locker_meta_box', $mb[ 'id' ] );
        $this->assertSame( 'Share Locker', $mb[ 'title' ] );
        
        $this->assertTrue( Util::has_obj( 'Sos', $mb[ 'callback' ] ) );
        $this->assertSame( 'sos', $mb[ 'callback' ][ 0 ]->post_type );
        $this->assertNull( $mb[ 'callback' ][ 0 ]->messages );
        $this->assertSame( 'render_locker_meta_box', $mb[ 'callback' ][ 1 ] );
    }

    public function test_setup_meta_boxes_normal_translate () {
        global $wp_meta_boxes;
        
        Util::change_locale( 'eo_FR' );
        $this->sos->setup_meta_boxes( null );
        $this->assertarrayHasKey( 'sos', $wp_meta_boxes );
        $high = $wp_meta_boxes[ 'sos' ][ 'normal' ][ 'high' ];
        $this->assertCount( 3, $high );
        $this->assertFalse( $high[ 'slider_sectionid' ] );
        $this->assertFalse( $high[ 'layout_sectionid' ] );
        $this->assertarrayHasKey( 'locker_meta_box', $high );
        $mb = $high[ 'locker_meta_box' ];
        $this->assertSame( 'locker_meta_box', $mb[ 'id' ] );
        $this->assertSame( 'Espéranto-France Share Locker', $mb[ 'title' ] ); // i18n
        
        $this->assertTrue( Util::has_obj( 'Sos', $mb[ 'callback' ] ) );
        $this->assertSame( 'sos', $mb[ 'callback' ][ 0 ]->post_type );
        $this->assertNull( $mb[ 'callback' ][ 0 ]->messages );
        $this->assertSame( 'render_locker_meta_box', $mb[ 'callback' ][ 1 ] );
    }

    public function test_setup_meta_boxes_normal_others () {
        global $wp_meta_boxes;
        
        $this->sos->setup_meta_boxes( null );
        $this->assertarrayHasKey( 'sos', $wp_meta_boxes );
        
        // core
        $area = $wp_meta_boxes[ 'sos' ][ 'normal' ][ 'core' ];
        $this->assertCount( 2, $area );
        $this->assertFalse( $area[ 'slider_sectionid' ] );
        $this->assertFalse( $area[ 'layout_sectionid' ] );
        
        // default
        $area = $wp_meta_boxes[ 'sos' ][ 'normal' ][ 'default' ];
        $this->assertCount( 2, $area );
        $this->assertFalse( $area[ 'slider_sectionid' ] );
        $this->assertFalse( $area[ 'layout_sectionid' ] );
        
        // low
        $area = $wp_meta_boxes[ 'sos' ][ 'normal' ][ 'low' ];
        $this->assertCount( 2, $area );
        $this->assertFalse( $area[ 'slider_sectionid' ] );
        $this->assertFalse( $area[ 'layout_sectionid' ] );
    }

    public function test_setup_meta_boxes_side () {
        global $wp_meta_boxes;
        
        $this->sos->setup_meta_boxes( null );
        $this->assertarrayHasKey( 'sos', $wp_meta_boxes );
        $side = $wp_meta_boxes[ 'sos' ][ 'side' ][ 'default' ];
        $this->assertCount( 1, $side );
        
        $this->assertarrayHasKey( 'codedrops_meta_box', $side );
        $mb = $side[ 'codedrops_meta_box' ];
        
        $this->assertSame( 'codedrops_meta_box', $mb[ 'id' ] );
        $this->assertSame( 'CodeDrops', $mb[ 'title' ] );
        $this->assertNull( $mb[ 'args' ] );
        $this->assertTrue( Util::has_obj( 'Sos', $mb[ 'callback' ] ) );
        $this->assertSame( 'sos', $mb[ 'callback' ][ 0 ]->post_type );
        $this->assertNull( $mb[ 'callback' ][ 0 ]->messages );
        $this->assertSame( 'render_codedrops_meta_box', $mb[ 'callback' ][ 1 ] );
    }

    public function test_render_post_columns () {
        global $post;
        $this->sos->create_post_type(); // add sos type
        $post = $this->create_post(); // set global post
                                      
        // test for dummy col
        ob_start();
        $this->sos->render_post_columns( 'dummy col' );
        $result = ob_get_contents();
        ob_end_clean();
        $this->assertSame( '', $result );
        
        // test for locker_id col
        ob_start();
        $this->sos->render_post_columns( 'locker_id' );
        $result = ob_get_contents();
        ob_end_clean();
        $this->assertSame( 'test locker', $result );
    }

    public function test_get_table () {
        global $post;
        $this->sos->create_post_type(); // add sos type
        $post = $this->create_post(); // set global post
        
        $result = $this->sos->get_table();
        
        $expected = $this->get_test_table();
        
        $this->assertSame( trim( $expected ), trim( $result ) );
    }

    public function test_get_table_translate () {
        global $post;
        $this->sos->create_post_type();
        $post = $this->create_post();
        
        Util::change_locale( 'eo_FR' );
        $result = $this->sos->get_table();
        
        $expected = $this->get_test_table( 'Espéranto-France' );
        
        $this->assertSame( trim( $expected ), trim( $result ) );
    }

    public function test_render_locker_meta_box () {
        global $post;
        $this->sos->create_post_type();
        $post = $this->create_post();
        
        ob_start();
        $this->sos->render_locker_meta_box();
        $result = ob_get_contents();
        ob_end_clean();
        
        // replace nonce with a constant
        $result = preg_replace( '#name="locker_nonce" value=".*"#U', 
                'name="locker_nonce" value="test nonce"', $result );
        
        // starts with nonce
        $this->assertSame( 0, strpos( $result, $this->get_test_nonce() ) );
        $this->assertNotFalse( 
                strpos( $result, trim( $this->get_test_table( '' ) ) ) ); // contains
        $this->assertNotFalse( 
                strpos( $result, trim( $this->editor_snippet() ) ) );
    }

    function test_render_codedrops_meta_box () {
        ob_start();
        $result = $this->sos->render_codedrops_meta_box();
        $result = ob_get_contents();
        ob_end_clean();
        
        $expected = $this->get_test_codedrops_metabox();
        $this->assertSame( trim( $expected ), trim( $result ) );
    }

    function test_render_codedrops_meta_box_translate () {
        Util::change_locale( 'eo_FR' );
        ob_start();
        $result = $this->sos->render_codedrops_meta_box();
        $result = ob_get_contents();
        ob_end_clean();
        
        $expected = $this->get_test_codedrops_metabox( 'Espéranto-France' );
        $this->assertSame( trim( $expected ), trim( $result ) );
    }

    function test_checked () {
        $this->assertSame( 'checked', $this->sos->checked( 'test', 'test' ) );
        $this->assertSame( '', $this->sos->checked( '', 'test' ) );
        $this->assertSame( '', $this->sos->checked( 'test', '' ) );
    }

    public function test_add_editor () {
        global $post;
        $this->sos->create_post_type();
        $post = $this->create_post();
        
        ob_start();
        $this->sos->add_editor();
        $editor = ob_get_contents(); // full code
        ob_end_clean();
        $snippet = $this->editor_snippet(); // essential part
        $this->assertNotFalse( strpos( $editor, $snippet ) );
        
        // test kses
        update_post_meta( $post->ID, 'locker_text', 
                'locker text value<php evilscript() ?>' );
        ob_start();
        $this->sos->add_editor();
        $editor = ob_get_contents();
        ob_end_clean();
        $snippet = $this->editor_snippet();
        $this->assertNotFalse( strpos( $editor, $snippet ) );
    }

    function test_save_post_autosave () {
        // TODO - tough to implement
    }

    function test_save_post_nonce () {
        global $post;
        $this->sos->create_post_type();
        $post = $this->create_post();
        $this->assertSame( 'test locker', 
                get_post_meta( $post->ID, 'locker_id', true ) );
        
        // nonce not set
        $_POST[ 'locker_id' ] = 'dummy locker';
        $this->sos->save_post( $post->ID ); // should not save meta - locker id
        $this->assertSame( 'test locker', 
                get_post_meta( $post->ID, 'locker_id', true ) );
        
        // set wrong nonce
        $_POST[ 'locker_nonce' ] = '123456';
        $_POST[ 'locker_id' ] = 'dummy locker';
        $this->sos->save_post( $post->ID ); // should not save meta - locker id
        $this->assertSame( 'test locker', 
                get_post_meta( $post->ID, 'locker_id', true ) );
        
        if ( false == is_multisite() ) {
            // set proper nonce but no cap
            Util::set_cap( 'edit_posts', false );
            $nonce = wp_create_nonce( 'save_locker' );
            $_POST[ 'locker_nonce' ] = $nonce;
            $_POST[ 'locker_id' ] = 'dummy locker';
            $this->sos->save_post( $post->ID ); // should not save meta - locker
                                                // id
            $this->assertSame( 'test locker', 
                    get_post_meta( $post->ID, 'locker_id', true ) );
            
            // set proper nonce but no cap
            Util::set_cap( 'edit_posts', true );
            $nonce = wp_create_nonce( 'save_locker' );
            $_POST[ 'locker_nonce' ] = $nonce;
            $_POST[ 'locker_id' ] = 'dummy locker';
            $this->sos->save_post( $post->ID ); // should save meta - locker id
            $this->assertSame( 'dummy locker', 
                    get_post_meta( $post->ID, 'locker_id', true ) );
        } else {
            $blogs = wp_get_sites();
            $this->assertCount( 1, $blogs );
            
            // remove capability - edit_posts
            $user_id = $this->add_user( 'testuser' );
            wp_set_current_user( $user_id );
            add_user_to_blog( $blogs[ 0 ][ 'blog_id' ], $user_id, 'editor' );
            
            // set proper nonce but no cap
            switch_to_blog( $blogs[ 0 ][ 'blog_id' ] );
            Util::set_cap( 'edit_posts', false );
            $nonce = wp_create_nonce( 'save_locker' );
            $_POST[ 'locker_nonce' ] = $nonce;
            $_POST[ 'locker_id' ] = 'dummy locker';
            $this->sos->save_post( $post->ID ); // should not save meta - locker
                                                // id
            $this->assertSame( 'test locker', 
                    get_post_meta( $post->ID, 'locker_id', true ) );
            
            // set proper nonce but no cap
            switch_to_blog( $blogs[ 0 ][ 'blog_id' ] );
            Util::set_cap( 'edit_posts', true );
            $nonce = wp_create_nonce( 'save_locker' );
            $_POST[ 'locker_nonce' ] = $nonce;
            $_POST[ 'locker_id' ] = 'dummy locker';
            $this->sos->save_post( $post->ID ); // should save meta - locker id
            $this->assertSame( 'dummy locker', 
                    get_post_meta( $post->ID, 'locker_id', true ) );
        }
    }

    function test_save_post_caps () {
        global $post;
        $this->sos->create_post_type();
        $post = $this->create_post();
        $this->assertSame( 'test locker', 
                get_post_meta( $post->ID, 'locker_id', true ) );
        
        if ( false == is_multisite() ) {
            // remove capability - edit_posts
            Util::set_cap( 'edit_posts', false );
            $nonce = wp_create_nonce( 'save_locker' );
            $_POST[ 'locker_nonce' ] = $nonce;
            $_POST[ 'locker_id' ] = 'dummy locker';
            $this->sos->save_post( $post->ID ); // should not save meta - locker
                                                // id
            $this->assertSame( 'test locker', 
                    get_post_meta( $post->ID, 'locker_id', true ) );
            
            // add cap - edit_posts
            Util::set_cap( 'edit_posts', true );
            $nonce = wp_create_nonce( 'save_locker' );
            $_POST[ 'locker_nonce' ] = $nonce;
            $_POST[ 'locker_id' ] = 'dummy locker';
            $this->sos->save_post( $post->ID ); // should save meta - locker id
            $this->assertSame( 'dummy locker', 
                    get_post_meta( $post->ID, 'locker_id', true ) );
        } else {
            $blogs = wp_get_sites();
            $this->assertCount( 1, $blogs );
            
            // remove capability - edit_posts
            $user_id = $this->add_user( 'testuser' );
            wp_set_current_user( $user_id );
            add_user_to_blog( $blogs[ 0 ][ 'blog_id' ], $user_id, 'editor' );
            
            switch_to_blog( $blogs[ 0 ][ 'blog_id' ] );
            Util::set_cap( 'edit_posts', false );
            $nonce = wp_create_nonce( 'save_locker' );
            $_POST[ 'locker_nonce' ] = $nonce;
            $_POST[ 'locker_id' ] = 'dummy locker';
            $this->sos->save_post( $post->ID ); // should not save meta - locker
                                                // id
            $this->assertSame( 'test locker', 
                    get_post_meta( $post->ID, 'locker_id', true ) );
            restore_current_blog();
            
            // add cap - edit_posts
            switch_to_blog( $blogs[ 0 ][ 'blog_id' ] );
            Util::set_cap( 'edit_posts', true );
            $nonce = wp_create_nonce( 'save_locker' );
            $_POST[ 'locker_nonce' ] = $nonce;
            $_POST[ 'locker_id' ] = 'dummy locker';
            $this->sos->save_post( $post->ID ); // should save meta - locker id
            $this->assertSame( 'dummy locker', 
                    get_post_meta( $post->ID, 'locker_id', true ) );
            restore_current_blog();
        }
    }

    private function add_user ( $login_name ) {
        $userdata = array(
                'user_login' => $login_name,
                'user_url' => 'localhost',
                'user_pass' => NULL
        );
        return $this->factory->user->create_object( $userdata );
    }

    function test_save_post () {
        global $post;
        $this->sos->create_post_type();
        $post = $this->create_post();
        $this->assertSame( 'test locker', 
                get_post_meta( $post->ID, 'locker_id', true ) );
        delete_post_meta( $post->ID, 'locker_id' );
        delete_post_meta( $post->ID, 'locker_text' );
        
        Util::set_cap( 'edit_posts', true );
        $nonce = wp_create_nonce( 'save_locker' );
        
        $_POST[ 'locker_nonce' ] = $nonce;
        $_POST[ 'locker_id' ] = 'locker id';
        $_POST[ 'share_target' ] = 'page';
        $_POST[ 'shareon_fb' ] = '1';
        $_POST[ 'shareon_gplus' ] = '1';
        $_POST[ 'shareon_twitter' ] = '1';
        $_POST[ 'locker_text' ] = 'locker text';
        $this->sos->save_post( $post->ID );
        
        $meta = get_post_meta( $post->ID );
        
        $this->assertCount( 6, $meta );
        $this->assertSame( 'locker id', $meta[ 'locker_id' ][ 0 ] );
        $this->assertSame( 'page', $meta[ 'share_target' ][ 0 ] );
        $this->assertSame( '1', $meta[ 'shareon_fb' ][ 0 ] );
        $this->assertSame( '1', $meta[ 'shareon_gplus' ][ 0 ] );
        $this->assertSame( '1', $meta[ 'shareon_twitter' ][ 0 ] );
        $this->assertSame( 'locker text', $meta[ 'locker_text' ][ 0 ] );
        $this->assertFalse( get_transient( 'sos_duplicate_id' ) );
        $this->assertFalse( get_transient( 'sos_invalid_id' ) );
    }

    function test_save_post_update () {
        global $post;
        $this->sos->create_post_type();
        $post = $this->create_post();
        
        Util::set_cap( 'edit_posts', true );
        $nonce = wp_create_nonce( 'save_locker' );
        
        $_POST[ 'locker_nonce' ] = $nonce;
        $_POST[ 'locker_id' ] = 'test locker';
        $this->sos->save_post( $post->ID );
        
        $meta = get_post_meta( $post->ID );
        
        $this->assertCount( 6, $meta );
        $this->assertSame( 'test locker', $meta[ 'locker_id' ][ 0 ] );
        $this->assertFalse( get_transient( 'sos_duplicate_id' ) );
        $this->assertFalse( get_transient( 'sos_invalid_id' ) );
    }

    function test_save_post_invalid () {
        global $post;
        $this->sos->create_post_type();
        $post = $this->create_post();
        
        Util::set_cap( 'edit_posts', true );
        $nonce = wp_create_nonce( 'save_locker' );
        
        $_POST[ 'locker_nonce' ] = $nonce;
        $_POST[ 'locker_id' ] = '';
        $this->sos->save_post( $post->ID );
        
        $meta = get_post_meta( $post->ID );
        
        $this->assertCount( 6, $meta );
        $this->assertSame( '', $meta[ 'locker_id' ][ 0 ] );
        $this->assertFalse( get_transient( 'sos_duplicate_id' ) ); // not set
        $this->assertTrue( get_transient( 'sos_invalid_id' ) ); // set
    }

    function test_save_post_duplicate () {
        global $post;
        $this->sos->create_post_type();
        $post = $this->create_post();
        $duplicate = $this->create_post();
        // save_post is yet save meta, so delete the meta
        delete_post_meta( $duplicate->ID, 'locker_id' );
        
        Util::set_cap( 'edit_posts', true );
        $nonce = wp_create_nonce( 'save_locker' );
        
        $_POST[ 'locker_nonce' ] = $nonce;
        $_POST[ 'locker_id' ] = 'test locker'; // try to save duplicate locker
                                               // id
        $this->sos->save_post( $duplicate->ID );
        $meta = get_post_meta( $duplicate->ID );
        
        $this->assertCount( 6, $meta );
        $this->assertSame( '', $meta[ 'locker_id' ][ 0 ] );
        $this->assertTrue( get_transient( 'sos_duplicate_id' ) ); // set
        $this->assertFalse( get_transient( 'sos_invalid_id' ) ); // not set
    }

    function test_is_duplicate_locker () {
        global $post;
        $this->sos->create_post_type();
        $post = $this->create_post();
        $duplicate = $this->create_post();
        delete_post_meta( $duplicate->ID, 'locker_id' );
        
        // test when locker with a locker_id is exists
        $_POST[ 'locker_id' ] = 'test locker';
        $this->assertFalse( $this->sos->is_duplicate_locker( $post->ID ) );
        $this->assertTrue( $this->sos->is_duplicate_locker( $duplicate->ID ) );
        
        // test when no locker with a locker_id exits
        delete_post_meta( $post->ID, 'locker_id' );
        $_POST[ 'locker_id' ] = 'test locker';
        $this->assertFalse( $this->sos->is_duplicate_locker( $post->ID ) );
        $this->assertFalse( $this->sos->is_duplicate_locker( $duplicate->ID ) );
    }

    function test_sos_admin_notice_duplicate () {
        ob_start();
        $this->sos->sos_admin_notice();
        $result = ob_get_contents();
        ob_end_clean();
        $expected = '';
        $this->assertSame( trim( $expected ), trim( $result ) );
        
        set_transient( 'sos_duplicate_id', true, 10 );
        ob_start();
        $this->sos->sos_admin_notice();
        $result = ob_get_contents();
        ob_end_clean();
        $expected = '<div class="error"><p>Duplicate Locker ID! Save the locker with an unique Locker ID. ';
        $expected .= 'Unable to activate locker.</p></div>';
        $this->assertSame( trim( $expected ), trim( $result ) );
    }

    function test_sos_admin_notice_duplicate_translate () {
        ob_start();
        $this->sos->sos_admin_notice();
        $result = ob_get_contents();
        ob_end_clean();
        $expected = '';
        $this->assertSame( trim( $expected ), trim( $result ) );
        
        Util::change_locale( 'eo_FR' );
        set_transient( 'sos_duplicate_id', true, 10 );
        ob_start();
        $this->sos->sos_admin_notice();
        $result = ob_get_contents();
        ob_end_clean();
        $expected = '<div class="error"><p>Espéranto-France Duplicate Locker ID! Save the locker with an unique Locker ID. ';
        $expected .= 'Espéranto-France Unable to activate locker.</p></div>';
        $this->assertSame( trim( $expected ), trim( $result ) );
    }

    function test_sos_admin_notice_invalid () {
        ob_start();
        $this->sos->sos_admin_notice();
        $result = ob_get_contents();
        ob_end_clean();
        $expected = '';
        $this->assertSame( trim( $expected ), trim( $result ) );
        
        set_transient( 'sos_invalid_id', true, 10 );
        ob_start();
        $this->sos->sos_admin_notice();
        $result = ob_get_contents();
        ob_end_clean();
        $expected = '<div class="error"><p>Invalid Locker ID! Unable to activate locker.</p></div>';
        $this->assertSame( trim( $expected ), trim( $result ) );
    }

    function test_sos_admin_notice_invalid_translate () {
        ob_start();
        $this->sos->sos_admin_notice();
        $result = ob_get_contents();
        ob_end_clean();
        $expected = '';
        $this->assertSame( trim( $expected ), trim( $result ) );
        
        Util::change_locale( 'eo_FR' );
        set_transient( 'sos_invalid_id', true, 10 );
        ob_start();
        $this->sos->sos_admin_notice();
        $result = ob_get_contents();
        ob_end_clean();
        $expected = '<div class="error"><p>Espéranto-France Invalid Locker ID! ';
        $expected .= 'Espéranto-France Unable to activate locker.</p></div>';
        $this->assertSame( trim( $expected ), trim( $result ) );
    }

    function test_save_post_sanitize () {
        global $post;
        $this->sos->create_post_type();
        $post = $this->create_post();
        $this->assertSame( 'test locker', 
                get_post_meta( $post->ID, 'locker_id', true ) );
        delete_post_meta( $post->ID, 'locker_id' );
        delete_post_meta( $post->ID, 'locker_text' );
        
        Util::set_cap( 'edit_posts', true );
        $nonce = wp_create_nonce( 'save_locker' );
        
        $_POST[ 'locker_nonce' ] = $nonce;
        $_POST[ 'locker_id' ] = 'locker id<h1><php? evil() ?>';
        $_POST[ 'share_target' ] = 'page<h1><php? evil() ?>';
        $_POST[ 'shareon_fb' ] = 'xyz<php? evil() ?>';
        $_POST[ 'shareon_gplus' ] = 'xyz<php? evil() ?>';
        $_POST[ 'shareon_twitter' ] = 'xyz<php? evil() ?>';
        $_POST[ 'locker_text' ] = 'locker text<h1><php? evil() ?>';
        $this->sos->save_post( $post->ID );
        
        $meta = get_post_meta( $post->ID );
        
        $this->assertCount( 6, $meta );
        $this->assertSame( 'locker id', $meta[ 'locker_id' ][ 0 ] );
        $this->assertSame( 'page', $meta[ 'share_target' ][ 0 ] );
        $this->assertSame( '0', $meta[ 'shareon_fb' ][ 0 ] );
        $this->assertSame( '0', $meta[ 'shareon_gplus' ][ 0 ] );
        $this->assertSame( '0', $meta[ 'shareon_twitter' ][ 0 ] );
        $this->assertSame( 'locker text<h1>', $meta[ 'locker_text' ][ 0 ] );
    }

    public function test_sanitized_int () {
        // $_POST is not set
        $this->assertSame( 0, $this->sos->sanitized_int( 'i' ) );
        
        // set $_POST
        $_POST[ 'i' ] = 0;
        $this->assertSame( 0, $this->sos->sanitized_int( 'i' ) );
        $_POST[ 'i' ] = 1;
        $this->assertSame( 1, $this->sos->sanitized_int( 'i' ) );
        $_POST[ 'i' ] = - 1;
        $this->assertSame( 1, $this->sos->sanitized_int( 'i' ) );
        $_POST[ 'i' ] = '1';
        $this->assertSame( 1, $this->sos->sanitized_int( 'i' ) );
        $_POST[ 'i' ] = 'xyz';
        $this->assertSame( 0, $this->sos->sanitized_int( 'i' ) );
        $_POST[ 'i' ] = '';
        $this->assertSame( 0, $this->sos->sanitized_int( 'i' ) );
        $_POST[ 'i' ] = null;
        $this->assertSame( 0, $this->sos->sanitized_int( 'i' ) );
    }

    public function test_sanitized_text () {
        // $_POST is not set
        $this->assertSame( '', $this->sos->sanitized_text( 't' ) );
        
        $_POST[ 't' ] = 'test';
        $this->assertSame( 'test', $this->sos->sanitized_text( 't' ) );
        $_POST[ 't' ] = 'test <h1>';
        $this->assertSame( 'test', $this->sos->sanitized_text( 't' ) );
        $_POST[ 't' ] = 'test <?php ?>';
        $this->assertSame( 'test', $this->sos->sanitized_text( 't' ) );
        $_POST[ 't' ] = '';
        $this->assertSame( '', $this->sos->sanitized_text( 't' ) );
        $_POST[ 't' ] = null;
        $this->assertSame( '', $this->sos->sanitized_text( 't' ) );
    }

    public function test_sanitized_html () {
        // $_POST is not set
        $this->assertSame( '', $this->sos->sanitized_html( 't' ) );
        
        $_POST[ 't' ] = 'test';
        $this->assertSame( 'test', $this->sos->sanitized_html( 't' ) );
        $_POST[ 't' ] = 'test <h1>';
        $this->assertSame( 'test <h1>', $this->sos->sanitized_html( 't' ) );
        $_POST[ 't' ] = 'test <table></table>';
        $this->assertSame( 'test <table></table>', 
                $this->sos->sanitized_html( 't' ) );
        $_POST[ 't' ] = 'test <?php ?>';
        $this->assertSame( 'test ', $this->sos->sanitized_html( 't' ) );
        $_POST[ 't' ] = '';
        $this->assertSame( '', $this->sos->sanitized_html( 't' ) );
        $_POST[ 't' ] = null;
        $this->assertSame( '', $this->sos->sanitized_html( 't' ) );
    }

    public function test_hide_minor_publish () {
        global $current_screen;
        
        // setup admin screen
        global $current_screen;
        $this->assertNull( $current_screen );
        
        $screen = WP_Screen::get( 'admin_init' );
        $current_screen = $screen;
        
        // for page and post - don't hide minor-publishing section
        $expected = '';
        $screen->id = 'page';
        ob_start();
        $this->sos->hide_minor_publish();
        $result = ob_get_contents();
        ob_end_clean();
        $this->assertSame( $expected, $result );
        
        $screen->id = 'post';
        ob_start();
        $this->sos->hide_minor_publish();
        $result = ob_get_contents();
        ob_end_clean();
        $this->assertSame( $expected, $result );
        
        // for sos - we hide minor-publishing section through css style
        $screen->id = $this->sos->post_type;
        $expected = '<style>#minor-publishing { display: none; }</style>';
        ob_start();
        $this->sos->hide_minor_publish();
        $result = ob_get_contents();
        ob_end_clean();
        $this->assertSame( $expected, $result );
        
        // revert back
        $current_screen = null;
    }

    public function test_filter_published_message () {
        $messages = array(
                'post' => array()
        );
        $result = $this->sos->filter_published_message( $messages );
        $this->assertCount( 1, $result );
        $this->assertCount( 2, $result[ 'post' ] );
        $this->assertSame( 'Share Locker updated', $result[ 'post' ][ 1 ] );
        $this->assertSame( 'Share Locker saved', $result[ 'post' ][ 6 ] );
    }

    public function test_filter_published_message_translate () {
        Util::change_locale( 'eo_FR' );
        $messages = array(
                'post' => array()
        );
        $result = $this->sos->filter_published_message( $messages );
        $this->assertCount( 1, $result );
        $this->assertCount( 2, $result[ 'post' ] );
        $this->assertSame( 'Espéranto-France Share Locker updated', 
                $result[ 'post' ][ 1 ] );
        $this->assertSame( 'Espéranto-France Share Locker saved', 
                $result[ 'post' ][ 6 ] );
    }
    
    // some handy routines
    private function get_locker_text ( $lang_str = '' ) {
        ($lang_str == '') ? $lang_str : $lang_str .= ' ';
        $text1 = $lang_str . 'Content is Locked';
        $text2 = $lang_str . 'Share to unlock the content';
        $text = <<< EOD
&nbsp;
<p style="text-align: center;"><strong>
<span style="font-size: 16pt; color: #993300; font-family: impact,chicago;">
{$text1} !</span></strong></p>
&nbsp;
<p style="text-align: center;">
<span style="font-size: 14pt; color: #993300; font-family: impact,chicago;">
{$text2}.</span></p>
&nbsp;
EOD;
        return $text;
    }

    private function create_post () {
        $args = array(
                'post_name' => 'sos post',
                'post_title' => 'sos post title',
                'post_status' => 'publish',
                'post_type' => 'sos',
                'post_content' => 'sos post content'
        );
        $post_id = $this->factory->post->create( $args );
        add_post_meta( $post_id, 'locker_id', 'test locker' );
        add_post_meta( $post_id, 'locker_text', 'locker text value' );
        return get_post( $post_id );
    }

    private function editor_snippet () {
        $str = '<div id="wp-locker_text-editor-container" class="wp-editor-container">';
        $str .= '<textarea class="wp-editor-area" rows="10" cols="40" name="locker_text" id="locker_text">';
        $str .= 'locker text value</textarea></div>';
        return $str;
    }

    private function get_test_nonce () {
        $nonce = '<input type="hidden" id="locker_nonce" name="locker_nonce" value="test nonce" />';
        $nonce .= '<input type="hidden" name="_wp_http_referer" value="" />';
        return $nonce;
    }

    private function get_test_table ( $lang_str = '' ) {
        $lang_str == '' ? $lang_str : $lang_str .= ' ';
        
        $table = <<<EOD
        <div>Use Context Help (top right corner) for field level help.</div>
		<table class="form-table">
		<tr>
		<th scope="row"><label for="locker_id">{$lang_str}Locker ID</label></th>
    	<td><input type="text" name="locker_id" id="locker_id" value="test locker" /></td>
    	</tr><tr>
    	<th scope="row"><label for="locker_shareon">{$lang_str}Share on</label></th>
    	<td>
    	   <input type="checkbox" id="shareon_fb" name="shareon_fb" value="1"
    				 >{$lang_str}Facebook</input>
			<input type="checkbox" id="shareon_gplus" name="shareon_gplus" value="1"
    				 >{$lang_str}Google+</input>
    		<input type="checkbox" id="shareon_twitter" name="shareon_twitter" value="1"
    				 >{$lang_str}Twitter</input>
    	</td>
    	</tr><tr>
    	<th scope="row"><label for="share_target">{$lang_str}Share [Which URL]</label></th>
		<td><input type="radio" id="share_target" name="share_target" value="page"
		           	checked > {$lang_str}Page </input>
		<input type="radio" id="share_target" name="share_target" value="parent"
					 > {$lang_str}Parent Page</input>
		<input type="radio" id="share_target" name="share_target" value="site"
					 > {$lang_str}Site</input></td>
    	</tr><tr>
    	<th scope="row"><label for="locker_text">{$lang_str}Display Text</label></th>
		<td>&nbsp;</td>
    	</tr>
        </table>
EOD;
        return $table;
    }

    private function get_test_codedrops_metabox ( $lang_str = '' ) {
        $lang_str == '' ? $lang_str : $lang_str .= ' ';
        $html = <<<EOD
        <p>&nbsp;</p>
		<p>{$lang_str}Discover how this plugin is developed ! Learn WordPress Plugins Development with our companion tutorial.</p>		
		<p><h3><a href="http://www.codedrops.in/wordpress-tutorial" target="_blank">{$lang_str}CodeDrops WordPress Tutorial</a></h3></p>					 	
EOD;
        return $html;
    }
}
