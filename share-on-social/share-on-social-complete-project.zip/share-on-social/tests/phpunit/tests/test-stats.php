<?php

class Test_Stats extends WP_UnitTestCase {

    var $sos_stats;

    public static function tearDownAfterClass () {
        remove_action( 'shutdown', 'Sos_Helper::output_debug_data' );
    }

    public function setUp () {
        parent::setUp();
        
        require_once ('admin/class-stats.php');
        $this->sos_stats = new Sos_Stats();
        
        wp_set_current_user( 1 );
        Util::set_admin_role( true );
    }

    public function teardown () {
        parent::teardown();
        wp_deregister_script( 'sos_chart_script' );
        wp_deregister_script( 'sos_google_api' );
        unload_textdomain( 'sos-domain' );
        
        global $submenu;
        if ( isset( $submenu[ 'edit.php?post_type=sos' ] ) ) {
            unset( $submenu[ 'edit.php?post_type=sos' ] );
        }
    }

    public function test_setup () {
        $this->assertFalse( 
                Util::has_action( 'admin_menu', $this->sos_stats, 
                        'register_stats_page' ) );
        $this->assertFalse( 
                Util::has_action( 'admin_init', $this->sos_stats, 
                        'init_chart_scripts' ) );
        
        $this->sos_stats->setup();
        
        $this->assertTrue( 
                Util::has_action( 'admin_menu', $this->sos_stats, 
                        'register_stats_page' ) );
        $this->assertTrue( 
                Util::has_action( 'admin_init', $this->sos_stats, 
                        'init_chart_scripts' ) );
    }

    public function test_init_chart_scripts () {
        $this->assertFalse( wp_script_is( 'sos_google_api', 'registered' ) );
        $this->assertFalse( wp_script_is( 'sos_chart_script', 'registered' ) );
        
        $this->sos_stats->init_chart_scripts();
        
        $this->assertTrue( wp_script_is( 'sos_google_api', 'registered' ) );
        $this->assertTrue( wp_script_is( 'sos_chart_script', 'registered' ) );
    }

    public function test_enqueue_chart_scripts () {
        // register but test false for enqueue
        $this->sos_stats->init_chart_scripts();
        $this->assertFalse( wp_script_is( 'sos_google_api', 'enqueued' ) );
        $this->assertFalse( wp_script_is( 'sos_chart_script', 'enqueued' ) );
        
        // next enqueue and test true
        $this->sos_stats->enqueue_chart_scripts();
        $this->assertTrue( wp_script_is( 'sos_google_api', 'enqueued' ) );
        $this->assertTrue( wp_script_is( 'sos_chart_script', 'enqueued' ) );
    }

    public function test_google_chart_api_url () {
        global $wp_scripts;
        
        $this->assertFalse( 
                isset( $wp_scripts->registered[ 'sos_google_api' ] ) );
        
        $this->sos_stats->init_chart_scripts();
        
        $url = $wp_scripts->registered[ 'sos_google_api' ]->src;
        $this->assertSame( $url, 'https://www.google.com/jsapi' );
    }

    public function test_localized_script () {
        global $wp_scripts;
        
        $this->sos_stats->init_chart_scripts();
        
        $data = $wp_scripts->get_data( 'sos_chart_script', 'data' );
        $data = substr( $data, strpos( $data, '{' ) - 1, 
                strpos( $data, '}' ) + 1 );
        $localized_data = json_decode( $data, true );
        $this->assertNull( $localized_data );
        
        $this->sos_stats->enqueue_chart_scripts();
        $data = $wp_scripts->get_data( 'sos_chart_script', 'data' );
        $data = substr( $data, strpos( $data, '{' ) - 1, 
                strpos( $data, '}' ) + 1 );
        $localized_data = json_decode( $data, true );
        $this->assertCount( 5, $localized_data );
        
        $this->assertarrayHasKey( 'ajax_url', $localized_data );
        $this->assertarrayHasKey( 'stats_nonce', $localized_data );
        $this->assertarrayHasKey( 'stats_summary_nonce', $localized_data );
        $this->assertarrayHasKey( 'summary_title', $localized_data );
        $this->assertarrayHasKey( 'stats_title', $localized_data );
        
        $this->assertSame( 'http://localhost/wp-admin/admin-ajax.php', 
                $localized_data[ 'ajax_url' ] );
        $this->assertSame( 'Summary', $localized_data[ 'summary_title' ] );
        $this->assertSame( 'Shares', $localized_data[ 'stats_title' ] );
        // verify returns 1 or 2 when valid else false
        $this->assertSame( 1, 
                wp_verify_nonce( $localized_data[ 'stats_nonce' ], 
                        'sos-get-stats' ) );
        $this->assertSame( 1, 
                wp_verify_nonce( $localized_data[ 'stats_summary_nonce' ], 
                        'sos-get-stats-summary' ) );
    }

    public function test_localized_script_translate () {
        global $wp_scripts;
        
        Util::change_locale( 'eo_FR' );
        
        $this->sos_stats->init_chart_scripts();
        $this->sos_stats->enqueue_chart_scripts();
        
        $data = $wp_scripts->get_data( 'sos_chart_script', 'data' );
        $data = substr( $data, strpos( $data, '{' ) - 1, 
                strpos( $data, '}' ) + 1 );
        $localized_data = json_decode( $data, true );
        $this->assertCount( 5, $localized_data );
        
        $this->assertarrayHasKey( 'ajax_url', $localized_data );
        $this->assertarrayHasKey( 'stats_nonce', $localized_data );
        $this->assertarrayHasKey( 'stats_summary_nonce', $localized_data );
        $this->assertarrayHasKey( 'summary_title', $localized_data );
        $this->assertarrayHasKey( 'stats_title', $localized_data );
        
        $this->assertSame( 'http://localhost/wp-admin/admin-ajax.php', 
                $localized_data[ 'ajax_url' ] );
        $this->assertSame( 'Espéranto-France Summary', 
                $localized_data[ 'summary_title' ] );
        $this->assertSame( 'Espéranto-France Shares', 
                $localized_data[ 'stats_title' ] );
        // verify returns 1 or 2 when valid else false
        $this->assertSame( 1, 
                wp_verify_nonce( $localized_data[ 'stats_nonce' ], 
                        'sos-get-stats' ) );
        $this->assertSame( 1, 
                wp_verify_nonce( $localized_data[ 'stats_summary_nonce' ], 
                        'sos-get-stats-summary' ) );
    }

    public function test_render_stats_page () {
        ob_start();
        $this->sos_stats->render_stats_page();
        $result = ob_get_contents();
        ob_end_clean();
        $expected = <<< EOD
        <h3>Share Stats</h3>
        <div>&nbsp;</div>
        <div id="summary_chart"></div>
        <div>&nbsp;</div>
        <div id="stats_chart"></div>    
EOD;
        $this->assertSame( trim( $expected ), trim( $result ) );
    }

    public function test_render_stats_page_translate () {
        Util::change_locale( 'eo_FR' );
        
        ob_start();
        $this->sos_stats->render_stats_page();
        $result = ob_get_contents();
        ob_end_clean();
        $expected = <<< EOD
        <h3>Espéranto-France Share Stats</h3>
        <div>&nbsp;</div>
        <div id="summary_chart"></div>
        <div>&nbsp;</div>
        <div id="stats_chart"></div>
EOD;
        $this->assertSame( trim( $expected ), trim( $result ) );
    }

    public function test_register_stats_page_submenu () {
        global $submenu;
        
        $this->assertFalse( isset( $submenu[ 'edit.php?post_type=sos' ] ) );
        
        $this->sos_stats->register_stats_page();
        
        $this->assertTrue( isset( $submenu[ 'edit.php?post_type=sos' ] ) );
        
        $settings = $submenu[ 'edit.php?post_type=sos' ];
        $this->assertSame( 'Statistics', $settings[ 0 ][ 0 ] );
        $this->assertSame( 'administrator', $settings[ 0 ][ 1 ] );
        $this->assertSame( 'sos_stats_page', $settings[ 0 ][ 2 ] );
        $this->assertSame( 'Share on Social Statistics', $settings[ 0 ][ 3 ] );
    }

    public function test_register_stats_page_submenu_translate () {
        global $submenu;
        
        $this->assertFalse( isset( $submenu[ 'edit.php?post_type=sos' ] ) );
        
        Util::change_locale( 'eo_FR' );
        $this->sos_stats->register_stats_page();
        
        $this->assertTrue( isset( $submenu[ 'edit.php?post_type=sos' ] ) );
        
        $settings = $submenu[ 'edit.php?post_type=sos' ];
        $this->assertSame( 'Espéranto-France Statistics', $settings[ 0 ][ 0 ] );
        $this->assertSame( 'administrator', $settings[ 0 ][ 1 ] );
        $this->assertSame( 'sos_stats_page', $settings[ 0 ][ 2 ] );
        $this->assertSame( 'Espéranto-France Share on Social Statistics', 
                $settings[ 0 ][ 3 ] );
    }

    public function test_register_stats_page_enqueue_scripts () {
        $hook_name = 'admin_print_scripts-admin_page_sos_stats_page';
        $this->assertFalse( 
                Util::has_action( $hook_name, $this->sos_stats, 
                        'enqueue_chart_scripts' ) );
        
        $this->sos_stats->register_stats_page();
        
        $this->assertTrue( 
                Util::has_action( $hook_name, $this->sos_stats, 
                        'enqueue_chart_scripts' ) );
    }
}