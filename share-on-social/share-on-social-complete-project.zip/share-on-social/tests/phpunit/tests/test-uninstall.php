<?php

class Test_Sos_Uninstall extends WP_UnitTestCase {

    var $sos;

    public function setup () {
        parent::setup();
        
        define( 'WP_UNINSTALL_PLUGIN', true );
        
        require_once 'uninstall.php';
        
        // create locker
        require_once 'admin/class-sos.php';
        Util::set_activate_plugins_cap( true );
        $this->sos = new Sos();
        $this->sos->create_post_type();
        Util::set_activate_plugins_cap( false );
        
        // add options
        add_option( 'sos_common_options', array() );
        add_option( 'sos_stats', array() );
        add_option( 'sos_stats_summary', array() );
        
        // add one more post of sos type to test delete sos posts
        $this->add_post( 'sos' );
    }

    public function teardown () {
        parent::setup();
        unload_textdomain( 'sos-domain' );
        
        delete_option( 'sos_stats' );
        delete_option( 'sos_stats_summary' );
        delete_option( 'sos_common_options' );
        sos_delete_sos_posts();
        
        Util::set_activate_plugins_cap( false );
    }

    public function test_sos_uninstall_sos_plugin_without_cap () {
        $this->assertEquals( 2, Util::count_posts( 'sos' ) );
        
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $stats = get_option( 'sos_stats' );
        $this->assertNotFalse( $stats );
        $stats_summary = get_option( 'sos_stats_summary' );
        $this->assertNotFalse( $stats_summary );
        
        // remove cap
        Util::set_cap( 'activate_plugins', false );
        sos_uninstall_sos_plugin();
        
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $this->assertEquals( 2, Util::count_posts( 'sos' ) );
        
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $stats = get_option( 'sos_stats' );
        $this->assertNotFalse( $stats );
        $stats_summary = get_option( 'sos_stats_summary' );
        $this->assertNotFalse( $stats_summary );
    }

    public function test_sos_uninstall_sos_plugin_with_cap () {
        $this->assertEquals( 2, Util::count_posts( 'sos' ) );
        
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $stats = get_option( 'sos_stats' );
        $this->assertNotFalse( $stats );
        $stats_summary = get_option( 'sos_stats_summary' );
        $this->assertNotFalse( $stats_summary );
        
        // enable cap
        Util::set_cap( 'activate_plugins', true );
        sos_uninstall_sos_plugin();
        
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertFalse( isset( $post_id ) );
        $this->assertEquals( 0, Util::count_posts( 'sos' ) );
        
        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        $stats = get_option( 'sos_stats' );
        $this->assertFalse( $stats );
        $stats_summary = get_option( 'sos_stats_summary' );
        $this->assertFalse( $stats_summary );
    }

    public function test_sos_delete_sos_posts () {
        
        // TODO debug why post added to a blog is also get counted in all blogs
        $this->add_post( 'post' );
        
        $this->assertEquals( 2, Util::count_posts( 'sos' ) );
        $this->assertEquals( 1, Util::count_posts( 'post' ) );
        
        sos_delete_sos_posts();
        
        $this->assertEquals( 0, Util::count_posts( 'sos' ) );
        $this->assertEquals( 1, Util::count_posts( 'post' ) );
    }

    public function test_sos_delete_sos_options () {
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $stats = get_option( 'sos_stats' );
        $this->assertNotFalse( $stats );
        $stats_summary = get_option( 'sos_stats_summary' );
        $this->assertNotFalse( $stats_summary );
        
        sos_delete_sos_options();
        
        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        $stats = get_option( 'sos_stats' );
        $this->assertFalse( $stats );
        $stats_summary = get_option( 'sos_stats_summary' );
        $this->assertFalse( $stats_summary );
    }

    private function add_post ( $post_type ) {
        $args = array(
                'post_name' => 'test locker',
                'post_title' => 'test locker',
                'post_status' => 'publish',
                'post_type' => $post_type,
                'post_content' => ''
        );
        $post_id = $this->factory->post->create( $args );
    }
}
