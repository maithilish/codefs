<?php

class Test_Sos_Options extends WP_UnitTestCase {

    var $sos_options;

    var $sos;

    public function setup () {
        parent::setup();
        
        require_once 'admin/class-sos.php';
        $this->sos = new Sos();
        
        require_once 'admin/class-options.php';
        $this->sos_options = new Sos_Options();
        
        wp_set_current_user( 1 );
        Util::set_admin_role( true );
    }

    public function teardown () {
        parent::teardown();
        unload_textdomain( 'sos-domain' );
        
        global $submenu;
        if ( isset( $submenu[ 'edit.php?post_type=sos' ] ) ) {
            unset( $submenu[ 'edit.php?post_type=sos' ] );
        }
        
        global $wp_settings_fields;
        if ( isset( $wp_settings_fields[ 'sos_common_options' ] ) ) {
            unset( $wp_settings_fields[ 'sos_common_options' ] );
        }
    }

    public function test_setup () {
        $this->assertFalse( 
                Util::has_action( 'admin_init', $this->sos_options, 
                        'init_common_options' ) );
        $this->assertFalse( 
                Util::has_action( 'admin_menu', $this->sos_options, 
                        'register_settings_page' ) );
        
        $this->sos_options->setup();
        
        $this->assertTrue( 
                Util::has_action( 'admin_init', $this->sos_options, 
                        'init_common_options' ) );
        $this->assertTrue( 
                Util::has_action( 'admin_menu', $this->sos_options, 
                        'register_settings_page' ) );
    }

    public function test_register_settings_page () {
        global $submenu;
        
        $this->assertFalse( isset( $submenu[ 'edit.php?post_type=sos' ] ) );
        $this->assertFalse( 
                Util::has_action( 'admin_page_sos_settings_page', 
                        $this->sos_options, 'render_settings_page' ) );
        
        $this->sos_options->register_settings_page();
        
        $this->assertTrue( isset( $submenu[ 'edit.php?post_type=sos' ] ) );
        $settings = $submenu[ 'edit.php?post_type=sos' ];
        $this->assertSame( 'Settings', $settings[ 0 ][ 0 ] );
        $this->assertSame( 'administrator', $settings[ 0 ][ 1 ] );
        $this->assertSame( 'sos_settings_page', $settings[ 0 ][ 2 ] );
        $this->assertSame( 'Common Options', $settings[ 0 ][ 3 ] );
        $this->assertTrue( 
                Util::has_action( 'admin_page_sos_settings_page', 
                        $this->sos_options, 'render_settings_page' ) );
    }

    public function test_register_settings_page_translate () {
        global $submenu;
        
        $this->assertFalse( 
                Util::has_action( 'admin_page_sos_settings_page', 
                        $this->sos_options, 'render_settings_page' ) );
        
        Util::change_locale( 'eo_FR' );
        $this->sos_options->register_settings_page();
        
        $this->assertTrue( isset( $submenu[ 'edit.php?post_type=sos' ] ) );
        $settings = $submenu[ 'edit.php?post_type=sos' ];
        $this->assertSame( 'Espéranto-France Settings', $settings[ 0 ][ 0 ] );
        $this->assertSame( 'administrator', $settings[ 0 ][ 1 ] );
        $this->assertSame( 'sos_settings_page', $settings[ 0 ][ 2 ] );
        $this->assertSame( 'Espéranto-France Common Options', 
                $settings[ 0 ][ 3 ] );
        $this->assertTrue( 
                Util::has_action( 'admin_page_sos_settings_page', 
                        $this->sos_options, 'render_settings_page' ) );
    }

    public function test_render_settings_page () {
        ob_start();
        $this->sos_options->render_settings_page();
        $result = ob_get_contents();
        ob_end_clean();
        // replace nonce with a constant
        $result = preg_replace( '#name="_wpnonce" value=".*"#U', 
                'name="_wpnonce" value="test nonce"', $result );
        $expected = $this->get_settings_page();
        $this->assertSame( trim( $expected ), trim( $result ) );
    }

    public function test_render_settings_page_translate () {
        Util::change_locale( 'eo_FR' );
        ob_start();
        $this->sos_options->render_settings_page();
        $result = ob_get_contents();
        ob_end_clean();
        // replace nonce with a constant
        $result = preg_replace( '#name="_wpnonce" value=".*"#U', 
                'name="_wpnonce" value="test nonce"', $result );
        
        $expected = $this->get_settings_page( 'Espéranto-France' );
        $this->assertSame( trim( $expected ), trim( $result ) );
    }

    public function test_init_common_options_section () {
        global $wp_settings_sections;
        $this->assertFalse( 
                isset( $wp_settings_sections[ 'sos_common_options' ] ) );
        
        $this->sos_options->init_common_options();
        
        $this->assertTrue( 
                isset( 
                        $wp_settings_sections[ 'sos_common_options' ][ 'sos_common_options_section' ] ) );
        $section = $wp_settings_sections[ 'sos_common_options' ][ 'sos_common_options_section' ];
        $this->assertSame( 'sos_common_options_section', $section[ 'id' ] );
    }

    public function test_init_common_options_add_options () {
        $option_group = 'sos_common_options';
        
        $options = get_option( $option_group );
        $this->assertFalse( $options );
        
        $this->sos_options->init_common_options();
        
        $options = get_option( $option_group );
        $this->assertSame( '', $options );
    }

    public function test_init_common_options_fb_field () {
        global $wp_settings_fields;
        
        $this->assertFalse( 
                isset( $wp_settings_fields[ 'sos_common_options' ] ) );
        
        $this->sos_options->init_common_options();
        $field_name = 'fbappid';
        $this->assertTrue( 
                isset( 
                        $wp_settings_fields[ 'sos_common_options' ][ 'sos_common_options_section' ][ $field_name ] ) );
        $field = $wp_settings_fields[ 'sos_common_options' ][ 'sos_common_options_section' ][ $field_name ];
        
        $this->assertSame( $field_name, $field[ 'id' ] );
        $this->assertSame( 'Facebook App ID', $field[ 'title' ] );
        
        $this->assertTrue( 
                Util::has_obj( 'Sos_Options', $field[ 'callback' ] ) );
        $this->assertTrue( 
                Util::has_value( 'textinput', $field[ 'callback' ] ) );
        
        // test for default FB app id
        $this->assertSame( $field_name, $field[ 'args' ][ 'id' ] );
        $this->assertSame( 'sos_common_options[fbappid]', 
                $field[ 'args' ][ 'name' ] );
        $this->assertSame( '', $field[ 'args' ][ 'value' ] );
    }

    public function test_init_common_options_fb_field_translate () {
        global $wp_settings_fields;
        
        $this->assertFalse( 
                isset( $wp_settings_fields[ 'sos_common_options' ] ) );
        
        Util::change_locale( 'eo_FR' );
        $this->sos_options->init_common_options();
        $field_name = 'fbappid';
        $this->assertTrue( 
                isset( 
                        $wp_settings_fields[ 'sos_common_options' ][ 'sos_common_options_section' ][ $field_name ] ) );
        $field = $wp_settings_fields[ 'sos_common_options' ][ 'sos_common_options_section' ][ $field_name ];
        
        $this->assertSame( $field_name, $field[ 'id' ] );
        $this->assertSame( 'Espéranto-France Facebook App ID', 
                $field[ 'title' ] );
        
        $this->assertTrue( 
                Util::has_obj( 'Sos_Options', $field[ 'callback' ] ) );
        $this->assertTrue( 
                Util::has_value( 'textinput', $field[ 'callback' ] ) );
        
        // test for default FB app id
        $this->assertSame( $field_name, $field[ 'args' ][ 'id' ] );
        $this->assertSame( 'sos_common_options[fbappid]', 
                $field[ 'args' ][ 'name' ] );
        $this->assertSame( '', $field[ 'args' ][ 'value' ] );
    }

    public function test_init_common_options_gplus_field () {
        global $wp_settings_fields;
        
        $this->assertFalse( 
                isset( $wp_settings_fields[ 'sos_common_options' ] ) );
        
        $this->sos_options->init_common_options();
        $field_name = 'gplusclientid';
        $this->assertTrue( 
                isset( 
                        $wp_settings_fields[ 'sos_common_options' ][ 'sos_common_options_section' ][ $field_name ] ) );
        $field = $wp_settings_fields[ 'sos_common_options' ][ 'sos_common_options_section' ][ $field_name ];
        
        $this->assertSame( $field_name, $field[ 'id' ] );
        $this->assertSame( 'Google Plus Client ID', $field[ 'title' ] );
        
        $this->assertTrue( 
                Util::has_obj( 'Sos_Options', $field[ 'callback' ] ) );
        $this->assertTrue( 
                Util::has_value( 'textinput', $field[ 'callback' ] ) );
        
        $this->assertSame( $field_name, $field[ 'args' ][ 'id' ] );
        $this->assertSame( 'sos_common_options[gplusclientid]', 
                $field[ 'args' ][ 'name' ] );
        $this->assertSame( '', $field[ 'args' ][ 'value' ] );
    }

    public function test_init_common_options_gplus_field_translate () {
        global $wp_settings_fields;
        
        $this->assertFalse( 
                isset( $wp_settings_fields[ 'sos_common_options' ] ) );
        
        Util::change_locale( 'eo_FR' );
        $this->sos_options->init_common_options();
        $field_name = 'gplusclientid';
        $this->assertTrue( 
                isset( 
                        $wp_settings_fields[ 'sos_common_options' ][ 'sos_common_options_section' ][ $field_name ] ) );
        $field = $wp_settings_fields[ 'sos_common_options' ][ 'sos_common_options_section' ][ $field_name ];
        
        $this->assertSame( $field_name, $field[ 'id' ] );
        $this->assertSame( 'Espéranto-France Google Plus Client ID', 
                $field[ 'title' ] );
        
        $this->assertTrue( 
                Util::has_obj( 'Sos_Options', $field[ 'callback' ] ) );
        $this->assertTrue( 
                Util::has_value( 'textinput', $field[ 'callback' ] ) );
        
        $this->assertSame( $field_name, $field[ 'args' ][ 'id' ] );
        $this->assertSame( 'sos_common_options[gplusclientid]', 
                $field[ 'args' ][ 'name' ] );
        $this->assertSame( '', $field[ 'args' ][ 'value' ] );
    }

    public function test_init_common_options_debug_field () {
        global $wp_settings_fields;
        
        $this->assertFalse( 
                isset( $wp_settings_fields[ 'sos_common_options' ] ) );
        
        $this->sos_options->init_common_options();
        $field_name = 'sos_debug';
        $this->assertTrue( 
                isset( 
                        $wp_settings_fields[ 'sos_common_options' ][ 'sos_common_options_section' ][ $field_name ] ) );
        $field = $wp_settings_fields[ 'sos_common_options' ][ 'sos_common_options_section' ][ $field_name ];
        
        $this->assertSame( $field_name, $field[ 'id' ] );
        $this->assertSame( 'Debug', $field[ 'title' ] );
        
        $this->assertTrue( 
                Util::has_obj( 'Sos_Options', $field[ 'callback' ] ) );
        $this->assertTrue( Util::has_value( 'checkbox', $field[ 'callback' ] ) );
        
        $this->assertSame( $field_name, $field[ 'args' ][ 'id' ] );
        $this->assertSame( 'sos_common_options[sos_debug]', 
                $field[ 'args' ][ 'name' ] );
        $this->assertSame( '', $field[ 'args' ][ 'value' ] );
    }

    public function test_init_common_options_debug_field_translate () {
        global $wp_settings_fields;
        
        $this->assertFalse( 
                isset( $wp_settings_fields[ 'sos_common_options' ] ) );
        
        Util::change_locale( 'eo_FR' );
        $this->sos_options->init_common_options();
        $field_name = 'sos_debug';
        $this->assertTrue( 
                isset( 
                        $wp_settings_fields[ 'sos_common_options' ][ 'sos_common_options_section' ][ $field_name ] ) );
        $field = $wp_settings_fields[ 'sos_common_options' ][ 'sos_common_options_section' ][ $field_name ];
        
        $this->assertSame( $field_name, $field[ 'id' ] );
        $this->assertSame( 'Espéranto-France Debug', $field[ 'title' ] );
        
        $this->assertTrue( 
                Util::has_obj( 'Sos_Options', $field[ 'callback' ] ) );
        $this->assertTrue( Util::has_value( 'checkbox', $field[ 'callback' ] ) );
        
        $this->assertSame( $field_name, $field[ 'args' ][ 'id' ] );
        $this->assertSame( 'sos_common_options[sos_debug]', 
                $field[ 'args' ][ 'name' ] );
        $this->assertSame( '', $field[ 'args' ][ 'value' ] );
    }

    public function test_init_common_options_sanitize () {
        $this->assertFalse( 
                Util::has_filter( 'sanitize_option_sos_common_options', 
                        $this->sos_options, 'sanitize_options' ) );
        
        $this->sos_options->init_common_options();
        
        $this->assertTrue( 
                Util::has_filter( 'sanitize_option_sos_common_options', 
                        $this->sos_options, 'sanitize_options' ) );
    }

    public function test_textinput () {
        $args = array(
                'id' => 'test id',
                'name' => 'test name',
                'value' => 'test value'
        );
        // test echo
        $expected = '<input class="text" type="text" id="test id" name="test name" size="30" value="test value"/>';
        ob_start();
        $returned = $this->sos_options->textinput( $args );
        $result = ob_get_contents();
        ob_end_clean();
        
        $this->assertSame( trim( $expected ), trim( $result ) );
        $this->assertNull( $returned );
        
        ob_start();
        $returned = $this->sos_options->textinput( $args, true );
        $result = ob_get_contents();
        ob_end_clean();
        $this->assertSame( trim( $expected ), trim( $result ) );
        $this->assertNull( $returned );
        
        // test return
        ob_start();
        $returned = $this->sos_options->textinput( $args, false );
        $result = ob_get_contents();
        ob_end_clean();
        $this->assertSame( trim( $expected ), trim( $returned ) );
        $this->assertSame( '', $result );
    }

    public function test_checkbox () {
        $args = array(
                'id' => 'test id',
                'name' => 'test name'
        );
        
        // test unchecked
        // test echo
        $expected = '<input type="checkbox" id="test id" name="test name" value="1" />';
        ob_start();
        $returned = $this->sos_options->checkbox( $args );
        $result = ob_get_contents();
        ob_end_clean();
        $this->assertSame( trim( $expected ), trim( $result ) );
        $this->assertNull( $returned );
        
        ob_start();
        $returned = $this->sos_options->checkbox( $args, true );
        $result = ob_get_contents();
        ob_end_clean();
        $this->assertSame( trim( $expected ), trim( $result ) );
        $this->assertNull( $returned );
        
        // test return
        ob_start();
        $returned = $this->sos_options->checkbox( $args, false );
        $result = ob_get_contents();
        ob_end_clean();
        $this->assertSame( '', $result );
        $this->assertSame( trim( $expected ), trim( $returned ) );
        
        // test checked
        // test echo
        $args = array(
                'id' => 'test id',
                'name' => 'test name',
                'value' => 1
        );
        $expected = '<input type="checkbox" id="test id" name="test name" value="1"  checked=\'checked\'/>';
        ob_start();
        $returned = $this->sos_options->checkbox( $args );
        $result = ob_get_contents();
        ob_end_clean();
        $this->assertSame( trim( $expected ), trim( $result ) );
        $this->assertNull( $returned );
        
        ob_start();
        $returned = $this->sos_options->checkbox( $args, true );
        $result = ob_get_contents();
        ob_end_clean();
        $this->assertSame( trim( $expected ), trim( $result ) );
        $this->assertNull( $returned );
        // test return
        ob_start();
        $returned = $this->sos_options->checkbox( $args, false );
        $result = ob_get_contents();
        ob_end_clean();
        $this->assertSame( '', $result );
        $this->assertSame( trim( $expected ), trim( $returned ) );
    }

    public function test_sanitize_options () {
        $input = array(
                'id' => 'test id'
        );
        $output = $this->sos_options->sanitize_options( $input );
        $this->assertCount( 1, $output );
        $this->assertSame( 'test id', $output[ 'id' ] );
    }

    public function test_sanitize_options_scripts () {
        // test strip_tags
        $input = array(
                'id' => 'test id<h1><?php evil ?>'
        );
        $output = $this->sos_options->sanitize_options( $input );
        $this->assertCount( 1, $output );
        $this->assertSame( 'test id', $output[ 'id' ] );
        // test strip slashes
        $input = array(
                'id' => 'test \\id<h1><?php evil ?>'
        );
        $output = $this->sos_options->sanitize_options( $input );
        $this->assertCount( 1, $output );
        $this->assertSame( 'test id', $output[ 'id' ] );
    }

    public function test_sanitize_options_apply_filters () {
        /*
         * add extra filter to the hook sanitize_options, which returns a
         * hardcoded array. Because apply_filters() in
         * sos_options->sanitize_options(), we should get the hardcoded array
         */
        add_filter( 'sanitize_options', 
                function  ( $in ) {
                    return array(
                            'id' => 'dummy id'
                    );
                } );
        $input = array(
                'id' => 'test id'
        );
        $output = $this->sos_options->sanitize_options( $input );
        $this->assertCount( 1, $output );
        $this->assertSame( 'dummy id', $output[ 'id' ] );
    }

    private function get_settings_page ( $lang_str = '' ) {
        $lang_str == '' ? $lang_str : $lang_str .= ' ';
        $html = <<<EOD
        <div class="wrap">
		<div id="icon-tools" class="icon32"></div>
		<h2>{$lang_str}Common Options</h2>
		</div>
		<div>{$lang_str}These options are applied to all lockers.</div>		
		<form method="post" action="options.php" style="width: 80%;"><input type='hidden' name='option_page' value='sos_common_options' /><input type="hidden" name="action" value="update" /><input type="hidden" id="_wpnonce" name="_wpnonce" value="test nonce" /><input type="hidden" name="_wp_http_referer" value="" /><p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Save Changes"  /></p></form>
EOD;
        return $html;
    }
}
