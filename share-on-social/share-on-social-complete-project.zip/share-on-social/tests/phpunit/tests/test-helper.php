<?php

class Test_Helper extends WP_UnitTestCase {

    public function setup () {
        parent::setup();
        require_once ('include/class-helper.php');
    }

    public function teardown () {
        parent::teardown();
        
        global $sos_debug_data;
        $sos_debug_data = null;
    }

    public function test_is_debug_enabled () {
        // option not set
        $this->assertFalse( get_option( 'sos_common_options' ) );
        $this->assertFalse( Sos_Helper::is_debug_enabled() );
        
        // add and set option to true
        add_option( 'sos_common_options', 
                array(
                        'sos_debug' => true
                ) );
        $this->assertTrue( Sos_Helper::is_debug_enabled() );
        
        // update option to false
        update_option( 'sos_common_options', 
                array(
                        'sos_debug' => false
                ) );
        $this->assertFalse( Sos_Helper::is_debug_enabled() );
    }

    public function test_collect_debug_data () {
        global $sos_debug_data;
        $this->assertNull( $sos_debug_data );
        $a = array(
                "id" => "test id 1"
        );
        Sos_Helper::collect_debug_data( $a );
        $this->assertCount( 1, $sos_debug_data );
        $this->assertSame( $a, $sos_debug_data[ 0 ] );
        
        $b = array(
                "id" => "test id 2"
        );
        Sos_Helper::collect_debug_data( $b );
        $this->assertCount( 2, $sos_debug_data );
        $this->assertSame( $a, $sos_debug_data[ 0 ] );
        $this->assertSame( $b, $sos_debug_data[ 1 ] );
    }

    public function test_output_debug_data_disabled () {
        // test whether disabled
        $this->assertFalse( Sos_Helper::is_debug_enabled() );
        
        ob_start();
        Sos_Helper::output_debug_data();
        $result = ob_get_contents();
        ob_end_clean();
        $this->assertSame( '', $result );
    }

    public function test_output_debug_data_without_data () {
        // add and set option to true
        add_option( 'sos_common_options', 
                array(
                        'sos_debug' => true
                ) );
        
        $this->assertTrue( Sos_Helper::is_debug_enabled() );
        
        ob_start();
        Sos_Helper::output_debug_data();
        $result = ob_get_contents();
        ob_end_clean();
        $expected = '';
        $this->assertSame( Util::trim_whitespaces( $expected ), 
                Util::trim_whitespaces( $result ) );
    }

    public function test_output_debug_data_with_data () {
        // add and set option to true
        add_option( 'sos_common_options', 
                array(
                        'sos_debug' => true
                ) );
        
        $this->assertTrue( Sos_Helper::is_debug_enabled() );
        
        $a = array(
                "id" => "test id 1"
        );
        $b = array(
                "id" => "test id 2"
        );
        Sos_Helper::collect_debug_data( $a );
        Sos_Helper::collect_debug_data( $b );
        
        ob_start();
        Sos_Helper::output_debug_data();
        $result = ob_get_contents();
        ob_end_clean();
        
        $expected = $this->debug_output_with_data();
        $this->assertSame( trim( $expected ), trim( $result ) );
    }
    
    // private function debug_output_without_data ()
    // {
    // $text = <<<EOD
    // <!-- share-on-social Debug [ disable debug in production site! ]
    // -->
    // EOD;
    // return $text;
    // }
    private function debug_output_with_data () {
        $version = SOS_VERSION;
        $plugin_name = SOS_NAME;
        $text = <<<EOD
<!--
<![CDATA[

Plugin [{$plugin_name}] Version [{$version}]

Debug info [ disable debug in production site !!! ]

Array
(
    [0] => Array
        (
            [id] => test id 1
        )

    [1] => Array
        (
            [id] => test id 2
        )

)

]]>
 -->
EOD;
        return $text;
    }
}
