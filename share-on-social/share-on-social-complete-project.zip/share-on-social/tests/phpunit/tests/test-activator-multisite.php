<?php

class Test_Sos_Activator extends WP_UnitTestCase {

    var $activator;

    var $sos;

    public function setup () {
        parent::setup();
        
        // create sos post type
        require_once 'admin/class-sos.php';
        $this->sos = new Sos();
        
        require_once 'admin/class-activator.php';
        $this->activator = new Sos_Activator();
        
        // add one more blog to the site
        $this->add_blog( 'test1', 'Test 1' );
        
        // set default admin - some test change user
        wp_set_current_user( 1 );
        Util::set_admin_role( true );
    }

    public function teardown () {
        parent::teardown();
        unload_textdomain( 'sos-domain' );
        delete_option( 'sos_common_options' );
        Util::set_activate_plugins_cap( false );
    }

    public function test_setup () {
        global $wp_filter;
        
        $act_key = 'activate_share-on-social/share-on-social.php';
        $deact_key = 'deactivate_share-on-social/share-on-social.php';
        $links_key = 'plugin_action_links';
        
        // hooks should not exist in $wp_filter at present
        $this->assertarrayNotHasKey( $act_key, $wp_filter );
        $this->assertarrayNotHasKey( $deact_key, $wp_filter );
        $this->assertarrayNotHasKey( $links_key, $wp_filter );
        
        // register hooks
        $this->activator->setup();
        
        // test Sos_Activator->activate() function is registered
        $this->assertarrayHasKey( $act_key, $wp_filter );
        $this->assertTrue( 
                Util::has_obj( 'Sos_Activator', $wp_filter[ $act_key ] ) );
        $this->assertTrue( 
                Util::has_value( 'activate', $wp_filter[ $act_key ] ) );
        
        // test Sos_Activator->deactivate() function is registered
        $this->assertarrayHasKey( $deact_key, $wp_filter );
        $this->assertTrue( 
                Util::has_obj( 'Sos_Activator', $wp_filter[ $deact_key ] ) );
        $this->assertTrue( 
                Util::has_value( 'deactivate', $wp_filter[ $deact_key ] ) );
        
        $this->assertarrayHasKey( $links_key, $wp_filter );
        $this->assertTrue( 
                Util::has_obj( 'Sos_Activator', $wp_filter[ $links_key ] ) );
        $this->assertTrue( 
                Util::has_value( 'action_links', $wp_filter[ $links_key ] ) );
        
        $obj_id = spl_object_hash( $this->activator );
        $priority = 10;
        $expected = 2; // accepted_args field
        $result = $wp_filter[ $links_key ][ $priority ][ $obj_id . 'action_links' ][ 'accepted_args' ];
        $this->assertSame( $expected, $result );
    }

    public function test_multisite_activate_by_non_superadmin () {
        // list of blogs in site
        $blogs = wp_get_sites();
        $this->assertCount( 2, $blogs );
        
        // networkwide activation - superadmin
        $networkwide = true;
        
        // create locker and no options
        switch_to_blog( $blogs[ 0 ][ 'blog_id' ] );
        Util::set_activate_plugins_cap( true );
        $this->sos->create_post_type();
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        restore_current_blog();
        
        switch_to_blog( $blogs[ 1 ][ 'blog_id' ] );
        Util::set_activate_plugins_cap( true );
        $this->sos->create_post_type();
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        restore_current_blog();
        
        // we can't remove super admin status from default user so create new
        // user
        $user_id = $this->add_user( 'testuser' );
        wp_set_current_user( $user_id );
        
        // try to activate by non super admin - locker exists, no options
        $this->activator->activate( $networkwide );
        
        switch_to_blog( $blogs[ 0 ][ 'blog_id' ] );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        restore_current_blog();
        
        switch_to_blog( $blogs[ 1 ][ 'blog_id' ] );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        restore_current_blog();
    }

    public function test_multisite_activate_by_superadmin () {
        // list of blogs in site
        $blogs = wp_get_sites();
        $this->assertCount( 2, $blogs );
        
        // networkwide activation - superadmin
        $networkwide = true;
        
        // create locker and no options
        switch_to_blog( $blogs[ 0 ][ 'blog_id' ] );
        Util::set_activate_plugins_cap( true );
        $this->sos->create_post_type();
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        restore_current_blog();
        
        switch_to_blog( $blogs[ 1 ][ 'blog_id' ] );
        Util::set_activate_plugins_cap( true );
        $this->sos->create_post_type();
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        restore_current_blog();
        
        // we can't remove super admin status from default user so create new
        // user
        $user_id = $this->add_user( 'testuser' );
        wp_set_current_user( $user_id );
        
        // grant super admin and activate
        grant_super_admin( $user_id );
        $this->activator->activate( $networkwide );
        
        // test activation - locker deleted, options created
        switch_to_blog( $blogs[ 0 ][ 'blog_id' ] );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertFalse( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $this->assertCount( 1, $options );
        $this->assertSame( SOS_VERSION, $options[ 'version' ] );
        restore_current_blog();
        
        switch_to_blog( $blogs[ 1 ][ 'blog_id' ] );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertFalse( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $this->assertCount( 1, $options );
        $this->assertSame( SOS_VERSION, $options[ 'version' ] );
        restore_current_blog();
    }

    function test_multisite_activate_by_blog_admin_without_cap () {
        // list of blogs in site
        $blogs = wp_get_sites();
        $this->assertCount( 2, $blogs );
        
        // blog level activation
        $networkwide = false;
        
        $user_id = $this->add_user( 'testuser' );
        wp_set_current_user( $user_id );
        add_user_to_blog( $blogs[ 1 ][ 'blog_id' ], $user_id, 'administrator' );
        
        // create locker and no options
        switch_to_blog( $blogs[ 0 ][ 'blog_id' ] );
        Util::set_activate_plugins_cap( true );
        $this->sos->create_post_type();
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        restore_current_blog();
        
        switch_to_blog( $blogs[ 1 ][ 'blog_id' ] );
        Util::set_activate_plugins_cap( true );
        $this->sos->create_post_type();
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        restore_current_blog();
        
        // try to activate without cap - locker exists, no options
        Util::set_activate_plugins_cap( false );
        $this->activator->activate( $networkwide );
        
        switch_to_blog( $blogs[ 0 ][ 'blog_id' ] );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        restore_current_blog();
        
        switch_to_blog( $blogs[ 1 ][ 'blog_id' ] );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        restore_current_blog();
    }

    function test_multisite_activate_by_blog_admin_with_cap () {
        // list of blogs in site
        $blogs = wp_get_sites();
        $this->assertCount( 2, $blogs );
        
        // blog level activation
        $networkwide = false;
        
        $user_id = $this->add_user( 'testuser' );
        wp_set_current_user( $user_id );
        add_user_to_blog( $blogs[ 1 ][ 'blog_id' ], $user_id, 'administrator' );
        
        // create locker and no options
        switch_to_blog( $blogs[ 0 ][ 'blog_id' ] );
        Util::set_activate_plugins_cap( true );
        $this->sos->create_post_type();
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        restore_current_blog();
        
        switch_to_blog( $blogs[ 1 ][ 'blog_id' ] );
        Util::set_activate_plugins_cap( true );
        $this->sos->create_post_type();
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        restore_current_blog();
        
        // activate with cap in first blog - locker deleted, options exists
        switch_to_blog( $blogs[ 0 ][ 'blog_id' ] );
        Util::set_activate_plugins_cap( true );
        $this->activator->activate( $networkwide );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertFalse( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $this->assertCount( 1, $options );
        $this->assertSame( SOS_VERSION, $options[ 'version' ] );
        restore_current_blog();
        
        // test not activated in second blog
        switch_to_blog( $blogs[ 1 ][ 'blog_id' ] );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        restore_current_blog();
        
        // activate in second blog
        switch_to_blog( $blogs[ 1 ][ 'blog_id' ] );
        Util::set_activate_plugins_cap( true );
        $this->activator->activate( $networkwide );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertFalse( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $this->assertCount( 1, $options );
        $this->assertSame( SOS_VERSION, $options[ 'version' ] );
        restore_current_blog();
    }

    function test_multisite_deactivate_by_non_superadmin () {
        // list of blogs in site
        $blogs = wp_get_sites();
        $this->assertCount( 2, $blogs );
        
        // networkwide activation - superadmin
        $networkwide = true;
        
        // create locker and add options
        switch_to_blog( $blogs[ 0 ][ 'blog_id' ] );
        Util::set_activate_plugins_cap( true );
        $this->sos->create_post_type();
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $this->activator->add_settings();
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        restore_current_blog();
        
        switch_to_blog( $blogs[ 1 ][ 'blog_id' ] );
        Util::set_activate_plugins_cap( true );
        $this->sos->create_post_type();
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $this->activator->add_settings();
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        restore_current_blog();
        
        // we can't remove super admin status from default user so create new
        // user
        $user_id = $this->add_user( 'testuser' );
        wp_set_current_user( $user_id );
        
        // try to deactivate non superadmin
        $this->activator->deactivate( $networkwide );
        
        // test locker and options exists
        switch_to_blog( $blogs[ 0 ][ 'blog_id' ] );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $this->assertCount( 1, $options );
        $this->assertSame( SOS_VERSION, $options[ 'version' ] );
        restore_current_blog();
        
        switch_to_blog( $blogs[ 1 ][ 'blog_id' ] );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $this->assertCount( 1, $options );
        $this->assertSame( SOS_VERSION, $options[ 'version' ] );
        restore_current_blog();
    }

    function test_multisite_deactivate_by_superadmin () {
        // list of blogs in site
        $blogs = wp_get_sites();
        $this->assertCount( 2, $blogs );
        
        // networkwide activation - superadmin
        $networkwide = true;
        
        // create locker and add options
        switch_to_blog( $blogs[ 0 ][ 'blog_id' ] );
        Util::set_activate_plugins_cap( true );
        $this->sos->create_post_type();
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $this->activator->add_settings();
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        restore_current_blog();
        
        switch_to_blog( $blogs[ 1 ][ 'blog_id' ] );
        Util::set_activate_plugins_cap( true );
        $this->sos->create_post_type();
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $this->activator->add_settings();
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        restore_current_blog();
        
        // we can't remove super admin status from default user so create new
        // user
        $user_id = $this->add_user( 'testuser' );
        wp_set_current_user( $user_id );
        grant_super_admin( $user_id );
        
        // try to deactivate by superadmin
        $this->activator->deactivate( $networkwide );
        
        // test locker and options not delete during network deactivate
        switch_to_blog( $blogs[ 0 ][ 'blog_id' ] );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $this->assertCount( 1, $options );
        $this->assertSame( SOS_VERSION, $options[ 'version' ] );
        restore_current_blog();
        
        switch_to_blog( $blogs[ 1 ][ 'blog_id' ] );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $this->assertCount( 1, $options );
        $this->assertSame( SOS_VERSION, $options[ 'version' ] );
        restore_current_blog();
    }

    function test_multisite_deactivate_by_blog_admin_without_cap () {
        // list of blogs in site
        $blogs = wp_get_sites();
        $this->assertCount( 2, $blogs );
        
        // blog level activation
        $networkwide = false;
        
        $user_id = $this->add_user( 'testuser' );
        wp_set_current_user( $user_id );
        add_user_to_blog( $blogs[ 0 ][ 'blog_id' ], $user_id, 'administrator' );
        add_user_to_blog( $blogs[ 1 ][ 'blog_id' ], $user_id, 'administrator' );
        
        // create locker and add options
        switch_to_blog( $blogs[ 0 ][ 'blog_id' ] );
        Util::set_activate_plugins_cap( true );
        $this->sos->create_post_type();
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $this->activator->add_settings();
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        restore_current_blog();
        
        switch_to_blog( $blogs[ 1 ][ 'blog_id' ] );
        Util::set_activate_plugins_cap( true );
        $this->sos->create_post_type();
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $this->activator->add_settings();
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        restore_current_blog();
        
        // deact without cap and test locker and options not delete
        switch_to_blog( $blogs[ 0 ][ 'blog_id' ] );
        Util::set_activate_plugins_cap( false );
        $this->activator->deactivate( $networkwide );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $this->assertCount( 1, $options );
        $this->assertSame( SOS_VERSION, $options[ 'version' ] );
        restore_current_blog();
        
        switch_to_blog( $blogs[ 1 ][ 'blog_id' ] );
        Util::set_activate_plugins_cap( false );
        $this->activator->deactivate( $networkwide );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $this->assertCount( 1, $options );
        $this->assertSame( SOS_VERSION, $options[ 'version' ] );
        restore_current_blog();
    }

    function test_multisite_deactivate_by_blog_admin_with_cap () {
        // list of blogs in site
        $blogs = wp_get_sites();
        $this->assertCount( 2, $blogs );
        
        // blog level activation
        $networkwide = false;
        
        $user_id = $this->add_user( 'testuser' );
        wp_set_current_user( $user_id );
        add_user_to_blog( $blogs[ 0 ][ 'blog_id' ], $user_id, 'administrator' );
        add_user_to_blog( $blogs[ 1 ][ 'blog_id' ], $user_id, 'administrator' );
        
        // create locker and add options
        switch_to_blog( $blogs[ 0 ][ 'blog_id' ] );
        Util::set_activate_plugins_cap( true );
        $this->sos->create_post_type();
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $this->activator->add_settings();
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        restore_current_blog();
        
        switch_to_blog( $blogs[ 1 ][ 'blog_id' ] );
        Util::set_activate_plugins_cap( true );
        $this->sos->create_post_type();
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $this->activator->add_settings();
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        restore_current_blog();
        
        // deact with cap and test locker delete bug options not delete
        switch_to_blog( $blogs[ 0 ][ 'blog_id' ] );
        Util::set_activate_plugins_cap( true );
        $this->activator->deactivate( $networkwide );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertFalse( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $this->assertCount( 1, $options );
        $this->assertSame( SOS_VERSION, $options[ 'version' ] );
        restore_current_blog();
        
        // test locker not deleted in second blog
        switch_to_blog( $blogs[ 1 ][ 'blog_id' ] );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertTrue( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $this->assertCount( 1, $options );
        $this->assertSame( SOS_VERSION, $options[ 'version' ] );
        restore_current_blog();
        
        // now deac in second blog
        switch_to_blog( $blogs[ 1 ][ 'blog_id' ] );
        Util::set_activate_plugins_cap( true );
        $this->activator->deactivate( $networkwide );
        $post_id = Util::get_post_id( 'sos', 'locker_id', 'basic' );
        $this->assertFalse( isset( $post_id ) );
        $options = get_option( 'sos_common_options' );
        $this->assertNotFalse( $options );
        $this->assertCount( 1, $options );
        $this->assertSame( SOS_VERSION, $options[ 'version' ] );
        restore_current_blog();
    }

    function test_action_links () {
        $links = array();
        $file = 'plugin-x/plugin.php';
        $links = $this->activator->action_links( $links, $file );
        $this->assertCount( 0, $links );
        
        $file = 'share-on-social/share-on-social.php';
        $links = $this->activator->action_links( $links, $file );
        $expected = '<a href="http://localhost/wp-admin/edit.php?post_type=sos&page=sos_settings_page">Settings</a>';
        $this->assertCount( 1, $links );
        $this->assertSame( $expected, $links[ 0 ] );
        
        // test whether array_unshift is called
        $links = array(
                'http://example.org'
        );
        $links = $this->activator->action_links( $links, $file );
        $this->assertCount( 2, $links );
        $this->assertSame( $expected, $links[ 0 ] );
        $this->assertSame( 'http://example.org', $links[ 1 ] );
    }

    public function test_add_settings () {
        $options = get_option( 'sos_common_options' );
        $this->assertFalse( $options );
        
        $this->activator->add_settings();
        
        $options = get_option( 'sos_common_options' );
        $this->assertTrue( isset( $options ) );
        $this->assertCount( 1, $options );
        $this->assertSame( SOS_VERSION, $options[ 'version' ] );
    }

    private function add_user ( $login_name ) {
        $userdata = array(
                'user_login' => $login_name,
                'user_url' => 'localhost',
                'user_pass' => NULL
        );
        return $this->factory->user->create_object( $userdata );
    }
    
    // add blog to multisite
    private function add_blog ( $path, $title ) {
        // $_SERVER[ 'REMOTE_ADDR' ] = 'localhost';
        // use factory to add one more blog to the site
        $args = array(
                'domain' => 'localhost',
                'site_id' => 1,
                'path' => $path,
                'title' => $title
        );
        $this->factory->blog->create_object( $args );
    }
}
