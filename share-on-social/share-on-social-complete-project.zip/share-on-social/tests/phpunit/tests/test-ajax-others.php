<?php

/**
*
* Tests for the regualar functions (non ajax calls) in class-ajax.php
*
*/
class Test_Sos_Ajax_others extends WP_UnitTestCase {

    var $sos_ajax;

    // public static function tearDownAfterClass () {
    // remove_action( 'shutdown', 'Sos_Helper::output_debug_data' );
    // }
    public function setup () {
        parent::setup();

        require_once 'admin/class-ajax.php';
        $this->sos_ajax = new Sos_Ajax();
        date_default_timezone_set('UTC');
    }

    public function teardown () {
        parent::teardown();
        unload_textdomain( 'sos-domain' );
    }

    public function test_setup () {
        $this->assertFalse(
                Util::has_action( 'wp_ajax_nopriv_save-stats', $this->sos_ajax,
                        'save_stats' ) );
        $this->assertFalse(
                Util::has_action( 'wp_ajax_save-stats', $this->sos_ajax,
                        'save_stats' ) );
        $this->assertFalse(
                Util::has_action( 'wp_ajax_get-stats', $this->sos_ajax,
                        'get_stats' ) );

        $this->sos_ajax->setup();

        $this->assertTrue(
                Util::has_action( 'wp_ajax_nopriv_save-stats', $this->sos_ajax,
                        'save_stats' ) );
        $this->assertTrue(
                Util::has_action( 'wp_ajax_save-stats', $this->sos_ajax,
                        'save_stats' ) );
        $this->assertTrue(
                Util::has_action( 'wp_ajax_get-stats', $this->sos_ajax,
                        'get_stats' ) );
    }

    public function test_setup_purge_data () {
        $now = strtotime( 'now UTC' );

        // create stats for now - 88 to 92 days
        for ( $day = 58; $day < 63; $day ++ ) {
            $stats[] = array(
                    'date' => ($now - 86400 * $day),
                    'type' => 'fb',
                    'share_name' => 'test share'
            );
        }

        add_option( 'sos_stats', $stats );
        $stats = get_option( 'sos_stats' );
        $this->assertCount( 5, $stats );

        $this->sos_ajax->setup();

        // test stats retained for 60 days
        $stats = get_option( 'sos_stats' );
        $this->assertCount( 3, $stats );
        $this->assertTrue( $stats[ 0 ][ 'date' ] == ($now - 86400 * 58) );
        $this->assertTrue( $stats[ 1 ][ 'date' ] == ($now - 86400 * 59) );
        $this->assertTrue( $stats[ 2 ][ 'date' ] == ($now - 86400 * 60) );
    }

    public function test_update_sos_stat_single () {
        // sos use UTC so switch to some other TZ to test
        date_default_timezone_set( 'America/Los_Angeles' );
        $this->sos_ajax->update_sos_stats( 'fb', 'test' );

        $stats = get_option( 'sos_stats' );
        $this->assertCount( 1, $stats );

        $stat = $stats[ 0 ];

        $this->assertSame( 'fb', $stat[ 'type' ] );
        $this->assertSame( 'test', $stat[ 'share_name' ] );

        // saved timestamp and now may deviate by a tolerance
        $tolerance = 5;
        $now = strtotime( 'now UTC' );
        $low = $now - $tolerance;
        $high = $now + $tolerance;
        $this->assertTrue( $stat[ 'date' ] >= $low && $stat[ 'date' ] <= $high );

        date_default_timezone_set( 'UTC' );
    }

    public function test_update_stats_two_stats () {
        // sos use UTC so switch to some other TZ to test
        date_default_timezone_set( 'America/Los_Angeles' );
        $this->sos_ajax->update_sos_stats( 'fb', 'share 1' );
        $this->sos_ajax->update_sos_stats( 'twitter', 'share 2' );

        $stats = get_option( 'sos_stats' );
        $this->assertCount( 2, $stats );

        // saved timestamp and now may deviate by a tolerance
        $tolerance = 5;
        $now = strtotime( 'now UTC' );
        $low = $now - $tolerance;
        $high = $now + $tolerance;

        $stat = $stats[ 0 ];
        $this->assertSame( 'fb', $stat[ 'type' ] );
        $this->assertSame( 'share 1', $stat[ 'share_name' ] );
        $this->assertTrue( $stat[ 'date' ] >= $low && $stat[ 'date' ] <= $high );

        $stat = $stats[ 1 ];
        $this->assertSame( 'share 2', $stat[ 'share_name' ] );
        $this->assertTrue( $stat[ 'date' ] >= $low && $stat[ 'date' ] <= $high );

        date_default_timezone_set( 'UTC' );
    }

    public function test_update_sos_stats_summary () {
        $summary = get_option( 'sos_stats_summary' );
        $this->assertFalse( $summary );

        $this->sos_ajax->update_sos_stats_summary( 'fb', 'test' );
        $summary = get_option( 'sos_stats_summary' );
        $this->assertCount( 1, $summary );
        $this->assertSame( 1, $summary[ 'fb' ] );

        $this->sos_ajax->update_sos_stats_summary( 'fb', 'test' );
        $summary = get_option( 'sos_stats_summary' );
        $this->assertCount( 1, $summary );
        $this->assertSame( 2, $summary[ 'fb' ] );
    }

    public function test_get_stats_json_no_stat () {
        $expected = '{"cols":[{"label":"Date","type":"date"},{"label":"Facebook","type":"number"},{"label":"Twitter","type":"number"}]}';
        $result = $this->sos_ajax->get_stats_json();
        $this->assertSame( $expected, $result );
    }

    public function test_get_stats_json_single_stat () {
        $test_stats = $this->get_test_stats();
        $stats[] = $test_stats[ 0 ];
        add_option( 'sos_stats', $stats );
        $expected = '{"cols":[{"label":"Date","type":"date"},{"label":"FB","type":"number"}],"rows":[{"c":[{"v":"Date(2014,9,29)"},{"v":1}]}]}';
        $result = $this->sos_ajax->get_stats_json();
        $this->assertSame( $expected, $result );
    }

    public function test_get_stats_json_two_stat () {
        $test_stats = $this->get_test_stats();
        $stats[] = $test_stats[ 0 ];
        $stats[] = $test_stats[ 3 ];
        add_option( 'sos_stats', $stats );
        $expected = '{"cols":[{"label":"Date","type":"date"},{"label":"FB","type":"number"}],"rows":[{"c":[{"v":"Date(2014,9,29)"},{"v":1}]},{"c":[{"v":"Date(2014,9,28)"},{"v":1}]}]}';
        $result = $this->sos_ajax->get_stats_json();
        $this->assertSame( $expected, $result );
    }

    public function test_get_stats_json_multi_stat () {
        $test_stats = $this->get_test_stats();
        $stats[] = $test_stats[ 0 ];
        $stats[] = $test_stats[ 1 ];
        $stats[] = $test_stats[ 2 ];
        $stats[] = $test_stats[ 3 ];
        $stats[] = $test_stats[ 4 ];
        add_option( 'sos_stats', $stats );
        $expected = '{"cols":[{"label":"Date","type":"date"},{"label":"FB","type":"number"},{"label":"Twitter","type":"number"}],"rows":[{"c":[{"v":"Date(2014,9,29)"},{"v":2},{"v":0}]},{"c":[{"v":"Date(2014,9,28)"},{"v":2},{"v":0}]},{"c":[{"v":"Date(2014,9,27)"},{"v":0},{"v":1}]}]}';
        $result = $this->sos_ajax->get_stats_json();
        $this->assertSame( $expected, $result );

        delete_option( 'sos_stats' );

        // full set
        $stats = $this->get_test_stats();
        add_option( 'sos_stats', $stats );
        $expected = '{"cols":[{"label":"Date","type":"date"},{"label":"FB","type":"number"},{"label":"Twitter","type":"number"}],"rows":[{"c":[{"v":"Date(2014,9,29)"},{"v":2},{"v":0}]},{"c":[{"v":"Date(2014,9,28)"},{"v":2},{"v":0}]},{"c":[{"v":"Date(2014,9,27)"},{"v":0},{"v":1}]}]}';
        $result = $this->sos_ajax->get_stats_json();
        $this->assertSame( $expected, $result );
    }

    public function test_summarize_stats_by_date () {
        $stats = $this->get_test_stats();
        $result = $this->sos_ajax->summarize_stats_by_date( $stats );
        $expected[ 'Oct 29' ] = array(
                'date' => '1414586000',
                'fb' => 2,
                'twitter' => 0
        );
        $expected[ 'Oct 28' ] = array(
                'date' => '1414499800',
                'fb' => 2,
                'twitter' => 0
        );
        $expected[ 'Oct 27' ] = array(
                'date' => '1414370000',
                'fb' => 0,
                'twitter' => 1
        );
        $this->assertSame( $expected, $result );
    }

    public function test_get_stats_summary_json_no_stat () {
        $expected = '{"cols":[{"label":"Share On","type":"string"},{"label":"Total","type":"number"}]}';
        $result = $this->sos_ajax->get_stats_summary_json();
        $this->assertSame( $expected, $result );
    }

    public function test_get_stats_summary_json () {
        $summary[ 'fb' ] = 10;
        $summary[ 'twitter' ] = 30;
        add_option( 'sos_stats_summary', $summary );

        $expected = '{"cols":[{"label":"Share On","type":"string"},{"label":"Total","type":"number"}],"rows":[{"c":[{"v":"FB"},{"v":10}]},{"c":[{"v":"Twitter"},{"v":30}]}]}';
        $result = $this->sos_ajax->get_stats_summary_json();
        $this->assertSame( $expected, $result );
    }

    public function test_purge_data () {
        $now = strtotime( 'now UTC' );

        // create stats for last 4 days
        for ( $day = 0; $day < 5; $day ++ ) {
            $stats[] = array(
                    'date' => ($now - 86400 * $day)
            );
        }

        // retain data for 1 day
        add_option( 'sos_stats', $stats );
        $stats = get_option( 'sos_stats' );
        $this->assertCount( 5, $stats );

        $this->sos_ajax->purge_data( 1 );
        $purged_stats = get_option( 'sos_stats' );
        $this->assertCount( 2, $purged_stats );
        $this->assertSame( $stats[ 0 ], $purged_stats[ 0 ] );
        $this->assertSame( $stats[ 1 ], $purged_stats[ 1 ] );

        // retain data for 2 day
        delete_option( 'sos_stats' );
        add_option( 'sos_stats', $stats );
        $stats = get_option( 'sos_stats' );
        $this->assertCount( 5, $stats );

        $this->sos_ajax->purge_data( 2 );
        $purged_stats = get_option( 'sos_stats' );
        $this->assertCount( 3, $purged_stats );
        $this->assertSame( $stats[ 0 ], $purged_stats[ 0 ] );
        $this->assertSame( $stats[ 1 ], $purged_stats[ 1 ] );
        $this->assertSame( $stats[ 2 ], $purged_stats[ 2 ] );

        // retain data for 3 day
        delete_option( 'sos_stats' );
        add_option( 'sos_stats', $stats );
        $stats = get_option( 'sos_stats' );
        $this->assertCount( 5, $stats );

        $this->sos_ajax->purge_data( 3 );
        $purged_stats = get_option( 'sos_stats' );
        $this->assertCount( 4, $purged_stats );
        $this->assertSame( $stats[ 0 ], $purged_stats[ 0 ] );
        $this->assertSame( $stats[ 1 ], $purged_stats[ 1 ] );
        $this->assertSame( $stats[ 2 ], $purged_stats[ 2 ] );
        $this->assertSame( $stats[ 3 ], $purged_stats[ 3 ] );

        // retain data for 4 day
        delete_option( 'sos_stats' );
        add_option( 'sos_stats', $stats );
        $stats = get_option( 'sos_stats' );
        $this->assertCount( 5, $stats );

        $this->sos_ajax->purge_data( 4 );
        $purged_stats = get_option( 'sos_stats' );
        $this->assertCount( 5, $purged_stats );
        $this->assertSame( $stats[ 0 ], $purged_stats[ 0 ] );
        $this->assertSame( $stats[ 1 ], $purged_stats[ 1 ] );
        $this->assertSame( $stats[ 2 ], $purged_stats[ 2 ] );
        $this->assertSame( $stats[ 3 ], $purged_stats[ 3 ] );
        $this->assertSame( $stats[ 4 ], $purged_stats[ 4 ] );
    }

    public function test_get_purge_date () {
        $today = strtotime( 'today UTC' );
        $result = $this->sos_ajax->get_purge_date( 0 );
        $this->assertSame( $today, $result );
        $result = $this->sos_ajax->get_purge_date( 1 );
        $this->assertSame( $today - 86400, $result );
        $result = $this->sos_ajax->get_purge_date( 2 );
        $this->assertSame( $today - (86400 * 2), $result );
    }

    public function test_get_labels () {
        $stats = $this->get_test_stats();
        $labels = $this->sos_ajax->get_labels( $stats );
        $this->assertCount( 2, $labels );
        $this->assertSame( 'FB', $labels[ 'fb' ] );
        $this->assertSame( 'Twitter', $labels[ 'twitter' ] );
    }

    public function test_get_label () {
        $this->assertSame( 'FB', $this->sos_ajax->get_label( 'fb' ) );
        $this->assertSame( 'Twitter', $this->sos_ajax->get_label( 'twitter' ) );
        $this->assertSame( 'undefined', $this->sos_ajax->get_label( 'x' ) );
    }

    private function get_test_stats () {
        /*
        * 27-10-2014 FB 2
        * 28-10-2014 FB 2
        * 29-10-2014 Twitter 1
        */

        // 29-10-2014
        $stats[] = array(
                'date' => '1414586000',
                'type' => 'fb',
                'share_name' => 'test share 1'
        );
        // 29-10-2014
        $stats[] = array(
                'date' => '1414586100',
                'type' => 'fb',
                'share_name' => 'test share 1'
        );
        // 28-10-2014
        $stats[] = array(
                'date' => '1414499800',
                'type' => 'fb',
                'share_name' => 'test share 2'
        );
        // 28-10-2014
        $stats[] = array(
                'date' => '1414499900',
                'type' => 'fb',
                'share_name' => 'test share 2'
        );
        // 27-10-2014
        $stats[] = array(
                'date' => '1414370000',
                'type' => 'twitter',
                'share_name' => 'test share 3'
        );
        return $stats;
    }
}
