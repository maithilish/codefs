<?php

// @formatter:off
/*
 * To run tests, we need wordpress-test-lib files in includes dir. To install
 * wordpress test lib, run following command from share-on-social/tests/phpunit
 * directory. 
 * 
 * $ svn co https://develop.svn.wordpress.org/trunk/tests/phpunit/includes/
 * 
 * This command checkout the latest version of test lib to includes
 * directory. Our bootstrap.php file calls test lib's bootstrap.php located in
 * includes directory to create wordpress instance and database to run tests.
 */
// @formatter:on

// path to test lib bootstrap.php
$test_lib_bootstrap_file = dirname( __FILE__ ) . '/includes/bootstrap.php';

if ( ! file_exists( $test_lib_bootstrap_file ) ) {
    echo PHP_EOL;
    echo "Error : unable to find " . $test_lib_bootstrap_file . PHP_EOL;
    echo PHP_EOL;
    echo "Tests requires Wordpress development lib to run. ";
    echo "To install, run following command from share-on-social/tests/phpunit dir" .
             PHP_EOL;
    echo PHP_EOL;
    echo "$ svn co https://develop.svn.wordpress.org/trunk/tests/phpunit/includes/" .
             PHP_EOL . PHP_EOL;
    exit( '' . PHP_EOL );
}

// set plugin and options for activation
$GLOBALS[ 'wp_tests_options' ] = array(
        'active_plugins' => array(
                'share-on-social/share-on-social.php'
        ),
        'sos_test' => true
);

// call test-lib's bootstrap.php
require_once $test_lib_bootstrap_file;

require_once 'tests/phpunit/util/class-util.php';

$current_user = new WP_User( 1 );
$current_user->set_role( 'administrator' );

echo PHP_EOL;
echo 'Using Wordpress core : ' . ABSPATH . PHP_EOL;
echo PHP_EOL;