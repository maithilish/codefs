var sos_data = {
	gplus_client_id : '764948266296-0j4qu4soh4uhsa6r95c7k11u9c2j9rjg.apps.googleusercontent.com'
};

QUnit.test("showFBShares() single share_name", function(assert) {

	var $fixture = $("#qunit-fixture");
	$fixture.append("<input type='hidden' class='share_name' value='share-1'></input>");
	$fixture.append("<span class='share-locker fb-share-1'></span>");
	$fixture.append("<span class='share-locker fb-share-1'></span>");
	$fixture.append("<span class='share-locker fb-share-2'></span>");
	$fixture.append("<span class='share-locker gplus-share-1'></span>");

	showFBShares();

	var shareButtons = $('.fb-share-1'); // get elements by class
	assert.equal(shareButtons.length, 2, 'fb-share-1 buttons : 1');
	msg = ' - shareWithFB() linked to fb-share-1 button';
	assert.equal(shareWithFB, shareButtons[0].onclick, msg + ' 1');
	assert.equal(shareWithFB, shareButtons[1].onclick, msg + ' 2');

	var shareButtons = $('.fb-share-2');
	assert.equal(shareButtons.length, 1, 'fb-share-2 buttons : 1');
	msg = ' shareWithFB() not linked to fb-share-2 button';
	assert.notEqual(shareWithFB, shareButtons[0].onclick, msg + ' 1');

	var shareButtons = $('.gplus-share-1');
	msg = ' shareWithFB() not linked to GPlus button';
	assert.equal(shareButtons.length, 1, 'Gplus share buttons : 1');
	assert.notEqual(shareWithFB, shareButtons[0].onclick, msg + ' 1');

});

QUnit.test("showFBShares() multi share_name", function(assert) {

	var $fixture = $("#qunit-fixture");
	$fixture.append("<input type='hidden' class='share_name' value='share-1'></input>");
	$fixture.append("<input type='hidden' class='share_name' value='share-2'></input>");
	$fixture.append("<span class='share-locker fb-share-1'></span>");
	$fixture.append("<span class='share-locker fb-share-1'></span>");
	$fixture.append("<span class='share-locker fb-share-2'></span>");
	$fixture.append("<span class='share-locker gplus-share-1'></span>");

	showFBShares();

	var shareButtons = $('.fb-share-1');
	assert.equal(shareButtons.length, 2, 'fb-share-1 buttons : 1');
	msg = ' - shareWithFB() linked to fb-share-1 button';
	assert.equal(shareWithFB, shareButtons[0].onclick, msg + ' 1');
	assert.equal(shareWithFB, shareButtons[1].onclick, msg + ' 2');

	var shareButtons = $('.fb-share-2');
	assert.equal(shareButtons.length, 1, 'fb-share-2 buttons : 1');
	msg = ' shareWithFB() linked to fb-share-2 button';
	assert.equal(shareWithFB, shareButtons[0].onclick, msg + ' 1');

	var shareButtons = $('.gplus-share-1');
	msg = ' shareWithFB() not linked to GPlus button';
	assert.equal(shareButtons.length, 1, 'Gplus share buttons : 1');
	assert.notEqual(shareWithFB, shareButtons[0].onclick, msg + ' 1');

});

QUnit.asyncTest("showGPlusShares() single share_name", function(assert) {

	var $fixture = $("#qunit-fixture");
	$fixture.append("<input type='hidden' class='share_name' value='share-1'></input>");
	$fixture.append("<input type='hidden' id='share-1_share_target' value='http://example.org'>");
	$fixture.append("<span id='span-1' class='share-locker gplus-share-1'></span>");
	$fixture.append("<span class='share-locker gplus-share-2'></span>");
	$fixture.append("<span class='share-locker fb-share-1'></span>");
	$fixture.append("<span class='share-locker fb-share-1'></span>");

	showGPlusShares();

	var shareButtons = $('.gplus-share-1');
	assert.equal(shareButtons.length, 1, 'gplus-share-1 buttons : 1');

	setTimeout(function() {
		assert.ok($(shareButtons[0]).attr('data-gapiattached'), 'gapi attached');
		QUnit.start();
	}, 1000);

});

QUnit.asyncTest("showGPlusShares() multi share_name", function(assert) {

	QUnit.stop();

	var $fixture = $("#qunit-fixture");
	$fixture.append("<input type='hidden' class='share_name' value='share-1'></input>");
	$fixture.append("<input type='hidden' class='share_name' value='share-2'></input>");
	$fixture.append("<input type='hidden' id='share-1_share_target' value='http://example.org'>");
	$fixture.append("<input type='hidden' id='share-2_share_target' value='http://example.org'>");
	$fixture.append("<span id='span-1' class='share-locker gplus-share-1'></span>");
	$fixture.append("<span id='span-2' class='share-locker gplus-share-2'></span>");
	$fixture.append("<span class='share-locker fb-share-1'></span>");
	$fixture.append("<span class='share-locker fb-share-1'></span>");

	showGPlusShares();

	var shareButtons = $('.gplus-share-1');
	assert.equal(shareButtons.length, 1, 'gplus-share-1 buttons : 1');
	button1 = shareButtons[0];
	setTimeout(function() {
		assert.ok($(button1).attr('data-gapiattached'), 'gapi attached');
		QUnit.start();
	}, 1000);

	var shareButtons = $('.gplus-share-2');
	assert.equal(shareButtons.length, 1, 'gplus-share-1 buttons : 1');

	button2 = shareButtons[0];
	setTimeout(function() {
		assert.ok($(button2).attr('data-gapiattached'), 'gapi attached');
		QUnit.start();
	}, 1000);

});

QUnit.test('getGPlusShareOptions()', function(assert) {
	options = getGPlusShareOptions('share-1', 'http://example.org');
	assert.equal(options.contenturl, 'http://example.org');
	assert.equal(options.clientid, sos_data.gplus_client_id);
	assert.equal(options.cookiepolicy, 'single_host_origin');
	assert.equal(options.calltoactionlabel, 'DISCOVER');
	assert.equal(options.calltoactionurl, 'http://example.org');

	onsharefunc = 'function (response) {\n' + '\t    handleGPlusResponse(shareName, response);\n' + '\t}';
	assert.equal(options.onshare.toString(), onsharefunc);
});

QUnit.test('unlockContent() sos-content - cookie not set', function(assert) {
	var $fixture = $("#qunit-fixture");
	$fixture.append("<div class='share-1-sos-content sos-hide'></div>");
	$fixture.append("<div class='share-1-sos-content sos-hide'></div>");
	$fixture.append("<div class='share-2-sos-content sos-hide'></div>");

	unlockContent('share-1');

	var shares = $('.share-1-sos-content');
	assert.equal(shares.length, 2, 'share-1-sos-content - 2 items');
	assert.equal($(shares[0]).attr('class'), 'share-1-sos-content sos-hide', 'content hidden');
	assert.equal($(shares[1]).attr('class'), 'share-1-sos-content sos-hide', 'content hidden');

	var shares = $('.share-2-sos-content');
	assert.equal(shares.length, 1, 'share-2-sos-content - 1 items');
	assert.equal($(shares[0]).attr('class'), 'share-2-sos-content sos-hide', 'content state not changed');

});

QUnit.test('unlockContent() sos-content - cookie set', function(assert) {
	var $fixture = $("#qunit-fixture");
	$fixture.append("<div class='share-1-sos-content sos-hide'></div>");
	$fixture.append("<div class='share-1-sos-content sos-hide'></div>");
	$fixture.append("<div class='share-2-sos-content sos-hide'></div>");

	document.cookie = 'share-1=true; Path=/;';
	unlockContent('share-1');

	var shares = $('.share-1-sos-content');
	assert.equal(shares.length, 2, 'share-1-sos-content - 2 items');
	assert.equal($(shares[0]).attr('class'), 'share-1-sos-content', 'content unlocked');
	assert.equal($(shares[1]).attr('class'), 'share-1-sos-content', 'content unlocked');

	var shares = $('.share-2-sos-content');
	assert.equal(shares.length, 1, 'share-2-sos-content - 1 items');
	assert.equal($(shares[0]).attr('class'), 'share-2-sos-content sos-hide', 'content state not changed');

	delete_cookie('share-1');
});

QUnit.test('unlockContent() sos-locker - cookie not set', function(assert) {
	var $fixture = $("#qunit-fixture");
	$fixture.append("<div class='share-1-sos-locker'></div>");
	$fixture.append("<div class='share-1-sos-locker'></div>");
	$fixture.append("<div class='share-2-sos-locker'></div>");

	unlockContent('share-1');

	var shares = $('.share-1-sos-locker');
	assert.equal(shares.length, 2, 'share-1-sos-locker - 2 items');
	assert.equal($(shares[0]).attr('class'), 'share-1-sos-locker', 'locker active');
	assert.equal($(shares[1]).attr('class'), 'share-1-sos-locker', 'locker active');

	var shares = $('.share-2-sos-locker');
	assert.equal(shares.length, 1, 'share-2-sos-locker - 1 item');
	assert.equal($(shares[0]).attr('class'), 'share-2-sos-locker', 'locker state not changed');

});

QUnit.test('unlockContent() sos-locker - cookie set', function(assert) {
	var $fixture = $("#qunit-fixture");
	$fixture.append("<div class='share-1-sos-locker'></div>");
	$fixture.append("<div class='share-1-sos-locker'></div>");
	$fixture.append("<div class='share-2-sos-locker'></div>");

	document.cookie = 'share-1=true; Path=/;';
	unlockContent('share-1');

	var shares = $('.share-1-sos-locker');
	assert.equal(shares.length, 2, 'share-1-sos-locker - 2 items');
	assert.equal($(shares[0]).attr('class'), 'share-1-sos-locker sos-hide', 'locker hidden');
	assert.equal($(shares[1]).attr('class'), 'share-1-sos-locker sos-hide', 'locker hidden');

	var shares = $('.share-2-sos-locker');
	assert.equal(shares.length, 1, 'share-2-sos-locker - 1 item');
	assert.equal($(shares[0]).attr('class'), 'share-2-sos-locker', 'locker state not changed');

	delete_cookie('share-1');
});

QUnit.test('processLockers() single share-name', function(assert) {
	var $fixture = $("#qunit-fixture");

	// single share
	$fixture.append("<input type='hidden' class='share_name' value='share-1'></input>");

	$fixture.append("<div class='share-1-sos-content sos-hide'></div>");
	$fixture.append("<div class='share-1-sos-content sos-hide'></div>");
	$fixture.append("<div class='share-2-sos-content sos-hide'></div>");

	$fixture.append("<div class='share-1-sos-locker'></div>");
	$fixture.append("<div class='share-1-sos-locker'></div>");
	$fixture.append("<div class='share-2-sos-locker'></div>");

	document.cookie = 'share-1=true; Path=/;';
	processLockers();

	var shares = $('.share-1-sos-content');
	assert.equal(shares.length, 2, 'share-1-sos-content - 2 items');
	assert.equal($(shares[0]).attr('class'), 'share-1-sos-content', 'content unlocked');
	assert.equal($(shares[1]).attr('class'), 'share-1-sos-content', 'content unlocked');

	var shares = $('.share-2-sos-content');
	assert.equal(shares.length, 1, 'share-2-sos-content - 1 items');
	assert.equal($(shares[0]).attr('class'), 'share-2-sos-content sos-hide', 'content state not changed');

	// lockers
	var shares = $('.share-1-sos-locker');
	assert.equal(shares.length, 2, 'share-1-sos-locker - 2 items');
	assert.equal($(shares[0]).attr('class'), 'share-1-sos-locker sos-hide', 'locker hidden');
	assert.equal($(shares[1]).attr('class'), 'share-1-sos-locker sos-hide', 'locker hidden');

	var shares = $('.share-2-sos-locker');
	assert.equal(shares.length, 1, 'share-2-sos-locker - 1 item');
	assert.equal($(shares[0]).attr('class'), 'share-2-sos-locker', 'locker state not changed');

	delete_cookie('share-1');
});

QUnit.test('processLockers() multi share-name', function(assert) {
	var $fixture = $("#qunit-fixture");

	// multi share
	$fixture.append("<input type='hidden' class='share_name' value='share-1'></input>");
	$fixture.append("<input type='hidden' class='share_name' value='share-2'></input>");

	$fixture.append("<div class='share-1-sos-content sos-hide'></div>");
	$fixture.append("<div class='share-1-sos-content sos-hide'></div>");
	$fixture.append("<div class='share-2-sos-content sos-hide'></div>");

	$fixture.append("<div class='share-1-sos-locker'></div>");
	$fixture.append("<div class='share-1-sos-locker'></div>");
	$fixture.append("<div class='share-2-sos-locker'></div>");

	document.cookie = 'share-1=true; Path=/;';
	document.cookie = 'share-2=true; Path=/;';
	processLockers();

	var shares = $('.share-1-sos-content');
	assert.equal(shares.length, 2, 'share-1-sos-content - 2 items');
	assert.equal($(shares[0]).attr('class'), 'share-1-sos-content', 'content unlocked');
	assert.equal($(shares[1]).attr('class'), 'share-1-sos-content', 'content unlocked');

	var shares = $('.share-2-sos-content');
	assert.equal(shares.length, 1, 'share-2-sos-content - 1 items');
	assert.equal($(shares[0]).attr('class'), 'share-2-sos-content', 'content unlocked');

	// lockers
	var shares = $('.share-1-sos-locker');
	assert.equal(shares.length, 2, 'share-1-sos-locker - 2 items');
	assert.equal($(shares[0]).attr('class'), 'share-1-sos-locker sos-hide', 'locker hidden');
	assert.equal($(shares[1]).attr('class'), 'share-1-sos-locker sos-hide', 'locker hidden');

	var shares = $('.share-2-sos-locker');
	assert.equal(shares.length, 1, 'share-2-sos-locker - 1 item');
	assert.equal($(shares[0]).attr('class'), 'share-2-sos-locker sos-hide', 'locker hidden');

	delete_cookie('share-1');
	delete_cookie('share-2');
});

QUnit.test('getShareNames()', function(assert) {

	var shareNames = getShareNames();
	assert.equal(0, shareNames.length);

	var $fixture = $("#qunit-fixture");
	$fixture.append("<input type='hidden' class='share_name' value='share-1'></input>");
	$fixture.append("<input type='hidden' class='share_name' value='share-2'></input>");
	$fixture.append("<input type='hidden' class='share_name' value='share-3'></input>");

	var result = getShareNames();

	assert.equal(result.length, 3);
	assert.equal(result[0].value, 'share-1');
	assert.equal(result[1].value, 'share-2');
	assert.equal(result[2].value, 'share-3');

});

QUnit.test('getShareName()', function(assert) {

	var $fixture = $("#qunit-fixture");
	$fixture.append("<span id='fb_10-share-1' class='share-locker fb-share'></span>");
	$fixture.append("<span id='gplus_x_10-test-share-1_1' class='share-locker gplus-share'></span>");
	$fixture.append("<span class='share-locker twitter-share'></span>");
	$fixture.append("<span id='linkedin_10_test_1_1' class='share-locker linkedin-share'></span>");

	var elements = $('.fb-share');
	assert.equal(elements.length, 1);

	var result = getShareName(elements[0]);
	assert.equal(result, 'share-1');

	elements = $('.gplus-share');
	assert.equal(elements.length, 1);

	result = getShareName(elements[0]);
	assert.equal(result, 'test-share-1_1');

	elements = $('.twitter-share');
	assert.equal(elements.length, 1);

	result = getShareName(elements[0]);
	assert.equal(result, undefined);

	elements = $('.linkedin-share');
	assert.equal(elements.length, 1);

	result = getShareName(elements[0]);
	assert.equal(result, undefined);
});

QUnit.test("getShareTarget()", function(assert) {

	var $fixture = $("#qunit-fixture");
	$fixture.append("<input type='hidden' id='share-1_share_target' value='http://example.org'></input>");
	$fixture.append("<input type='hidden' id='share-2_share_target' value='http://example.org/wordpress'></input>");

	var result = getShareTarget('share-1');
	assert.equal(result, 'http://example.org');

	var result = getShareTarget('share-2');
	assert.equal(result, 'http://example.org/wordpress');

	var result = getShareTarget('share-3');
	assert.equal(result, undefined);

});

QUnit.test('getShareSpans()', function(assert) {
	var $fixture = $("#qunit-fixture");
	$fixture.append("<span id='fb_10-share-1' class='share-locker fb-share-1'></span>");
	$fixture.append("<span id='fb_20-share-1' class='share-locker fb-share-1'></span>");
	$fixture.append("<span id='gplus_10-share-1' class='share-locker gplus-share-1'></span>");
	$fixture.append("<span id='gplus_10-share-2' class='share-locker gplus-share-2'></span>");
	$fixture.append("<span id='gplus_20-share-2' class='share-locker gplus-share-2'></span>");

	var result = getShareSpans('share-1', 'fb');
	assert.equal(result.length, 2);
	assert.equal(result[0].id, 'fb_10-share-1');
	assert.equal(result[1].id, 'fb_20-share-1');

	var result = getShareSpans('share-1', 'gplus');
	assert.equal(result.length, 1);
	assert.equal(result[0].id, 'gplus_10-share-1');

	var result = getShareSpans('share-2', 'gplus');
	assert.equal(result.length, 2);
	assert.equal(result[0].id, 'gplus_10-share-2');
	assert.equal(result[1].id, 'gplus_20-share-2');
});

QUnit.test('isCookieSet()', function(assert) {

	assert.ok(!isCookieSet('share-1'), 'cookie not set');

	document.cookie = 'share-1=true; Path=/;';
	assert.ok(isCookieSet('share-1'), 'cookie set');

	delete_cookie('share-1');
});

QUnit.test('createCookie()', function(assert) {
	var hours = 2;
	var now = new Date();

	var dateLow = new Date();
	dateLow.setTime(now.getTime() + (hours * 60 * 60 * 1000));

	var dateHigh = new Date();
	dateHigh.setTime(now.getTime() + (hours * 60 * 60 * 1000) + 10);

	expireDate = createCookie('share-1', true, hours);
	assert.ok(isCookieSet('share-1'), 'cookie set');

	assert.ok((expireDate >= dateLow && expireDate < dateHigh), 'cookie expiry is within range');

	delete_cookie('share-1');
});

QUnit.test('openLocker()', function(assert) {

	var $fixture = $("#qunit-fixture");

	$fixture.append("<input type='hidden' class='share_name' value='share-1'></input>");

	$fixture.append("<div class='share-1-sos-content sos-hide'></div>");
	$fixture.append("<div class='share-1-sos-content sos-hide'></div>");
	$fixture.append("<div class='share-2-sos-content sos-hide'></div>");

	$fixture.append("<div class='share-1-sos-locker'></div>");
	$fixture.append("<div class='share-1-sos-locker'></div>");
	$fixture.append("<div class='share-2-sos-locker'></div>");

	openLocker('share-1');

	assert.ok(isCookieSet('share-1'), 'cookie set');

	var shares = $('.share-1-sos-content');
	assert.equal(shares.length, 2, 'share-1-sos-content - 2 items');
	assert.equal($(shares[0]).attr('class'), 'share-1-sos-content', 'content unlocked');
	assert.equal($(shares[1]).attr('class'), 'share-1-sos-content', 'content unlocked');

	var shares = $('.share-2-sos-content');
	assert.equal(shares.length, 1, 'share-2-sos-content - 1 items');
	assert.equal($(shares[0]).attr('class'), 'share-2-sos-content sos-hide', 'content state not changed');

	// lockers
	var shares = $('.share-1-sos-locker');
	assert.equal(shares.length, 2, 'share-1-sos-locker - 2 items');
	assert.equal($(shares[0]).attr('class'), 'share-1-sos-locker sos-hide', 'locker hidden');
	assert.equal($(shares[1]).attr('class'), 'share-1-sos-locker sos-hide', 'locker hidden');

	var shares = $('.share-2-sos-locker');
	assert.equal(shares.length, 1, 'share-2-sos-locker - 1 item');
	assert.equal($(shares[0]).attr('class'), 'share-2-sos-locker', 'locker state not changed');

	delete_cookie('share-1');
});

function delete_cookie(name) {
	document.cookie = name + '=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}
