Debug
-----

enable debug 
install debug bar plugin

Options
-------

in tests toggle options as
 $GLOBALS['wp_tests_options']['sos_test'] = false;

How to know to what to test
---------------------------

class-options.php is simple but has all types of tests

browse the wp source code for the function 
example - register_post_type() add entry to global $wp_post_types

grep for func-name in wp directory

print_r the global for registered items

example test_setup_meta_boxes in test-sos.php

about WP_Screen in test-share-on-social.php

no much difference between backupGlobals true or false - actions i
 set in in test are removed after the test

phpunit.xml  directory (all tests) gives problem  
1. when backupGlobals=true or 2. testing the includes 

yum install php-devel
pecl install xdebug

Ajax tests -  Risky
-------------------

following items resolve the issue

for ajax test class add @runTestsInSeparateProcesses
in config - WP_DEBUG set false 
in config - set WP_TESTS_DOMAIN to localhost

following items will not resolve the issue

network should be up else tests pass as risky
hack - don't use wp-die to send data
       use echo to send the data and terminate with wp_die() without any args 
       in test catch WPAjaxDieContinueException and get data using $actual = $this->_last_response

Test db error
-------------

mysql -p -u wptest wptest
MySQL [wptest]> show tables;
MySQL [wptest]> drop table wptests_terms;


Setup translations for unit test
--------------------------------

install wp i18n tools
---------------------

cd /var/www/html
svn co http://develop.svn.wordpress.org/trunk/tools/

cd /var/www/html
ln -s . src

in phpunit.xml set backupGlobals as true else textdomain will not unload between
tests. If it is false then we need to call unload_textdomain() in teardown.

make pot 
--------

cd wp-content/plugins/share-on-social/
php /var/www/html/tools/i18n/makepot.php wp-plugin .
mv share-on-social.pot sos-domain.pot
mv sos-domain.pot tests/languages/

make po and mo
--------------

cd tests/languages/
msginit -i sos-domain.pot -o sos-domain-en_US.po -l en_US
msginit -i sos-domain.pot -o sos-domain-eo_FR.po -l eo_FR

cp sos-domain-en_US.po temp.po
edit temp.po and append test to all translated strings with  %s/^msgstr "/msgstr "Espéranto-France /g
replace temp.po header with sos-domain-eo_FR.po header

mv temp.po sos-domain-eo_FR.po

msgfmt -o sos-domain-eo_FR.mo  sos-domain-eo_FR.po


eclipse
-------

donot import instead use new folder and link to /var/www/html/wp-content/plugins/share-on-social/


change log
----------

Oct 23 moved backupGlobals in phpunit.xml to true and cleaned many teardown()


todo
----

variable names
add fb default id to activation
add settings to activation
version upgrade
check default scripts avoid custom scripts
debug output, minify, CDATA, version number
comments
test against 4.0
test from subdomain
test for multisite

https://wordpress.org/plugins/about/faq/
read  articale by Joost de Valk
localhost functional test with check debug log
functional test with check debug log
disable SOS_DEV before submission


dev notes
---------

comments after end html is not minified even without CDATA

W3 Total will not minifiy this

<!-- <![CDATA[ maithilish_comment comments by m ]]> -->

but next one gets minified

<![CDATA[  <!-- maithilish_comment comments by m --> ]]>

 


functional tests
----------------

http://dev-wordpressguide.rhcloud.com/

basic locker

- target page 
- target parent
- target site
- enable/disable fb
- enable/disable gplus
- enable/disable twitter
- no fb app id
- no gplus app id

- with id as basic
- one share with share name
- two shares with share name
- with id as basic with link  


test debug data in openshift and w3 total minify

