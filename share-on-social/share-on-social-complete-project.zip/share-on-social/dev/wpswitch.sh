echo
echo -e '\t    \tSwitch WordPress'
echo 
echo -e '\t  1 \tWP 3  -  Single'
echo -e '\t  2 \tWP 3  -  Multi'
echo -e '\t  3 \tWP 4  -  Single'
echo -e '\t  4 \tWP 4  -  Multi'
echo
echo
echo -en "\t    \tSelect : "
read choice
echo

function single_to_multi(){
	sed -i 's#single#multi#' index.php
	sed -i 's#single#multi#' .htaccess 
}

function multi_to_single(){
        sed -i 's#multi#single#' index.php
        sed -i 's#multi#single#' .htaccess 
}

function wp3_to_wp4(){
	sed -i 's#wp3#wp4#' index.php
	sed -i 's#wp3#wp4#' .htaccess 
}

function wp4_to_wp3(){
	sed -i 's#wp4#wp3#' index.php
	sed -i 's#wp4#wp3#' .htaccess 
}

if [ "$choice" -eq "1" ]
then
	multi_to_single
        wp4_to_wp3 
	echo -e 'Switched to : WP 3 Single'
fi 

if [ "$choice" -eq "2" ]
then
	single_to_multi
	wp4_to_wp3
	echo -e 'Switched to : WP 3 Multi'
fi 

if [ "$choice" -eq "3" ]
then
	multi_to_single
	wp3_to_wp4
	echo -e 'Switched to : WP 4 Single'
fi 

if [ "$choice" -eq "4" ]
then
	single_to_multi
	wp3_to_wp4
	echo -e 'Switched to : WP 4 Multi'
fi 

echo
