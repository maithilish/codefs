SOS_SVN_REPO=/orange/work/share-on-social/trunk

rsync -r admin $SOS_SVN_REPO
rsync -r css $SOS_SVN_REPO
rsync -r frontend $SOS_SVN_REPO
rsync -r images $SOS_SVN_REPO
rsync -r include $SOS_SVN_REPO
rsync -r js $SOS_SVN_REPO
rsync -r langs $SOS_SVN_REPO

rsync readme.txt $SOS_SVN_REPO
rsync share-on-social.php $SOS_SVN_REPO
rsync uninstall.php $SOS_SVN_REPO
