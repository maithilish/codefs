# Share on Social Plugin Devops

## Run Wordpress Container

    export WORK_DIR=/orange/work/mywp ; mkdir -p $WORK_DIR; cd $WORK_DIR
    git clone /orange/repo/gitor/share-on-social.git
    cp share-on-social/dev/docker-compose.yml .
    docker-compose up

## Setup wordpress

open http://localhost:8000 and complete wp setup

## Clone share-on-social from repo

    cd $WORK_DIR
    sudo mv share-on-social wp/wp-content/plugins
    sudo chown m.www-data wp/wp-content/plugins/share-on-social -R
    sudo chmod 755 wp/wp-content/plugins/share-on-social -R

owner.group: m.www-data permissions: rwxr-xr-x

## Checkout and Sync last commit

    cd /orange/work
    svn co https://plugins.svn.wordpress.org/share-on-social
    cd share-on-social/trunk
    rsync -r . $WORK_DIR/wp/wp-content/plugins/share-on-social

edit share-on-social.php and uncomment  define( 'SOS_DEV', true );

## Activate and Check the Plugin

Use test FB user to share. Refer projects/wordpress entry in KeePass for user details and fb app id.

Activate the plugin and set facebook app id. Edit sample page and add some lockers.

    [share-on-social link='https://www.codetab.org']
        locked content 1
    [/share-on-social]


## Unit Testing

Extract wordpress source

    cd /orange/work
    unzip /orange/Downloads/wordpress.x.x.zip

Link sos plugin

    ln -s $WORK_DIR/wp/wp-content/plugins/share-on-social wordpress/wp-content/plugins

Create test database

    mysql -u root -proot -h 127.0.0.1
     create database wptest;
     GRANT ALL PRIVILEGES ON wptest.* TO wptest@localhost IDENTIFIED BY 'wptest';
     GRANT ALL PRIVILEGES ON wptest.* TO wptest@'%' IDENTIFIED BY 'wptest';
     flush privileges;

Test db connection
    mysql -u wptest -pwptest -h 127.0.0.1 wptest

Update lang files, see next section for details.

Run test

    cd $WORK_DIR/wp/wp-content/plugins/share-on-social
    phpunit

Run qunit tests

    open $WORK_DIR/wp/wp-content/plugins/share-on-social/qunit.html file in browser

## Setup lang files for tests

in phpunit.xml if backupGlobals is true else textdomain will not unload between
tests. If it is false then we need to call unload_textdomain() in teardown.

install gettext and wp-cli

	sudo apt install gettext
	curl -O https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar
	php wp-cli.phar --info
	chmod +x wp-cli.phar
	sudo mv wp-cli.phar /usr/local/bin/wp
	wp --info
	sudo apt-get install php7.4-mbstring	# change php version

make pot

pot is master file

	cd wp-content/plugins/share-on-social
	wp i18n make-pot . sos-domain.pot
	mv sos-domain.pot tests/phpunit/langs

make po

po files are for translation to other languages

	cd tests/phpunit/langs
	msginit -i sos-domain.pot -o sos-domain-en_US.po -l en_US
	cp sos-domain-en_US.po temp.po

	msginit -i sos-domain.pot -o sos-domain-eo_FR.po -l eo_FR

edit temp.po and append test to all translated strings with  %s/^msgstr "/msgstr "Espéranto-France /g
replace temp.po header with sos-domain-eo_FR.po header

	mv temp.po sos-domain-eo_FR.po

make mo

mo is binary file

	msgfmt -o sos-domain-eo_FR.mo sos-domain-eo_FR.po


## Plugin Functional Testing

test basic locker
test page, parent and site
with and without FB App ID
create custom locker
test custom locker with id attribute
test locker groups with name attribute - in page or across pages
test link attribute

During testing, use Inspect Element (Q) -> Storage Inspector -> Cookie to delete the cookies.

After release, test in live site.

## Release

update version in three places

    readme.txt - stable tag
    share-on-social.php - Version in front matter
    share-on-social.php - SOS_VERSION

after format and before zip edit style.css and add space around > update readme.txt

check cp2svn.sh and ensure that var SOS_SVN_REPO points to downloaded source folder and then sync back the changes.

    cp2svn.sh

go to downloaded plugin source folder and edit trunk/share-on-social.php and comment  define( 'SOS_DEV', true );

    svn stat
    svn diff
    svn add trunk/*     // only for new items else just commit
    svn --username maithilish ci -m 'update to 1.0.2'

In svn, even after add, the stat lists the modified files and only after commit they are not listed.

next create tag and commit (from latest tag users download the plugin)

    svn cp trunk tags/1.0.2
    svn ci -m "tagging version 1.0.2"

In case, you cp tag again then, before copy, delete with `svn del tags/1.0.2`.

browse the repository and refresh tag/<latest>/readme.txt file and changes should be visible in plugin page if not try ctrl+f5 on readme.txt or wait for couple of minutes

For codefs, just zip the complete folder.