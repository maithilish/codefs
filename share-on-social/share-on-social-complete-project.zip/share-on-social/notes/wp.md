## Debug

enable debug
install debug bar plugin
output debug message  error_log()

## Options

in tests toggle options as
 $GLOBALS['wp_tests_options']['sos_test'] = false;

## What to test

class-options.php is simple but has all types of tests

browse the wp source code for the function
example - register_post_type() add entry to global $wp_post_types

grep for func-name in wp directory

print_r the global for registered items

example test_setup_meta_boxes in test-sos.php

about WP_Screen in test-share-on-social.php

no much difference between backupGlobals true or false - actions i
 set in in test are removed after the test

phpunit.xml  directory (all tests) gives problem
1. when backupGlobals=true or 2. testing the includes

yum install php-devel
pecl install xdebug

## Ajax tests -  Risky

following items resolve the issue

for ajax test class add @runTestsInSeparateProcesses
in config - WP_DEBUG set false
in config - set WP_TESTS_DOMAIN to localhost

following items will not resolve the issue

network should be up else tests pass as risky
hack - don't use wp-die to send data
       use echo to send the data and terminate with wp_die() without any args
       in test catch WPAjaxDieContinueException and get data using $actual = $this->_last_response

## Test db error

mysql -p -u wptest wptest
MySQL [wptest]> show tables;
MySQL [wptest]> drop table wptests_terms;

## Comments

comments after end html is not minified even without CDATA

W3 Total will not minifiy this

<!-- <![CDATA[ maithilish_comment comments by m ]]> -->

but next one gets minified

<![CDATA[  <!-- maithilish_comment comments by m --> ]]>
