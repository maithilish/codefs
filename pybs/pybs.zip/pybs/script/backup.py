import yaml
import os
import sys
import datetime
from subprocess import call

def getNames(backups):
    return backups.keys()

def getDirs(backups,name):
    return backups[name]["dirs"]

def getExcludes(backups,name):
    if( "excludes" in backups[name]):
      return backups[name]["excludes"]
    else:
      return list()

def matchLabel(backups,name,label):
    if( "label" in backups[name]):
      plabel = backups[name]["label"]  ## label from backup list
      if(plabel == label):
        return True
      else:
        return False
    else:
      print("backup: " + name + " [error], label not set")
      return False
      
def isAllDirsExists(dirs):
    allExists = True
    for dir in dirs:
      if(os.path.exists(dir) == False ):
        allExists = False
    return allExists

def createCommand(repoArchive, dirs, excludes):
    args = ["borg","create"]
    for exclude in excludes:
      args.append("-e")
      args.append(exclude)
    args.append(repoArchive)
    for dir in dirs:
      args.append(dir)
    return args

def borgBackup(repoArchive, name, dirs, excludes):
    cmd = createCommand(repoArchive, dirs, excludes)
    status = call(cmd)
    return status

## start

if sys.version_info[0] < 3:
    raise Exception("Python 3 or a more recent version is required.")

backupListFile = sys.argv[1]
label = sys.argv[2]

timestamp = datetime.datetime.now().strftime("%s")
year = datetime.datetime.now().strftime("%Y")

yamlStream = open(backupListFile, 'r')
conf = (yaml.load(yamlStream, yaml.FullLoader))

repo = conf["repo"]
backups = conf["backups"]

names = getNames(backups)

for name in names:
    if(matchLabel(backups,name,label)):
      repoArchive = repo + "::" + year + "-" + name + "-" + timestamp
      dirs = getDirs(backups,name)
      if(isAllDirsExists(dirs)):
        excludes = getExcludes(backups,name)
        status = borgBackup(repoArchive, name, dirs, excludes)
        if(status == 0):
          print("backup: " + name + " [ok], archived to " + repoArchive)
        else:
          print("backup: " + name + " [error], borg error")
      else:
        print("backup: " + name + " [error], some dirs doesn't exists")

