#!/usr/bin/env bash

echo "delay start: $DELAY_START_SEC seconds"
sleep $DELAY_START_SEC

count=0
while pgrep -x "borg" > /dev/null
do
   sleep 5
   let count=count+5
done

if [ "$count" -gt "0" ]
then 
  echo "waited $count seconds for another borg process to end"
fi

/usr/bin/borg break-lock $REPO_PATH

python3 $BASE_DIR/script/backup.py $BASE_DIR/$BACKUP_LIST $LABEL



