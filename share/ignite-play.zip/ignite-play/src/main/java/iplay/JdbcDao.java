package iplay;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcDao {

    private Connection conn;
    private int maxTry = 1;

    public void setMaxTry(final int maxTry) {
        if (maxTry > 1) {
            this.maxTry = maxTry;
        }
    }

    public boolean initConnection() throws Exception {
        Class.forName("org.apache.ignite.IgniteJdbcThinDriver");
        conn = DriverManager
                .getConnection("jdbc:ignite:thin://127.0.0.1:10800..10900");
        conn.setAutoCommit(true);
        return true;
    }

    public boolean closeConnection() {
        try {
            conn.close();
            System.out.println("jdbc connection closed");
        } catch (final SQLException e) {
            e.printStackTrace();
        }
        return true;
    }

    public boolean createTables() throws SQLException {
        String sql = joinStrings(
                "create table IF NOT EXISTS data (id int primary key,",
                "state varchar(10), data varchar(20))",
                "WITH \"template=REPLICATED,atomicity=ATOMIC\"");
        execute(sql);

        sql = joinStrings("create table IF NOT EXISTS keystore",
                "(key varchar(128) primary key not null, value varchar(128))",
                "WITH \"template=REPLICATED,atomicity=ATOMIC\"");
        execute(sql);

        return true;
    }

    public boolean putData(final long id, final String data)
            throws SQLException {
        final String sql = "insert into data (id, state,data) values(?,?,?)";
        return execute(sql, id, "NEW", data);
    }

    public int getDataCount() throws Exception {
        final String sql = "SELECT count(*) from data";
        return execute(sql, (rs -> {
            rs.next();
            return rs.getInt(1);
        }));
    }

    public String getLastData() throws Exception {
        final String sql = "SELECT data from data order by id desc";
        return execute(sql, (rs -> {
            rs.next();
            return rs.getString(1);
        }));
    }

    public int getMaxDataId() throws Exception {
        final String sql = "SELECT max(id) from data";
        return execute(sql, (rs -> {
            rs.next();
            return rs.getInt(1);
        }));
    }

    // Helper Methods - with retry jdbc calls in case of error
    // fetch value from result set
    private <R> R execute(final String sql, final SqlFunction<ResultSet, R> f)
            throws SQLException {
        R r = null;
        int tries = 1;
        while (tries <= maxTry) {
            try (Statement stmt = conn.createStatement();
                    ResultSet rs = stmt.executeQuery(sql)) {
                r = f.apply(rs);
                break;
            } catch (final SQLException e) {
                System.out.println("tries " + tries);
                if (tries == maxTry) {
                    throw e;
                }
                tries++;
            }
        }
        return r;
    }

    // execute prepared statement
    private boolean execute(final Object... args)
            throws SQLException {
        final String sql = (String) args[0];
        Boolean r = null;
        int tries = 1;
        while (tries <= maxTry) {
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                for (int p = 1; p < args.length; p++) {
                    stmt.setObject(p, args[p]);
                }
                r = stmt.execute();
                break;
            } catch (final SQLException e) {
                System.out.println("tries " + tries);
                if (tries == maxTry) {
                    throw e;
                }
                tries++;
            }
        }
        return r;
    }

    private static String joinStrings(final String... parts) {
        return String.join(" ", parts);
    }
}
