package iplay;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteAtomicLong;
import org.apache.ignite.Ignition;
import org.apache.ignite.cluster.ClusterNode;

public class GridNode {

    private Ignite ignite;
    private IgniteAtomicLong seq;

    public void start() {
        System.setProperty("IGNITE_QUIET", "true");
        System.setProperty("IGNITE_NO_ASCII", "true");
        System.setProperty("IGNITE_PERFORMANCE_SUGGESTIONS_DISABLED", "true");
        System.setProperty("IGNITE_CONSOLE_APPENDER", "false");

        // ignite = Ignition.start();
        ignite = Ignition.start("config/example-cache.xml");

        final ClusterNode lnode = ignite.cluster().localNode();
        System.out.printf("\nnode id: %s \n\n", lnode.id());
    }

    public long getSeq() {
        seq = ignite.atomicLong("seqName", 0, true);
        return seq.getAndIncrement();
    }

    public void stop() {
        ignite.close();
    }
}
