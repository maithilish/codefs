package iplay;

public class App {

    public static void main(final String[] args) {

        final GridNode gridNode = new GridNode();
        final JdbcDao dao = new JdbcDao();

        try {
            // start ignite
            gridNode.start();

            // max retries in case of SQL exception
            dao.setMaxTry(4);
            // init ignite db
            dao.initConnection();
            dao.createTables();

            // insert some data
            for (int i = 0; i < 100; i++) {
                final long id = gridNode.getSeq();
                dao.putData(id, "data-" + id);
                showProgress(dao.getMaxDataId());
                pause(100);
            }

            // finish
            System.out.println("");
            System.out.println("Records count: " + dao.getDataCount());
            System.out.println("Last data: " + dao.getLastData());
            pause(1000);
        } catch (final Exception e) {
            e.printStackTrace();
        } finally {
            dao.closeConnection();
            pause(1000);
            gridNode.stop();
            // System.exit(0);
        }
    }

    public static void showProgress(final int c) {
        if (c != 0 && c % 100 == 0) {
            System.out.println(c);
        } else {
            if (c % 10 == 0) {
                System.out.print(c + " ");
            }
        }
    }

    public static void pause(final int ms) {
        try {
            Thread.sleep(ms);
        } catch (final InterruptedException e) {
            System.err.format("IOException: %s%n", e);
        }
    }
}
