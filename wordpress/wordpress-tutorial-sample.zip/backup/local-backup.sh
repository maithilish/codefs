#!/bin/bash

DATE=`date +"%Y-%m-%d"`
BACKUP_DIR=$OPENSHIFT_DATA_DIR/backup
ARCHIVE_FILE=$OPENSHIFT_APP_NAME-wordpress-backup-$DATE.tar


## MySQL dump

DB_NAME=$OPENSHIFT_APP_NAME
MYSQLDUMP_FILE="$OPENSHIFT_APP_NAME-$DATE.sql"
mysqldump -u $OPENSHIFT_MYSQL_DB_USERNAME --password=$OPENSHIFT_MYSQL_DB_PASSWORD     \
          -S $OPENSHIFT_MYSQL_DB_SOCKET $DB_NAME > $BACKUP_DIR/$MYSQLDUMP_FILE
if [ $? -ne 0 ]; then
	echo "MySQL backup failed. Backup aborted ..."
	rm $BACKUP_DIR/$MYSQLDUMP_FILE
	exit 1
fi


## archive Wordpress
tar -cf "$BACKUP_DIR/$ARCHIVE_FILE" -C $OPENSHIFT_DATA_DIR  plugins themes uploads 

## append MySQL dump to archive (-r appends files to archive)
tar -rf "$BACKUP_DIR/$ARCHIVE_FILE" -C $BACKUP_DIR $MYSQLDUMP_FILE
rm $BACKUP_DIR/$MYSQLDUMP_FILE

## compress the archive
gzip "$BACKUP_DIR/$ARCHIVE_FILE"

