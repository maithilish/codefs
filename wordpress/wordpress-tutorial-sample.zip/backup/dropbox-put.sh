
TIMESTAMP=$(date +'%s')
TMPFILE=/tmp/dbox.tmp
BACKUP_DIR=$OPENSHIFT_DATA_DIR/backup
AUTHFILE=$BACKUP_DIR/.dropbox-auths
API_UPLOAD_URL="https://api-content.dropbox.com/1/files_put"

SRCFILE=$1
DSTFILE=$2

function removeTmpFile {
    if [ -f $TMPFILE ] 
    then
        rm $TMPFILE
    fi
}



source $AUTHFILE

## reset access level - auto 
ACCESS_LEVEL=auto

curl -s -i --globoff -o "$TMPFILE" --upload-file $SRCFILE "$API_UPLOAD_URL/$ACCESS_LEVEL/$DSTFILE?oauth_consumer_key=$APPKEY&oauth_token=$DBOX_ACCESS_TOKEN&oauth_signature_method=PLAINTEXT&oauth_signature=$APPSECRET%26$DBOX_ACCESS_TOKEN_SECRET&oauth_timestamp=$TIMESTAMP&oauth_nonce=$RANDOM"

if [ $? != "0" ]
then
	removeTmpFile
	exit 1
fi

if grep -q "^HTTP/1.1 200 OK" "$TMPFILE"
then
     removeTmpFile
     exit 0
else
     echo "----- Dropbox response -----"
     cat $TMPFILE
     echo -e "\n-----     -----"
     removeTmpFile
     exit 1
fi

