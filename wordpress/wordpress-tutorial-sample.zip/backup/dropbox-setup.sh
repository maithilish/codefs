#!/usr/bin/env bash

API_REQUEST_TOKEN_URL="https://api.dropbox.com/1/oauth/request_token"
API_USER_AUTH_URL="https://www2.dropbox.com/1/oauth/authorize"
API_ACCESS_TOKEN_URL="https://api.dropbox.com/1/oauth/access_token"

TIMESTAMP=$(date +'%s')
TMPFILE=/tmp/dbox.tmp
AUTHFILE=./.dropbox-auths
ACCESS_LEVEL="dropbox"

function exitOnError {
    CODE=$?
    if [[ $CODE != "0" ]] 
    then
    	echo "unable to proceed... exit"
        exit 1
    fi
}

function checkForTmpFile {
    if [ ! -f $TMPFILE ] 
    then
        echo "Response file not found. unable to proceed ..."
        exit 1
    fi
}

function removeTmpFile {
    if [ -f $TMPFILE ] 
    then
	rm $TMPFILE
    fi
}

function showDropboxResponse {
      echo
      echo "--------------------- Dropbox Says ---------------------"
      cat $TMPFILE
      echo
      echo "--------------------------------------------------------"
      echo
}

curl -s --show-error -I http://example.com > /dev/null
exitOnError


echo "Setup Dropbox for OpenShift"
echo 
echo "Create Dropbox app at https://www.dropbox.com/developers/apps and note down App Key and Secret"
echo -n "  Enter App key: "
read APPKEY

echo -n "  Enter App secret: "
read APPSECRET


#TOKEN REQUESTS
echo 
echo
echo "Step 1 : Requesting Token from Dropbox ... "
removeTmpFile
curl -s --show-error --globoff -i -o $TMPFILE --data "oauth_consumer_key=$APPKEY&oauth_signature_method=PLAINTEXT&oauth_signature=$APPSECRET%26&oauth_timestamp=$TIMESTAMP&oauth_nonce=$RANDOM" $API_REQUEST_TOKEN_URL 2> /dev/null

checkForTmpFile
DBOX_TOKEN_SECRET=$(sed -n 's/oauth_token_secret=\([a-z A-Z 0-9]*\).*/\1/p' $TMPFILE)
DBOX_TOKEN=$(sed -n 's/.*oauth_token=\([a-z A-Z 0-9]*\)/\1/p' $TMPFILE)
if [[ $DBOX_TOKEN == "" || $DBOX_TOKEN_SECRET = "" ]]; then
      showDropboxResponse
      echo "Check your App Key or Secret"
      exit 1
fi
removeTmpFile


#USER AUTH
echo 
echo "Step 2 - Now you have to allow access from dropbox side !!!" 
echo "  to do that open the following URL in your browser and allow access"
echo
echo "    ${API_USER_AUTH_URL}?oauth_token=$DBOX_TOKEN"
echo 
echo "  after you have done that press enter ..."
echo 
read

echo "Requesting Access Token ... "
curl -s --show-error --globoff -i -o $TMPFILE --data "oauth_consumer_key=$APPKEY&oauth_token=$DBOX_TOKEN&oauth_signature_method=PLAINTEXT&oauth_signature=$APPSECRET%26$DBOX_TOKEN_SECRET&oauth_timestamp=$TIMESTAMP&oauth_nonce=$RANDOM" $API_ACCESS_TOKEN_URL 2> /dev/null

checkForTmpFile
DBOX_ACCESS_UID=$(sed -n 's/.*uid=\([0-9]*\)/\1/p' "$TMPFILE")
DBOX_ACCESS_TOKEN=$(sed -n 's/.*oauth_token=\([a-z A-Z 0-9]*\)&.*/\1/p' "$TMPFILE")
DBOX_ACCESS_TOKEN_SECRET=$(sed -n 's/oauth_token_secret=\([a-z A-Z 0-9]*\)&.*/\1/p' $TMPFILE)
if [[ $DBOX_ACCESS_TOKEN == "" || $DBOX_ACCESS_TOKEN_SECRET = "" || $DBOX_ACCESS_UID == "" ]]; then
      echo 
      echo "Bad: Step 2 failed."
      echo 
      showDropboxResponse
      echo
      echo "Have you pressed ENTER  before allowing access from Dropbox in STEP 2 ???"
      echo 
      echo "Now only option is to run Setup again !!!"
      echo
      exit 1
fi
removeTmpFile

echo "Good: Step 2 successful. Saving Dropbox authorizations"

echo "APPKEY=$APPKEY" > "$AUTHFILE"
echo "APPSECRET=$APPSECRET" >> "$AUTHFILE"
echo "ACCESS_LEVEL=$ACCESS_LEVEL" >> "$AUTHFILE"
echo "DBOX_ACCESS_TOKEN=$DBOX_ACCESS_TOKEN" >> "$AUTHFILE"
echo "DBOX_ACCESS_TOKEN_SECRET=$DBOX_ACCESS_TOKEN_SECRET" >> "$AUTHFILE"

echo 
echo "Dropbox Setup complete !!!"
echo 

