package in.fins.server.dao.mybatis;

public class DaoHelper extends in.fins.server.dao.DaoHelper {

}
