package in.fins.server.dao.hibernate;

public class DaoHelper extends in.fins.server.dao.DaoHelper {

}
