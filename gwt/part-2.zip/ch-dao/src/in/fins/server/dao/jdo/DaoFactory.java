package in.fins.server.dao.jdo;

import in.fins.server.dao.IDao;
import in.fins.shared.Data;
import in.fins.shared.DataGroup;
import in.fins.shared.Symbol;

import java.util.logging.Logger;

import javax.jdo.PersistenceManagerFactory;

public class DaoFactory extends in.fins.server.dao.DaoFactory {

	private static final Logger log = Logger.getLogger(DaoFactory.class
			.getName());

	private PersistenceManagerFactory pmf;

	public DaoFactory() {
		pmf = PMF.get();
	}

	@Override
	public <T> IDao<T> getDao(Class<T> clz) throws Exception {
		if (clz == Symbol.class) {
			log.fine("JDO SymbolDao returned");
			return (IDao<T>) new SymbolDao<T>(pmf);
		}
		if (clz == Data.class) {
			log.fine("JDO DataDao returned");
			return (IDao<T>) new DataDao<T>(pmf);
		}
		if (clz == DataGroup.class) {
			log.fine("JDO DataGroupDao returned");
			return (IDao<T>) new DataGroupDao<T>(pmf);
		}
		log.fine("JDO Generic Dao returned");
		return (IDao<T>) new Dao<T>(pmf);
	}

}
