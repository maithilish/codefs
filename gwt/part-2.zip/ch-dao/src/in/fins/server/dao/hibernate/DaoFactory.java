package in.fins.server.dao.hibernate;

import in.fins.server.dao.IDao;
import in.fins.shared.Data;
import in.fins.shared.DataGroup;
import in.fins.shared.Symbol;

import java.util.logging.Logger;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class DaoFactory extends in.fins.server.dao.DaoFactory {

	private static final Logger log = Logger.getLogger(DaoFactory.class
			.getName());

	private SessionFactory sf;

	public DaoFactory() {
		try {
			Configuration configuration = new Configuration()
					.configure("META-INF/hibernate.cfg.xml");
			ServiceRegistry serviceRegistry = new ServiceRegistryBuilder()
					.applySettings(configuration.getProperties())
					.buildServiceRegistry();
			sf = configuration.buildSessionFactory(serviceRegistry);
		} catch (HibernateException e) {
			log.warning("Unable to initialize Hibernate SessionFactory");
			throw new ExceptionInInitializerError(e);
		}
	}

	@Override
	public <T> IDao<T> getDao(Class<T> clz) throws Exception {
		if (clz == Symbol.class) {
			log.fine("Hibernate SymbolDao returned");
			return (IDao<T>) new SymbolDao<T>(sf);
		}
		if (clz == Data.class) {
			log.fine("Hibernate DataDao returned");
			return (IDao<T>) new DataDao<T>(sf);
		}
		if (clz == DataGroup.class) {
			log.fine("Hibernate DataGroupDao returned");
			return (IDao<T>) new DataGroupDao<T>(sf);
		}
		log.fine("Hibernate Generic Dao returned");
		return (IDao<T>) new Dao<T>(sf);
	}

}
