package in.fins.server.dao.jdo;

import in.fins.server.dao.IDao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.Query;
import javax.persistence.PersistenceException;

public class Dao<T> implements IDao<T> {

	private static final Logger log = Logger.getLogger(Dao.class.getName());

	protected PersistenceManagerFactory pmf;

	public Dao(PersistenceManagerFactory pmf) {
		this.pmf = pmf;
		if (pmf == null)
			log.warning("Loading JDO PersistaceManagerFactory failed.");

	}

	@Override
	public T selectById(Class<T> clz, Map<?, ?> parameters)
			throws PersistenceException {
		PersistenceManager pm = pmf.getPersistenceManager();
		T obj;
		try {
			String id = (String) parameters.get("id");
			obj = pm.detachCopy(pm.getObjectById(clz, id));
		} catch (PersistenceException e) {
			log.severe(e.getMessage());
			throw e;
		} finally {
			pm.close();
		}
		return obj;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> select(Class<?> clz, Class<T> resultClz, String namedQuery,
			Map<?, ?> parameters) {
		PersistenceManager pm = pmf.getPersistenceManager();
		List<T> list = null;
		try {
			Query query = pm.newNamedQuery(clz, namedQuery);
			query.setResultClass(resultClz);
			List<T> l = null;
			if (parameters == null) {
				l = (List<T>) query.execute();
			} else {
				l = (List<T>) query.executeWithMap(parameters);
			}
			// eagerly load all
			list = new ArrayList<T>(l);
		} finally {
			pm.close();
		}
		return list;
	}

}
