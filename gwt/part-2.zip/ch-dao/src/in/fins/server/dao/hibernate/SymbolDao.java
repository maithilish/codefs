package in.fins.server.dao.hibernate;

import in.fins.server.dao.IDao;
import in.fins.shared.Symbol;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.persistence.PersistenceException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class SymbolDao<T> implements IDao<T> {

	private static final Logger log = Logger.getLogger(SymbolDao.class
			.getName());

	private SessionFactory sf;

	public SymbolDao(SessionFactory sf) {
		this.sf = sf;
		if (sf == null)
			log.warning("Loading Hibernate SessionFactory failed.");

	}

	@SuppressWarnings("unchecked")
	@Override
	public T selectById(Class<T> clz, Map<?, ?> parameters)
			throws PersistenceException {
		Session session = sf.openSession();
		Symbol symbol;
		try {
			String id = (String) parameters.get("symbolName");
			Symbol sym = (Symbol) session.load(Symbol.class, id);
			log.fine(sym.getName());
			/*
			 * pm.detachCopyAll will eagerly load the entire symbol. applyFilter
			 * access required datagroup/data/fact this lazy loads the symbol
			 */
			Map<String, String[]> filterMap = (Map<String, String[]>) parameters
					.get("filterMap");
			symbol = DaoHelper.applyFilter(sym, filterMap);
		} catch (PersistenceException e) {
			log.severe(e.getMessage());
			throw e;
		} finally {
			session.close();
		}
		return (T) symbol;
	}

	@Override
	public List<T> select(Class<?> clz, Class<T> resultClz, String statement,
			Map<?, ?> parameters) throws PersistenceException {
		// TODO Auto-generated method stub
		return null;
	}
}
