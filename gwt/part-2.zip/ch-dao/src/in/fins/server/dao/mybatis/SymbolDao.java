package in.fins.server.dao.mybatis;

import in.fins.server.dao.IDao;
import in.fins.shared.Symbol;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.persistence.PersistenceException;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

public class SymbolDao<T> implements IDao<T> {

	private static final Logger log = Logger.getLogger(SymbolDao.class
			.getName());

	private SqlSessionFactory ssf;

	public SymbolDao(SqlSessionFactory ssf) {
		this.ssf = ssf;
		if (ssf == null)
			log.warning("Loading MyBatis SqlSessionFactory failed.");
	}

	@SuppressWarnings("unchecked")
	@Override
	public T selectById(Class<T> clz, Map<?, ?> parameters)
			throws PersistenceException {
		SqlSession session = ssf.openSession();
		Symbol symbol;
		try {
			String symbolName = (String) parameters.get("symbolName");
			Symbol sym = session.selectOne("mappers.selectSymbol", symbolName);
			log.fine(sym.getName());
			Map<String, String[]> filterMap = (Map<String, String[]>) parameters
					.get("filterMap");
			symbol = DaoHelper.applyFilter(sym, filterMap);
		} catch (PersistenceException e) {
			log.severe(e.getMessage());
			throw e;
		} finally {
			session.close();
		}
		return (T) symbol;
	}

	@Override
	public List<T> select(Class<?> clz, Class<T> resultClz, String statement,
			Map<?, ?> parameters) throws PersistenceException {
		// TODO Auto-generated method stub
		return null;
	}

}
