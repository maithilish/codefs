package in.fins.server.dao.hibernate;

import in.fins.server.dao.IDao;
import in.fins.shared.Data;
import in.fins.shared.Symbol;
import in.fins.shared.SymbolHelper;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.persistence.PersistenceException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class DataDao<T> implements IDao<T> {

	private static final Logger log = Logger.getLogger(DataDao.class.getName());

	private SessionFactory sf;

	public DataDao(SessionFactory sf) {
		this.sf = sf;
		if (sf == null)
			log.warning("Loading JDO PersistaceManagerFactory failed.");

	}

	@SuppressWarnings("unchecked")
	@Override
	public T selectById(Class<T> clz, Map<?, ?> parameters)
			throws PersistenceException {
		Session session = sf.openSession();
		Data filteredData;
		try {
			String id = (String) parameters.get("symbolName");
			String category = (String) parameters.get("category");
			Date date = (Date) parameters.get("date");
			int offset = (Integer) parameters.get("offset");
			String[] filter = (String[]) parameters.get("filter");
			log.fine("selectData Symbol " + id + " cat " + category + " date "
					+ date + " offset " + offset);
			Symbol sym = (Symbol) session.load(Symbol.class, id);
			Date offsetDate = SymbolHelper.getOffsetDate(sym, category, date,
					offset);
			Data data = SymbolHelper.getData(sym, category, offsetDate);
			/*
			 * pm.detachCopyAll will eagerly load the entire symbol. applyFilter
			 * access required data/fact this lazy loads the symbol
			 */
			filteredData = DaoHelper.applyFilter(data, filter);
		} catch (PersistenceException e) {
			log.severe(e.getMessage());
			throw e;
		} finally {
			session.close();
		}
		return (T) filteredData;
	}

	@Override
	public List<T> select(Class<?> clz, Class<T> resultClz, String statement,
			Map<?, ?> parameters) throws PersistenceException {
		// TODO Auto-generated method stub
		return null;
	}

}
