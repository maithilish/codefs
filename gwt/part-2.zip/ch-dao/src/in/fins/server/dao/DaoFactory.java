package in.fins.server.dao;

import java.util.logging.Logger;

public abstract class DaoFactory {

	public enum ORM {
		JDO, MyBatis, Hibernate
	}

	private static final Logger log = Logger.getLogger(DaoFactory.class
			.getName());

	private static DaoFactory INSTANCE;

	public abstract <T> IDao<T> getDao(Class<T> clz) throws Exception;

	public static DaoFactory getDaoFactory(ORM orm) throws Exception {
		if (INSTANCE == null) {
			switch (orm) {
			case JDO:
				INSTANCE = new in.fins.server.dao.jdo.DaoFactory();
				break;
			case MyBatis:
				INSTANCE = new in.fins.server.dao.mybatis.DaoFactory();
				break;
			case Hibernate:
				INSTANCE = new in.fins.server.dao.hibernate.DaoFactory();
				break;
			}
		}
		if (INSTANCE == null) {
			log.warning("Unable create DaoFactory for : " + orm);
		} else {
			log.info("DaoFactory created for : " + orm);
		}
		return INSTANCE;
	}
}
