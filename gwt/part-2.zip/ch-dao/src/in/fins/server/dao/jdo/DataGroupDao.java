package in.fins.server.dao.jdo;

import in.fins.server.dao.IDao;
import in.fins.shared.DataGroup;
import in.fins.shared.Symbol;
import in.fins.shared.SymbolHelper;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.persistence.PersistenceException;

public class DataGroupDao<T> implements IDao<T> {

	private static final Logger log = Logger.getLogger(DataGroupDao.class
			.getName());

	protected PersistenceManagerFactory pmf;

	public DataGroupDao(PersistenceManagerFactory pmf) {
		this.pmf = pmf;
		if (pmf == null)
			log.warning("Loading JDO PersistaceManagerFactory failed.");

	}

	@SuppressWarnings("unchecked")
	@Override
	public T selectById(Class<T> clz, Map<?, ?> parameters)
			throws PersistenceException {
		PersistenceManager pm = pmf.getPersistenceManager();
		DataGroup filteredDataGroup;
		try {
			String id = (String) parameters.get("symbolName");
			String category = (String) parameters.get("category");
			String[] filter = (String[]) parameters.get("filter");
			log.fine("selectDataGroup Symbol " + id + " cat " + category);
			Symbol sym = pm.getObjectById(Symbol.class, id);
			DataGroup dataGroup = SymbolHelper.getDataGroup(sym, category);
			/*
			 * pm.detachCopyAll will eagerly load the entire symbol. applyFilter
			 * access required data/fact to lazy load the symbol
			 */
			filteredDataGroup = DaoHelper.applyFilter(dataGroup, filter);
		} catch (PersistenceException e) {
			log.severe(e.getMessage());
			throw e;
		} finally {
			pm.close();
		}
		return (T) filteredDataGroup;
	}

	@Override
	public List<T> select(Class<?> clz, Class<T> resultClz, String statement,
			Map<?, ?> parameters) throws PersistenceException {
		// TODO Auto-generated method stub
		return null;
	}

}
