package in.fins.server.listener;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Logger;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class FinsContextListener implements ServletContextListener {

	private static final Logger log = Logger
			.getLogger(FinsContextListener.class.getName());

	@Override
	public void contextInitialized(ServletContextEvent event) {
		String finsPropsFile = "META-INF/fins.properties";
		InputStream is = getClass().getClassLoader().getResourceAsStream(
				finsPropsFile);
		Properties properties = new Properties();
		if (is == null) {
			log.warning("Unable to find Fins conf : " + finsPropsFile);
		} else {
			try {
				properties.load(is);
				ServletContext sc = event.getServletContext();
				for (Object key : properties.keySet()) {
					sc.setAttribute((String) key, properties.get(key));
				}
				log.info(finsPropsFile + " - properties set to ServletContext");
			} catch (IOException e) {
				log.warning(e.getMessage());
			}
		}
	}

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
	}
}
