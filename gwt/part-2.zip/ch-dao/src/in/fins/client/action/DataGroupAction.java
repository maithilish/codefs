package in.fins.client.action;

import in.fins.client.event.DataGroupEvent;
import in.fins.client.event.EventBus;
import in.fins.client.event.SymbolEvent;
import in.fins.client.event.SymbolEvent.SymbolHandler;
import in.fins.client.rpc.ISymbolService;
import in.fins.client.rpc.ISymbolServiceAsync;
import in.fins.shared.DataGroup;
import in.fins.shared.Symbol;

import java.util.logging.Logger;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.OpenEvent;
import com.google.gwt.event.logical.shared.OpenHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;

public class DataGroupAction<T> implements SymbolHandler, OpenHandler<T>,
		ClickHandler {

	private static final Logger log = Logger.getLogger(DataGroupAction.class
			.getName());

	private Object eventSource;
	private String category;
	private Symbol symbol;
	private boolean symbolChanged;
	private DataGroup dataGroup;

	private String[] filter;

	public DataGroupAction(String category, String[] filter) {
		this.category = category;
		this.filter = filter;
		setEventSource(this);
		symbolChanged = false;
	}

	@Override
	public void onSymbolChange(SymbolEvent symbolEvent) {
		this.symbol = symbolEvent.getSymbol();
		symbolChanged = true;
	}

	public void setEventSource(Object eventSource) {
		this.eventSource = eventSource;
	}

	@Override
	public void onOpen(OpenEvent<T> event) {
		execute();
	}

	@Override
	public void onClick(ClickEvent event) {
		execute();
	}

	private void execute() {
		if (symbolChanged == false && dataGroup != null) {
			log.fine("No Symbol change. Using existing dataGroup");
			EventBus.get().fireEventFromSource(new DataGroupEvent(dataGroup),
					eventSource);
		} else {
			log.fine("Symbol Changed. Fetching dataGroup");
			ISymbolServiceAsync symbolService = GWT
					.create(ISymbolService.class);
			symbolService.getDataGroup(symbol.getName(), category, filter,
					new AsyncCallback<DataGroup>() {
						@Override
						public void onSuccess(DataGroup newDataGroup) {
							DataGroup existingDataGroup = symbol
									.getDataGroup(category);
							symbol.getDataGroups().remove(existingDataGroup);
							// positionDate of data is set to present
							// positionDate
							newDataGroup.setPositionDate(existingDataGroup
									.getPositionDate());
							symbol.getDataGroups().add(newDataGroup);

							dataGroup = newDataGroup;
							symbolChanged = false;
							// event source is dataSourceAction as this is annon
							EventBus.get().fireEventFromSource(
									new DataGroupEvent(newDataGroup),
									eventSource);
							log.fine("Fired DataGroupEvent Symbol " + symbol
									+ " Category " + newDataGroup);
						}

						@Override
						public void onFailure(Throwable caught) {
							log.warning(caught.getMessage());
						}

					});
		}
	}
}
