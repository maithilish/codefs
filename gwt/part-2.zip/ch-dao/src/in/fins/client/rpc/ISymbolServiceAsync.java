package in.fins.client.rpc;

import in.fins.shared.Data;
import in.fins.shared.DataGroup;
import in.fins.shared.Symbol;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.google.gwt.user.client.rpc.AsyncCallback;

public interface ISymbolServiceAsync {

	void getSymbolNames(AsyncCallback<List<String>> callback);

	void getSymbol(String symbolName, Map<String, String[]> filterMap,
			AsyncCallback<Symbol> callback);

	void getData(String symbolName, String category, Date date, int offset,
			String[] filter, AsyncCallback<Data> callback);

	void getDataGroup(String symbolName, String category, String[] filter,
			AsyncCallback<DataGroup> callback);

}
