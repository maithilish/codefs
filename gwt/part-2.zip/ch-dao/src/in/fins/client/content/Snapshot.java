package in.fins.client.content;

import in.fins.client.FinsResources;
import in.fins.client.action.DataAction;
import in.fins.client.action.DataGroupAction;
import in.fins.client.action.SymbolAction;
import in.fins.client.event.DataGroupEvent;
import in.fins.client.event.EventBus;
import in.fins.client.event.NameEvent;
import in.fins.client.event.SymbolEvent;
import in.fins.client.widget.AutoSuggest;
import in.fins.client.widget.ChartPanel;
import in.fins.client.widget.FactDisclosePanel;
import in.fins.client.widget.FactGrid;
import in.fins.client.widget.FactPanel;
import in.fins.client.widget.FactTable;
import in.fins.client.widget.TitlePanel;
import in.fins.client.widget.ToolbarItem;

import java.util.HashMap;
import java.util.Map;

import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiFactory;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.DisclosurePanel;
import com.google.gwt.user.client.ui.Grid;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.PopupPanel;
import com.google.gwt.user.client.ui.ResizeComposite;
import com.google.gwt.user.client.ui.Widget;

public class Snapshot extends ResizeComposite {

	interface SnapshotBinder extends UiBinder<Widget, Snapshot> {
	}

	private static UiBinder<Widget, Snapshot> binder = GWT
			.create(SnapshotBinder.class);

	@UiField
	AutoSuggest autoSuggest;

	@UiField
	Grid grid;

	private FactGrid factGrid;

	public Snapshot() {
		factGrid = new FactGrid();
		PopupPanel popup = new PopupPanel();
		popup.setGlassEnabled(true);
		popup.setAutoHideEnabled(true);
		popup.add(factGrid);

		initWidget(binder.createAndBindUi(this));
		autoSuggest.requestFocus();

		grid.getRowFormatter().setVerticalAlign(1,
				HasVerticalAlignment.ALIGN_TOP);

		SymbolAction symbolAction = new SymbolAction(getFilterMap());
		symbolAction.setEventSource(this);
		EventBus.get().addHandlerToSource(NameEvent.TYPE, this, symbolAction);
	}

	@UiFactory
	public AutoSuggest autoSuggestFactory() {
		AutoSuggest autoSuggest = new AutoSuggest();
		autoSuggest.setEventSource(this);
		return autoSuggest;
	}

	@UiFactory
	public TitlePanel titlePanelFactory() {
		TitlePanel tp = new TitlePanel();
		EventBus.get().addHandlerToSource(NameEvent.TYPE, this, tp);
		return tp;
	}

	@UiFactory
	public FactPanel factPanelFactory() {
		FactPanel fp = new FactPanel();
		EventBus.get().addHandlerToSource(SymbolEvent.TYPE, this, fp);
		return fp;
	}

	@UiFactory
	public FactDisclosePanel factDisclosePanelFactory(String header,
			String caption, String category) {
		DataGroupAction<DisclosurePanel> dataGroupAction = new DataGroupAction<DisclosurePanel>(
				category, getFilter(category));
		EventBus.get().addHandlerToSource(SymbolEvent.TYPE, this,
				dataGroupAction);

		FactDisclosePanel fdp = new FactDisclosePanel(header, caption);
		// required to make fdp visible after symbol is loaded
		EventBus.get().addHandlerToSource(SymbolEvent.TYPE, this, fdp);
		fdp.addOpenHandler(dataGroupAction);
		EventBus.get().addHandlerToSource(DataGroupEvent.TYPE, dataGroupAction,
				fdp);
		return fdp;
	}

	@UiFactory
	public ChartPanel chartPanelFactory(String title, String key, String width,
			String height, boolean rangeSelector) {
		ChartPanel cp = new ChartPanel(title, key, width, height, rangeSelector);
		return cp;
	}

	@UiFactory
	public FactTable factTableFactory(String captionText, String category) {
		FactTable ft = new FactTable(captionText, category);
		EventBus.get().addHandlerToSource(SymbolEvent.TYPE, this, ft);
		return ft;
	}

	@UiFactory
	public ToolbarItem toolbarItemFactory(String type, String category) {
		FinsResources images = FinsResources.INSTANCE;

		if (type.equals("previous")) {
			DataAction dataAction = new DataAction(category, "Backward",
					getFilter(category));
			EventBus.get().addHandlerToSource(SymbolEvent.TYPE, this,
					dataAction);
			ToolbarItem tbi = new ToolbarItem(images.previous());
			tbi.addClickHandler(dataAction);
			tbi.setEventSource(dataAction);
			return tbi;
		}
		if (type.equals("next")) {
			DataAction dataAction = new DataAction(category, "Forward",
					getFilter(category));
			EventBus.get().addHandlerToSource(SymbolEvent.TYPE, this,
					dataAction);
			ToolbarItem tbi = new ToolbarItem(images.next());
			tbi.addClickHandler(dataAction);
			tbi.setEventSource(dataAction);
			return tbi;
		}
		if (type.equals("popup")) {
			DataGroupAction<FactGrid> dataGroupAction = new DataGroupAction<FactGrid>(
					category, getFilter(category));
			EventBus.get().addHandlerToSource(SymbolEvent.TYPE, this,
					dataGroupAction);

			ToolbarItem tbi = new ToolbarItem(images.tablesheet());
			tbi.addClickHandler(dataGroupAction);
			// tbi.addClickHandler(factPopup);
			tbi.setEventSource(dataGroupAction);
			EventBus.get().addHandlerToSource(DataGroupEvent.TYPE,
					dataGroupAction, factGrid);
			return tbi;
		}
		return null;
	}

	private static Map<String, String[]> getFilterMap() {
		Map<String, String[]> filterMap = new HashMap<String, String[]>();
		filterMap.put("Quote", getFilter("Quote"));
		filterMap.put("BS", getFilter("BS"));
		filterMap.put("PL", getFilter("PL"));
		filterMap.put("Shareholding", getFilter("Shareholding"));
		filterMap.put("Cash Flow", getFilter("Cash Flow"));
		filterMap.put("Quarterly", getFilter("Quarterly"));
		return filterMap;
	}

	private static String[] getFilter(String cat) {
		if (cat.equals("Quote")) {
			return new String[] { "Price", "PB", "P/E", "BV", "DY (%)",
					"DIV (%)", "FV", "EPS", "Mk.Cap", "Ind. PE", "52 Wk High",
					"52 Wk Low" };
		}
		if (cat.equals("BS")) {
			return new String[] { "Capital", "Reserves", "Debt", "Cash", "FD",
					"Investment", "Gross Block", "Net Block", "Cap. WIP" };
		}
		if (cat.equals("PL")) {
			return new String[] { "Sales", "Raw Materials",
					"Power & Fuel Cost", "Employee Cost",
					"Selling and Admin Expenses", "Op Profit", "Tax", "Int",
					"Net Profit" };
		}
		if (cat.equals("Shareholding")) {
			return new String[] { "Promoters", "Pledge", "FII", "DII", "MF",
					"Public" };
		}
		if (cat.equals("Cash Flow")) {
			return new String[] { "Op. CF", "Inv. CF", "Fin. CF" };
		}
		if (cat.equals("Quarterly")) {
			return new String[] { "Sales", "Gross Profit", "Net Profit", "Int",
					"Tax", "EPS" };
		}
		return null;
	}
}
