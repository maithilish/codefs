package in.fins.client.event;

import in.fins.client.event.DataGroupEvent.DataGroupHandler;
import in.fins.shared.DataGroup;

import com.google.gwt.event.shared.EventHandler;
import com.google.web.bindery.event.shared.Event;

public class DataGroupEvent extends Event<DataGroupHandler> {

	public static final Type<DataGroupHandler> TYPE = new Type<DataGroupHandler>();

	public interface DataGroupHandler extends EventHandler {
		public void onDataGroupChange(DataGroupEvent dataGroupEvent);
	}

	private DataGroup dataGroup;

	public DataGroupEvent(DataGroup dataGroup) {
		this.dataGroup = dataGroup;
	}

	@Override
	public Type<DataGroupHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(DataGroupHandler handler) {
		handler.onDataGroupChange(this);
	}

	public DataGroup getDataGroup() {
		return dataGroup;
	}
}
