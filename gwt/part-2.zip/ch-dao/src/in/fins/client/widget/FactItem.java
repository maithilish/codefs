package in.fins.client.widget;

import com.google.gwt.uibinder.client.UiConstructor;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;

public class FactItem extends HorizontalPanel {

	private Label label;
	private String[] matchs;
	private Label value;
	private String category;

	@UiConstructor
	public FactItem(String category, String text, String match) {
		this.category = category;
		this.matchs = match.split("[,]+");

		label = new Label(text);
		label.setStyleName("fins-KeyValuePanel-Label-Key");
		add(label);

		value = new Label();
		value.setStyleName("fins-KeyValuePanel-Label-Value");
		add(value);
	}

	public String[] getMatchs() {
		return matchs;
	}

	public void setValue(String valueStr) {
		value.setText(valueStr);
	}

	public String getCategory() {
		return category;
	}
}