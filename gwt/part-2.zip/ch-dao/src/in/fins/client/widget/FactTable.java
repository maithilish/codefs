package in.fins.client.widget;

import in.fins.client.event.DataEvent;
import in.fins.client.event.DataEvent.DataHandler;
import in.fins.client.event.EventBus;
import in.fins.client.event.SymbolEvent;
import in.fins.client.event.SymbolEvent.SymbolHandler;
import in.fins.shared.Data;
import in.fins.shared.Fact;
import in.fins.shared.Symbol;
import in.fins.shared.SymbolHelper;

import java.util.Date;
import java.util.Iterator;
import java.util.logging.Logger;

import com.google.gwt.core.client.GWT;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiConstructor;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.cellview.client.CellTable;
import com.google.gwt.user.cellview.client.TextColumn;
import com.google.gwt.user.client.ui.CaptionPanel;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HasWidgets;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;
import com.google.gwt.view.client.ListDataProvider;

public class FactTable extends Composite implements HasWidgets, SymbolHandler,
		DataHandler {

	private static final Logger log = Logger.getLogger(FactTable.class
			.getName());

	interface FactTableBinder extends UiBinder<Widget, FactTable> {
	}

	private static UiBinder<Widget, FactTable> binder = GWT
			.create(FactTableBinder.class);

	@UiField
	CaptionPanel captionPanel;

	@UiField
	VerticalPanel vPanel;

	@UiField
	CellTable<Fact> cellTable;

	@UiField
	Label header;

	@UiField
	HorizontalPanel toolbar;

	private String category;

	private ListDataProvider<Fact> dataProvider;

	@UiConstructor
	public FactTable(String captionText, String category) {
		initWidget(binder.createAndBindUi(this));
		this.category = category;
		captionPanel.setCaptionText(captionText);
		addColumns();
		dataProvider = new ListDataProvider<Fact>();
		dataProvider.addDataDisplay(cellTable);
		setVisible(false);
	}

	public void addColumns() {
		TextColumn<Fact> labelColumn = new TextColumn<Fact>() {
			@Override
			public String getValue(Fact fact) {
				return fact.getKey();
			}
		};
		TextColumn<Fact> valueColumn = new TextColumn<Fact>() {
			@Override
			public String getValue(Fact fact) {
				return fact.getRoundoff();
			}
		};
		cellTable.addColumn(labelColumn);
		cellTable.addColumn(valueColumn);

		valueColumn.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
	}

	public void setHeaderText(String text) {
		header.setText(text);
	}

	@Override
	public void onSymbolChange(SymbolEvent symbolEvent) {
		log.fine("SymbolEvent received. " + symbolEvent.getSymbol());
		Symbol symbol = symbolEvent.getSymbol();
		Date date = SymbolHelper.getPositionDate(symbol, category);
		if (date != null) {
			DateTimeFormat fmt = DateTimeFormat.getFormat("MMM yy");
			setHeaderText(fmt.format(date));
			dataProvider.setList(SymbolHelper.getFacts(symbol, category, date));
		}
		setVisible(true);
	}

	@Override
	public void onDataChange(DataEvent dataEvent) {
		Data data = dataEvent.getData();
		log.fine("DataEvent recd - " + data);
		Date date = data.getDate();
		if (date != null) {
			DateTimeFormat fmt = DateTimeFormat.getFormat("MMM yy");
			setHeaderText(fmt.format(date));
			dataProvider.setList(data.getFacts());
		}
		setVisible(true);
	}

	@Override
	public void add(Widget w) {
		if (w instanceof FactTable) {
			vPanel.add(w);
		}
		if (w instanceof ToolbarItem) {
			ToolbarItem ti = (ToolbarItem) w;
			toolbar.add(w);
			EventBus.get().addHandlerToSource(DataEvent.TYPE,
					ti.getEventSource(), this);
			log.fine("DataEventHandler added ToolbarItem (Src) -> FactTable(Dst)");
		}
	}

	@Override
	public void clear() {
		vPanel.clear();
	}

	@Override
	public Iterator<Widget> iterator() {
		return vPanel.iterator();
	}

	@Override
	public boolean remove(Widget w) {
		return vPanel.remove(w);
	}

}
