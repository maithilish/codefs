package in.fins.shared;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class SymbolDatabase {

	private static final String[] symbolNames = { "A Sys", "B Max", "C World",
			"D Dummy" };

	private static final String[][] dates = { { "Quote", "31-01-2012" },
			{ "Quote", "29-02-2012" }, { "Quote", "31-03-2012" },
			{ "Quote", "30-04-2012" }, { "Quote", "31-05-2012" },
			{ "Quote", "30-06-2012" }, { "Quote", "31-07-2012" },
			{ "Quote", "31-08-2012" }, { "Quote", "30-09-2012" },
			{ "Quote", "31-10-2012" }, { "Quote", "30-11-2012" },
			{ "Quote", "31-12-2012" }, { "BS", "31-12-2008" },
			{ "BS", "31-12-2009" }, { "BS", "31-12-2010" },
			{ "BS", "31-12-2011" }, { "BS", "31-12-2012" },
			{ "PL", "31-12-2008" }, { "PL", "31-12-2009" },
			{ "PL", "31-12-2010" }, { "PL", "31-12-2011" },
			{ "PL", "31-12-2012" }, { "Cash Flow", "31-12-2008" },
			{ "Cash Flow", "31-12-2009" }, { "Cash Flow", "31-12-2010" },
			{ "Cash Flow", "31-12-2011" }, { "Cash Flow", "31-12-2012" },
			{ "Quarterly", "31-12-2011" }, { "Quarterly", "31-03-2012" },
			{ "Quarterly", "30-06-2012" }, { "Quarterly", "30-09-2012" },
			{ "Quarterly", "31-12-2012" }, { "Shareholding", "31-10-2012" },
			{ "Shareholding", "30-11-2012" }, { "Shareholding", "31-12-2012" } };

	public static List<String> getSymbolNames() {
		return Arrays.asList(symbolNames);
	}

	public static Symbol getSymbol(String symbolName,
			Map<String, String[]> filterMap) {
		Symbol symbol = new Symbol();
		symbol.setName(symbolName);
		symbol.setLabel(symbolName);
		symbol.setDataGroups(getDataGroups(filterMap));
		return symbol;
	}

	public static DataGroup getDataGroup(String symbolName, String category,
			String[] filter) {
		DataGroup dataGroup = new DataGroup();
		dataGroup.setCategory(category);
		dataGroup.setDataList(getDataList(category, filter));
		return dataGroup;
	}

	public static Data getData(String symbolName, String category, Date date,
			int offset, String[] filter) {
		Data data = new Data();
		data.setDate(getOffsetDate(category, date, offset));
		data.setFacts(getFacts(filter));
		return data;
	}

	private static List<DataGroup> getDataGroups(Map<String, String[]> filterMap) {
		List<DataGroup> dataGroups = new ArrayList<DataGroup>();
		for (String category : filterMap.keySet()) {
			DataGroup dataGroup = new DataGroup();
			dataGroup.setCategory(category);
			dataGroup
					.setDataList(getDataList(category, filterMap.get(category)));
			dataGroup.setPositionDate(dataGroup.lastDate());
			dataGroups.add(dataGroup);
		}
		return dataGroups;
	}

	private static List<Data> getDataList(String category, String[] filter) {
		List<Date> categoryDates = getCategoryDates(category);
		List<Data> dataList = new ArrayList<Data>();
		for (Date date : categoryDates) {
			Data data = new Data();
			data.setDate(date);
			data.setFacts(getFacts(filter));
			dataList.add(data);
		}
		return dataList;
	}

	private static List<Fact> getFacts(String[] filter) {
		List<Fact> facts = new ArrayList<Fact>();
		for (String key : filter) {
			Fact fact = new Fact();
			fact.setKey(key);
			// value is just some random
			Random random = new Random();
			int i = random.nextInt(999); // int
			int d = random.nextInt(99); // decimal
			fact.setValue(String.valueOf(i) + "." + String.valueOf(d));
			facts.add(fact);
		}
		return facts;
	}

	private static List<Date> getCategoryDates(String category) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		List<Date> categoryDates = new ArrayList<Date>();
		for (String[] cd : dates) {
			if (cd[0].equals(category)) {
				try {
					categoryDates.add(sdf.parse(cd[1]));
				} catch (ParseException e) {
				}
			}
		}
		return categoryDates;
	}

	private static Date getOffsetDate(String category, Date date, int offset) {
		List<Date> catDates = getCategoryDates(category);
		Collections.sort(catDates);
		int index = catDates.indexOf(date);
		index = index + offset;
		if (index < 0) {
			index = 0;
		}
		if (index >= catDates.size()) {
			index = catDates.size() - 1;
		}
		System.out.println(date + " " + offset + " " + catDates.get(index));
		return catDates.get(index);
	}
}
