package in.fins.server.service;

import in.fins.client.rpc.ISymbolService;
import in.fins.shared.Data;
import in.fins.shared.DataGroup;
import in.fins.shared.Symbol;
import in.fins.shared.SymbolDatabase;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;

public class SymbolService extends RemoteServiceServlet implements
		ISymbolService {

	private static final Logger log = Logger.getLogger(SymbolService.class
			.getName());

	private static final long serialVersionUID = 1L;

	public SymbolService() {
		super();
	}

	@Override
	public List<String> getSymbolNames() throws Exception {
		try {
			List<String> list = SymbolDatabase.getSymbolNames();
			log.info("Symbol Names : " + list.size());
			return list;
		} catch (Exception e) {
			log.warning(e.getMessage());
			throw e;
		}
	}

	@Override
	public Symbol getSymbol(String symbolName, Map<String, String[]> filterMap)
			throws Exception {
		try {
			return SymbolDatabase.getSymbol(symbolName, filterMap);
		} catch (Exception e) {
			log.warning(e.getMessage());
			throw e;
		}
	}

	@Override
	public Data getData(String symbolName, String category, Date date,
			int offset, String[] filter) throws Exception {
		try {
			return SymbolDatabase.getData(symbolName, category, date, offset,
					filter);
		} catch (Exception e) {
			log.warning(e.getMessage());
			throw e;
		}
	}

	@Override
	public DataGroup getDataGroup(String symbolName, String category,
			String[] filter) throws Exception {
		try {
			return SymbolDatabase.getDataGroup(symbolName, category, filter);
		} catch (Exception e) {
			log.warning(e.getMessage());
			throw e;
		}
	}

}
