package in.fins.client.rpc;

import java.util.List;

import com.google.gwt.user.client.rpc.AsyncCallback;

public interface ISymbolServiceAsync {

	void getSymbolNames(AsyncCallback<List<String>> callback);

}
