package in.fins.client.rpc;

import java.util.List;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

@RemoteServiceRelativePath("symbolService")
public interface ISymbolService extends RemoteService {

	public List<String> getSymbolNames() throws Exception;

}
