package in.fins.client.action;

import in.fins.client.event.EventBus;
import in.fins.client.event.NameEvent;
import in.fins.client.event.NameEvent.NameHandler;
import in.fins.client.event.SymbolEvent;
import in.fins.shared.Symbol;
import in.fins.shared.SymbolDatabase;
import in.fins.shared.SymbolHelper;

import java.util.Map;
import java.util.logging.Logger;

public class SymbolAction implements NameHandler {

	private static final Logger log = Logger.getLogger(SymbolAction.class
			.getName());

	private Object eventSource;

	private Map<String, String[]> filterMap;

	public SymbolAction(Map<String, String[]> filterMap) {
		this.filterMap = filterMap;
	}

	@Override
	public void onNameChange(NameEvent nameEvent) {
		getSymbol(nameEvent.getName());
	}

	private void getSymbol(String symbolName) {
		Symbol symbol = SymbolDatabase.getSymbol(symbolName, filterMap);
		for (String category : SymbolHelper.getCategories(symbol)) {
			SymbolHelper.setPositionDate(symbol, category,
					SymbolHelper.getLastDate(symbol, category));
		}
		EventBus.get()
				.fireEventFromSource(new SymbolEvent(symbol), eventSource);

		log.fine("Fired SymbolEvent " + symbol.getName());
	}

	public void setEventSource(Object eventSource) {
		this.eventSource = eventSource;
	}
}
