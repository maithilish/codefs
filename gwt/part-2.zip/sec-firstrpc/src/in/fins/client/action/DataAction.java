package in.fins.client.action;

import in.fins.client.event.DataEvent;
import in.fins.client.event.EventBus;
import in.fins.client.event.SymbolEvent;
import in.fins.client.event.SymbolEvent.SymbolHandler;
import in.fins.shared.Data;
import in.fins.shared.Symbol;
import in.fins.shared.SymbolDatabase;
import in.fins.shared.SymbolHelper;

import java.util.Date;
import java.util.logging.Logger;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;

public class DataAction implements ClickHandler, SymbolHandler {

	private static final Logger log = Logger.getLogger(DataAction.class
			.getName());

	private String direction;
	private Symbol symbol;
	private String category;

	private DataAction eventSource;

	private String[] filter;

	public DataAction(String category, String direction, String[] filter) {
		this.category = category;
		this.direction = direction;
		this.filter = filter;
		eventSource = this;
	}

	@Override
	public void onClick(ClickEvent event) {
		String symbolName = symbol.getName();
		final Date date = SymbolHelper.getPositionDate(symbol, category);
		final int offset;
		if (direction.equals("Forward")) {
			offset = 1;
		} else {
			offset = -1;
		}

		Data data = SymbolDatabase.getData(symbolName, category, date, offset,
				filter);
		SymbolHelper.replaceData(symbol, category, data);
		SymbolHelper.setPositionDate(symbol, category, data.getDate());
		EventBus.get().fireEventFromSource(new DataEvent(data), eventSource);
		log.fine("DataEvent fired - " + symbol + " " + data);

	}

	@Override
	public void onSymbolChange(SymbolEvent symbolEvent) {
		this.symbol = symbolEvent.getSymbol();
	}
}
