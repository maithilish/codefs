package in.fins.server.service;

import in.fins.client.rpc.ISymbolService;
import in.fins.shared.SymbolDatabase;

import java.util.List;
import java.util.logging.Logger;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;

public class SymbolService extends RemoteServiceServlet implements
		ISymbolService {

	private static final Logger log = Logger.getLogger(SymbolService.class
			.getName());

	private static final long serialVersionUID = 1L;

	public SymbolService() {
		super();
	}

	@Override
	public List<String> getSymbolNames() throws Exception {
		try {
			List<String> list = SymbolDatabase.getSymbolNames();
			log.info("Symbol Names : " + list.size());
			return list;
		} catch (Exception e) {
			log.warning(e.getMessage());
			throw e;
		}
	}

}
