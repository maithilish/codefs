package in.fins.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;

public class Fins implements EntryPoint {

	@Override
	public void onModuleLoad() {
		RootPanel root = RootPanel.get();
		root.add(new Label("Test Label"));
	}

}
