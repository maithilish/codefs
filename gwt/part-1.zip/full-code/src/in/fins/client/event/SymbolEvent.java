package in.fins.client.event;

import in.fins.client.Symbol;
import in.fins.client.event.SymbolEvent.SymbolHandler;

import com.google.gwt.event.shared.EventHandler;
import com.google.web.bindery.event.shared.Event;

public class SymbolEvent extends Event<SymbolHandler> {

	public static final Type<SymbolHandler> TYPE = new Type<SymbolHandler>();

	public interface SymbolHandler extends EventHandler {
		public void onSymbolChange(SymbolEvent symbolEvent);
	}

	private Symbol symbol;

	public SymbolEvent(Symbol symbol) {
		this.symbol = symbol;
	}

	@Override
	public Type<SymbolHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(SymbolHandler handler) {
		handler.onSymbolChange(this);
	}

	public Symbol getSymbol() {
		return symbol;
	}
}
