package in.fins.client.event;

import in.fins.client.Data;
import in.fins.client.event.DataEvent.DataHandler;

import com.google.gwt.event.shared.EventHandler;
import com.google.web.bindery.event.shared.Event;

public class DataEvent extends Event<DataHandler> {

	public static final Type<DataHandler> TYPE = new Type<DataHandler>();

	public interface DataHandler extends EventHandler {
		public void onDataChange(DataEvent dataEvent);
	}

	private Data data;

	public DataEvent(Data data) {
		this.data = data;
	}

	@Override
	public Type<DataHandler> getAssociatedType() {
		return TYPE;
	}

	@Override
	protected void dispatch(DataHandler handler) {
		handler.onDataChange(this);
	}

	public Data getData() {
		return data;
	}
}
