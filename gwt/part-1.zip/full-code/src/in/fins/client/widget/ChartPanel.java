package in.fins.client.widget;

import in.fins.client.Data;
import in.fins.client.DataGroup;
import in.fins.client.Fact;
import in.fins.client.event.DataGroupEvent;
import in.fins.client.event.DataGroupEvent.DataGroupHandler;

import java.util.Collections;
import java.util.List;
import java.util.logging.Logger;

import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.SimplePanel;
import com.google.gwt.visualization.client.AbstractDataTable;
import com.google.gwt.visualization.client.AbstractDataTable.ColumnType;
import com.google.gwt.visualization.client.DataTable;
import com.google.gwt.visualization.client.VisualizationUtils;
import com.google.gwt.visualization.client.visualizations.AnnotatedTimeLine;
import com.google.gwt.visualization.client.visualizations.AnnotatedTimeLine.Options;

public class ChartPanel extends Composite implements DataGroupHandler {

	private static final Logger log = Logger.getLogger(ChartPanel.class
			.getName());

	SimplePanel sPanel;
	private String title;
	private String width;
	private String height;
	private Runnable onLoadCallback;

	protected DataGroup dataGroup;

	private String key;

	private boolean rangeSelector;

	public ChartPanel(String title, String key, String chartWidth,
			String chartHeight, boolean rangeSelector) {
		this.title = title;
		this.key = key;
		this.width = chartWidth;
		this.height = chartHeight;
		this.rangeSelector = rangeSelector;

		sPanel = new SimplePanel();
		initWidget(sPanel);

		onLoadCallback = new Runnable() {
			public void run() {
				AnnotatedTimeLine chart = new AnnotatedTimeLine(createTable(),
						createOptions(), width, height);
				log.fine("Chart created");
				sPanel.setWidget(chart);
			}
		};
	}

	protected Options createOptions() {
		Options options = AnnotatedTimeLine.Options.create();
		options.set("allowRedraw", true);
		options.set("displayExactValues", true);
		options.set("dateFormat", "MMM dd, yyyy");
		options.set("displayRangeSelector", rangeSelector);
		options.set("fill", "20");
		return options;
	}

	private AbstractDataTable createTable() {

		DataTable dataTable = DataTable.create();
		dataTable.addColumn(ColumnType.DATE, "Date");
		dataTable.addColumn(ColumnType.NUMBER, this.title);

		List<Data> dataList = dataGroup.getDataList();
		dataTable.addRows(dataList.size());

		Collections.sort(dataList);
		for (int i = 0; i < dataList.size(); i++) {
			Data data = dataList.get(i);
			dataTable.setValue(i, 0, data.getDate());
			for (Fact fact : data.getFacts()) {
				if (fact.getKey().equals(key)) {
					try {
						double value = Double.parseDouble(fact.getValue());
						dataTable.setValue(i, 1, value);
					} catch (Exception e) {
					}
				}
			}
		}
		return dataTable;
	}

	@Override
	public void onDataGroupChange(DataGroupEvent dataGroupEvent) {
		log.fine("dataGroupEvent received. Load charts ");
		dataGroup = dataGroupEvent.getDataGroup();
		VisualizationUtils.loadVisualizationApi(onLoadCallback,
				AnnotatedTimeLine.PACKAGE);
	}
}
