package in.fins.client.widget;

import in.fins.client.DataGroup;
import in.fins.client.FinsResources;
import in.fins.client.event.DataGroupEvent;
import in.fins.client.event.DataGroupEvent.DataGroupHandler;
import in.fins.client.event.EventBus;
import in.fins.client.event.SymbolEvent;
import in.fins.client.event.SymbolEvent.SymbolHandler;

import java.util.Iterator;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.logical.shared.OpenHandler;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiConstructor;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.CaptionPanel;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.DisclosurePanel;
import com.google.gwt.user.client.ui.HasWidgets;
import com.google.gwt.user.client.ui.Widget;

public class FactDisclosePanel extends Composite implements HasWidgets,
		SymbolHandler, DataGroupHandler {

	interface FactDisclosePanelBinder extends
			UiBinder<Widget, FactDisclosePanel> {
	}

	private static UiBinder<Widget, FactDisclosePanel> binder = GWT
			.create(FactDisclosePanelBinder.class);

	@UiField(provided = true)
	DisclosurePanel dPanel;
	@UiField
	CaptionPanel cPanel;

	@UiConstructor
	public FactDisclosePanel(String header, String caption) {
		FinsResources images = FinsResources.INSTANCE;
		dPanel = new DisclosurePanel(images.barChart(), images.chart(), header);
		initWidget(binder.createAndBindUi(this));
		cPanel.setCaptionText(caption);
		dPanel.setContent(cPanel);
		setVisible(false);
	}

	public void addOpenHandler(OpenHandler<DisclosurePanel> handler) {
		dPanel.addOpenHandler(handler);
	}

	@Override
	public void onSymbolChange(SymbolEvent symbolEvent) {
		setVisible(true);
		dPanel.setOpen(false); // close the panel on symbol change
	}

	@Override
	public void onDataGroupChange(DataGroupEvent dataGroupEvent) {
		// we don't want to handle event outside this method
		// hence new event
		DataGroup dataGroup = dataGroupEvent.getDataGroup();
		EventBus.get().fireEventFromSource(new DataGroupEvent(dataGroup), this);
	}

	@Override
	public void add(Widget w) {
		cPanel.add(w);
		if (w instanceof DataGroupHandler) {
			EventBus.get().addHandlerToSource(DataGroupEvent.TYPE, this,
					(DataGroupHandler) w);
		}
	}

	@Override
	public void clear() {
		cPanel.clear();
	}

	@Override
	public Iterator<Widget> iterator() {
		return cPanel.iterator();
	}

	@Override
	public boolean remove(Widget w) {
		return cPanel.remove(w);
	}
}