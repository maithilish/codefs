package in.fins.client;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Symbol implements Serializable {

	private static final long serialVersionUID = 1L;

	private String name;
	private String label;
	private List<DataGroup> dataGroups;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public List<DataGroup> getDataGroups() {
		return dataGroups;
	}

	public void setDataGroups(List<DataGroup> dataGroups) {
		this.dataGroups = dataGroups;
	}

	public void addDataGroup(DataGroup dataGroup) {
		if (dataGroups == null) {
			dataGroups = new ArrayList<DataGroup>();
		}
		dataGroups.add(dataGroup);
	}

	public DataGroup getDataGroup(String category) {
		if (dataGroups == null) {
			return null;
		}
		for (DataGroup dataGroup : dataGroups) {
			if (dataGroup.getCategory().equals(category)) {
				return dataGroup;
			}
		}
		return null;
	}

	@Override
	public String toString() {
		return "Symbol [name=" + name + "]";
	}

}
