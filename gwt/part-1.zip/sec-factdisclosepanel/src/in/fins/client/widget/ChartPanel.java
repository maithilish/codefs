package in.fins.client.widget;

import in.fins.client.Data;
import in.fins.client.DataGroup;
import in.fins.client.Fact;
import in.fins.client.event.DataGroupEvent;
import in.fins.client.event.DataGroupEvent.DataGroupHandler;

import java.util.List;
import java.util.logging.Logger;

import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.VerticalPanel;

public class ChartPanel extends Composite implements DataGroupHandler {

	private static final Logger log = Logger.getLogger(ChartPanel.class
			.getName());

	private String title;
	private String width;
	private String height;

	protected DataGroup dataGroup;

	private String key;

	private boolean rangeSelector;

	private VerticalPanel vPanel;

	public ChartPanel(String title, String key, String chartWidth,
			String chartHeight, boolean rangeSelector) {
		this.title = title;
		this.key = key;
		this.width = chartWidth;
		this.height = chartHeight;
		this.rangeSelector = rangeSelector;

		vPanel = new VerticalPanel();
		initWidget(vPanel);
	}

	@Override
	public void onDataGroupChange(DataGroupEvent dataGroupEvent) {
		vPanel.clear();
		dataGroup = dataGroupEvent.getDataGroup();
		List<Data> dataList = dataGroup.getDataList();
		vPanel.add(new HTML(dataGroup.getCategory() + " : " + key));
		for (Data data : dataList) {
			for (Fact fact : data.getFacts()) {
				if (fact.getKey().equals(key)) {
					vPanel.add(new HTML(data.getDate() + " - "
							+ fact.getValue()));
				}
			}
		}
	}
}
