package in.fins.client.content;

import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.Grid;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.ResizeComposite;
import com.google.gwt.user.client.ui.Widget;

public class Snapshot extends ResizeComposite {

	interface SnapshotBinder extends UiBinder<Widget, Snapshot> {
	}

	private static UiBinder<Widget, Snapshot> binder = GWT
			.create(SnapshotBinder.class);

	@UiField
	Grid grid;

	public Snapshot() {
		initWidget(binder.createAndBindUi(this));

		grid.getRowFormatter().setVerticalAlign(1,
				HasVerticalAlignment.ALIGN_TOP);
	}
}
