package in.fins.client.widget;

import in.fins.client.SymbolDatabase;
import in.fins.client.event.EventBus;
import in.fins.client.event.NameEvent;

import java.util.List;
import java.util.logging.Logger;

import com.google.gwt.core.client.GWT;
import com.google.gwt.core.client.Scheduler;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.ui.MultiWordSuggestOracle;
import com.google.gwt.user.client.ui.ResizeComposite;
import com.google.gwt.user.client.ui.SuggestBox;
import com.google.gwt.user.client.ui.SuggestOracle;
import com.google.gwt.user.client.ui.Widget;

public class AutoSuggest extends ResizeComposite {

	private static final Logger log = Logger.getLogger(AutoSuggest.class
			.getName());

	interface AutoSuggestBinder extends UiBinder<Widget, AutoSuggest> {
	}

	private static UiBinder<Widget, AutoSuggest> binder = GWT
			.create(AutoSuggestBinder.class);

	@UiField
	SuggestBox suggestBox;

	public AutoSuggest() {
		initWidget(binder.createAndBindUi(this));
		setSymbolNames();
	}

	@UiHandler("suggestBox")
	public void handleSelection(SelectionEvent<SuggestOracle.Suggestion> s) {
		log.fine("Selection : " + suggestBox.getText());
		EventBus.get().fireEvent(new NameEvent(suggestBox.getText()));
		suggestBox.setText("");
	}

	private void setSymbolNames() {
		List<String> list = SymbolDatabase.getSymbolNames();
		((MultiWordSuggestOracle) suggestBox.getSuggestOracle()).addAll(list);
	}

	public void requestFocus() {
		Scheduler.get().scheduleDeferred(new Scheduler.ScheduledCommand() {
			public void execute() {
				suggestBox.setFocus(true);
			}
		});
	}
}