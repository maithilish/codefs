package in.fins.client.content;

import in.fins.client.action.SymbolAction;
import in.fins.client.event.EventBus;
import in.fins.client.event.NameEvent;
import in.fins.client.event.SymbolEvent;
import in.fins.client.widget.AutoSuggest;
import in.fins.client.widget.FactPanel;
import in.fins.client.widget.TitlePanel;

import java.util.HashMap;
import java.util.Map;

import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiFactory;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.Grid;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.ResizeComposite;
import com.google.gwt.user.client.ui.Widget;

public class Snapshot extends ResizeComposite {

	interface SnapshotBinder extends UiBinder<Widget, Snapshot> {
	}

	private static UiBinder<Widget, Snapshot> binder = GWT
			.create(SnapshotBinder.class);

	@UiField
	AutoSuggest autoSuggest;

	@UiField
	Grid grid;

	public Snapshot() {
		initWidget(binder.createAndBindUi(this));
		autoSuggest.requestFocus();

		grid.getRowFormatter().setVerticalAlign(1,
				HasVerticalAlignment.ALIGN_TOP);

		SymbolAction symbolAction = new SymbolAction(getFilterMap());
		symbolAction.setEventSource(this);
		EventBus.get().addHandlerToSource(NameEvent.TYPE, this, symbolAction);
	}

	@UiFactory
	public AutoSuggest autoSuggestFactory() {
		AutoSuggest autoSuggest = new AutoSuggest();
		autoSuggest.setEventSource(this);
		return autoSuggest;
	}

	@UiFactory
	public TitlePanel titlePanelFactory() {
		TitlePanel tp = new TitlePanel();
		EventBus.get().addHandlerToSource(NameEvent.TYPE, this, tp);
		return tp;
	}

	@UiFactory
	public FactPanel factPanelFactory() {
		FactPanel fp = new FactPanel();
		EventBus.get().addHandlerToSource(SymbolEvent.TYPE, this, fp);
		return fp;
	}

	private static Map<String, String[]> getFilterMap() {
		Map<String, String[]> filterMap = new HashMap<String, String[]>();
		filterMap.put("Quote", getFilter("Quote"));
		return filterMap;
	}

	private static String[] getFilter(String cat) {
		if (cat.equals("Quote")) {
			return new String[] { "Price", "PB", "P/E", "BV", "DY (%)",
					"DIV (%)", "FV", "EPS", "Mk.Cap", "Ind. PE", "52 Wk High",
					"52 Wk Low" };
		}
		return null;
	}
}
