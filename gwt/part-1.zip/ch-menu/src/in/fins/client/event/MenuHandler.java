package in.fins.client.event;

import com.google.gwt.event.shared.EventHandler;

public interface MenuHandler extends EventHandler {

	public void onMenuSelection(MenuEvent menuEvent);

}