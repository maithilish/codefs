package in.fins.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.resources.client.ClientBundle;
import com.google.gwt.resources.client.ImageResource;

public interface FinsResources extends ClientBundle {

	public static final FinsResources INSTANCE = GWT
			.create(FinsResources.class);

	@Source("images/ratio.png")
	ImageResource ratio();

	@Source("images/watch.png")
	ImageResource watch();

	@Source("images/coffee.png")
	ImageResource coffee();

	@Source("images/pin.png")
	ImageResource pin();

	@Source("images/spanner.png")
	ImageResource spanner();

	@Source("images/folder-doc.png")
	ImageResource folderDoc();

	@Source("images/shopping-bag.png")
	ImageResource shoppingBag();

	@Source("images/shopping-cart.png")
	ImageResource shoppingCart();

	@Source("images/bean.png")
	ImageResource bean();

	@Source("images/puzzle.png")
	ImageResource puzzle();

	@Source("images/shipping.png")
	ImageResource shipping();

	@Source("images/dollar.png")
	ImageResource dollar();

	@Source("images/peers.png")
	ImageResource peers();

	@Source("images/blank.png")
	ImageResource blank();

	@Source("images/line.jpeg")
	ImageResource chart();

	@Source("images/chart.png")
	ImageResource barChart();

	@Source("images/next.png")
	ImageResource next();

	@Source("images/previous.png")
	ImageResource previous();

	@Source("images/table-sheet.png")
	ImageResource tablesheet();

	@Source("images/loading.gif")
	ImageResource loading();

	@Source("images/close.png")
	ImageResource close();
}
