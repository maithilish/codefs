
# this script reads finlabel.csv and 
# replaces finsName with finLabel in fins.xml file

function getFinLabel(){
 finName=$1
 ## FS is "","" so fields are indexed from $2
 finLabel=`awk -F'","|^"|"$' -v finName="$finName" '
   {
     name = $2
     if ( name == finName ){
       label=$3
       print label
       exit 0
     }
   }' finlabel.csv`
}

function getFinName(){
  line=$1
  finName=`awk -F'","|^"|"$' -v finName="$finName" '
   {
     name = $2
     if ( name == finName ){
       label=$3
       print label
       exit 0
     }
   }' finlabel.csv`
}

function replaceInFile(){
        fileName=$1
	matchStr=$2
	replaceStr=$3
        # @ is used as some str contains /
        sed -i -e "s@$matchStr@$replaceStr@g" $fileName
}

# replace finsName with finsLabel
while read -r line 
do 
     finName=`echo ${line} | awk -F'","|^"|"$' '{print $2}'`
     getFinLabel "$finName"
     replaceInFile fins.xml "$finName" "$finLabel" 
done< finlabel.csv 

rm sed*
