
RStore stores data in rdbms through JDO and retrieves 
data via JDO,Hibernate and MyBatis

Run the RStore 
--------------

1. add required datanucleus, hibernate and mybatis jars and 
   hsqldb.jar to lib dir and add them to project build path
2. start hsqldb
3. execute ant target - run

 
