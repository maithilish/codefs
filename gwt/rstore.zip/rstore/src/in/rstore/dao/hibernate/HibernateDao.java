package in.rstore.dao.hibernate;

import in.fins.shared.Data;
import in.fins.shared.DataGroup;
import in.fins.shared.Fact;
import in.fins.shared.Symbol;

import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class HibernateDao {

	private SessionFactory sf;

	Logger logger = Logger.getLogger("in.rstore.dao");

	public HibernateDao() throws IOException {
		try {
			Configuration configuration = new Configuration().configure();
			ServiceRegistry serviceRegistry = new ServiceRegistryBuilder()
					.applySettings(configuration.getProperties())
					.buildServiceRegistry();
			sf = configuration.buildSessionFactory(serviceRegistry);
		} catch (HibernateException e) {
			System.err.println("Initial SessionFactory creation failed." + e);
			throw new ExceptionInInitializerError(e);
		}
	}

	public void selectThroughQuery() {
		Session session = sf.openSession();
		try {
			Query q = session.getNamedQuery("selectSymbolNames");
			@SuppressWarnings("unchecked")
			List<String> list = q.list();
			System.out.println("[ Hibernate ]  Select Symbol names");
			System.out.println("   List size : " + list.size());
		} finally {
			session.close();
		}
	}

	public void selectSymbol(String name) {
		Session session = sf.openSession();
		try {
			Symbol symbol = (Symbol) session.load(Symbol.class, name);
			System.out.println("[ Hibernate ]  Select Symbol");
			int dataGroupSize = 0, dataSize = 0, factSize = 0;
			List<DataGroup> dgs = symbol.getDataGroups();
			dataGroupSize = dgs.size();
			for (DataGroup dg : dgs) {
				List<Data> dl = dg.getDataList();
				dataSize += dl.size();
				for (Data data : dl) {
					factSize += data.getFacts().size();
					for (Fact f : data.getFacts()) {
						logger.debug(f);
					}
				}
			}
			System.out.println("   " + symbol + "  DataGroups : "
					+ dataGroupSize + "  Data : " + dataSize + "  Facts : "
					+ factSize);
		} finally {
			session.close();
		}

	}

}
