package in.rstore.dao.jdo;

import in.fins.shared.Data;
import in.fins.shared.DataGroup;
import in.fins.shared.Fact;
import in.fins.shared.Symbol;
import in.fins.shared.SymbolHelper;

import java.io.IOException;
import java.util.List;

import javax.jdo.JDOHelper;
import javax.jdo.JDOObjectNotFoundException;
import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.Query;
import javax.jdo.Transaction;

import org.apache.log4j.Logger;

public class JdoDao {

	Logger logger = Logger.getLogger("in.rstore.dao");

	private PersistenceManagerFactory pmf;

	public JdoDao() throws IOException {
		pmf = JDOHelper.getPersistenceManagerFactory("datanucleus.properties");
	}

	public void insert(Symbol symbol) {
		PersistenceManager pm = pmf.getPersistenceManager();
		Transaction tx = pm.currentTransaction();
		try {
			tx.begin();
			Symbol existingSymbol = pm.getObjectById(Symbol.class,
					symbol.getName());
			System.out.print("   Update " + symbol + " ... ");
			SymbolHelper.updateSymbol(symbol, existingSymbol);
			tx.commit();
		} catch (JDOObjectNotFoundException e) {
			System.out.print("   Insert " + symbol + " ... ");
			pm.makePersistent(symbol);
			tx.commit();
		} finally {
			if (tx.isActive()) {
				tx.rollback();
			}
			System.out.println("Done");
			pm.close();
		}
	}

	public void selectThroughQuery() {
		PersistenceManager pm = pmf.getPersistenceManager();
		try {
			Query query = pm.newNamedQuery(Symbol.class, "selectSymbolNames");
			query.setResultClass(String.class);
			@SuppressWarnings("unchecked")
			List<String> list = (List<String>) query.execute();
			System.out.println("[ JDO ]  Select Symbol names");
			System.out.println("   List size : " + list.size());
		} finally {
			pm.close();
		}
	}

	public void selectObject(String name) {
		PersistenceManager pm = pmf.getPersistenceManager();
		try {
			Symbol symbol = pm.getObjectById(Symbol.class, name);
			System.out.println("[ JDO ]  Select Symbol");
			int dataGroupSize = 0, dataSize = 0, factSize = 0;
			List<DataGroup> dgs = symbol.getDataGroups();
			dataGroupSize = dgs.size();
			for (DataGroup dg : dgs) {
				List<Data> dl = dg.getDataList();
				dataSize += dl.size();
				for (Data data : dl) {
					factSize += data.getFacts().size();
					for (Fact f : data.getFacts()) {
						logger.debug(f);
					}
				}
			}
			System.out.println("   " + symbol + "  DataGroups : "
					+ dataGroupSize + "  Data : " + dataSize + "  Facts : "
					+ factSize);
		} finally {
			pmf.close();
		}

	}

}
