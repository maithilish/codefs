package in.rstore.dao.mybatis;

import in.fins.shared.Data;
import in.fins.shared.DataGroup;
import in.fins.shared.Fact;
import in.fins.shared.Symbol;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.log4j.Logger;

public class MyBatisDao {

	Logger logger = Logger.getLogger("in.rstore.dao");

	private SqlSessionFactory sqlSessionFactory;

	public MyBatisDao() throws IOException {
		String resource = "mybatis-config.xml";
		InputStream inputStream = Resources.getResourceAsStream(resource);
		sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
	}

	public void selectThroughQuery() {
		SqlSession session = sqlSessionFactory.openSession();
		try {
			List<String> list = session.selectList("mappers.selectSymbolNames");
			System.out.println("[ MyBatis ]  Select Symbol names");
			System.out.println("   List size : " + list.size());
		} finally {
			session.close();
		}

	}

	public void selectObject(String name) {
		SqlSession session = sqlSessionFactory.openSession();
		try {
			Symbol symbol = session.selectOne("selectSymbol", name);
			System.out.println("[ MyBatis ]  Select Symbol");
			int dataGroupSize = 0, dataSize = 0, factSize = 0;
			List<DataGroup> dgs = symbol.getDataGroups();
			dataGroupSize = dgs.size();
			for (DataGroup dg : dgs) {
				List<Data> dl = dg.getDataList();
				dataSize += dl.size();
				for (Data data : dl) {
					factSize += data.getFacts().size();
					for (Fact f : data.getFacts()) {
						logger.debug(f);
					}
				}
			}
			System.out.println("   " + symbol + "  DataGroups : "
					+ dataGroupSize + "  Data : " + dataSize + "  Facts : "
					+ factSize);
		} finally {
			session.close();
		}

	}

}
