package in.rstore;

import in.rstore.dao.hibernate.HibernateDao;
import in.rstore.dao.jdo.JdoDao;
import in.rstore.dao.mybatis.MyBatisDao;
import in.rstore.processor.ISymbolProcessor;
import in.rstore.processor.SymbolParser;

import java.io.FileInputStream;

import org.xml.sax.InputSource;

public class RStoreRunner {

	public static void main(String[] args) {
		if (args.length < 1) {
			System.out
					.println("Insufficient Arguments. Requires - name of xmlFile");
		}
		String xmlFile = args[0];
		try {
			System.out.println("[ JDO ]  Insert Symbol");
			InputSource xml = new InputSource(new FileInputStream(xmlFile));
			ISymbolProcessor symbolProcessor = new in.rstore.processor.SymbolProcessor();
			new SymbolParser(xml, symbolProcessor);

			JdoDao jdo = new JdoDao();
			jdo.selectThroughQuery();
			jdo.selectObject("Deep Blu");

			MyBatisDao mbd = new MyBatisDao();
			mbd.selectThroughQuery();
			mbd.selectObject("Deep Blu");

			HibernateDao hibd = new HibernateDao();
			hibd.selectThroughQuery();
			hibd.selectSymbol("Deep Blu");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
