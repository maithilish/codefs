package in.rstore.processor;

import in.fins.shared.Symbol;
import in.rstore.dao.jdo.JdoDao;

import java.io.IOException;

public class SymbolProcessor implements ISymbolProcessor {

	private JdoDao jdo;

	public SymbolProcessor() {
		try {
			jdo = new JdoDao();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void processSymbol(Symbol symbol) {
		if (jdo != null) {
			jdo.insert(symbol);
		}
	}

}
