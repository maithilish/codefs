package in.rstore.processor;

import in.fins.shared.Symbol;

public interface ISymbolProcessor {

	public void processSymbol(Symbol symbol);
}
