package in.fins.shared;

import java.util.Date;
import java.util.List;

import javax.jdo.JDOHelper;

public class SymbolHelper {

	public static DataGroup getDataGroup(Symbol symbol, String category) {
		return symbol.getDataGroup(category);
	}

	public static Data getData(Symbol symbol, String category, Date date) {
		DataGroup dataGroup = getDataGroup(symbol, category);
		if (dataGroup == null) {
			return null;
		}
		return dataGroup.getData(date);
	}

	public static List<Fact> getFacts(Symbol symbol, String category, Date date) {
		Data data = getData(symbol, category, date);
		if (data == null) {
			return null;
		}
		return data.getFacts();
	}

	public static Fact getFact(Symbol symbol, String category, Date date,
			String key) {
		List<Fact> facts = getFacts(symbol, category, date);
		if (facts == null) {
			return null;
		}
		for (Fact fact : facts) {
			if (fact != null) {
				String k = fact.getKey();
				if (k != null && k.equals(key)) {
					return fact;
				}
			}
		}
		return null;
	}

	public static Date getLastDate(Symbol symbol, String category) {
		DataGroup dataGroup = getDataGroup(symbol, category);
		if (dataGroup == null) {
			return null;
		}
		return dataGroup.lastDate();
	}

	public static Date getPositionDate(Symbol symbol, String category) {
		DataGroup dataGroup = getDataGroup(symbol, category);
		if (dataGroup == null) {
			return null;
		}
		return dataGroup.getPositionDate();
	}

	public static Date getOffsetDate(Symbol symbol, String category, Date date,
			int offset) {
		DataGroup dataGroup = getDataGroup(symbol, category);
		if (dataGroup == null) {
			return null;
		}
		List<Date> dateList = dataGroup.getDateList();
		int index = dateList.indexOf(date) + offset;
		if (index < 0) {
			index = 0;
		}
		if (index >= dateList.size()) {
			index = dateList.size() - 1;
		}
		return dateList.get(index);
	}

	public static void setPositionDate(Symbol symbol, String category, Date date) {
		DataGroup dataGroup = getDataGroup(symbol, category);
		if (dataGroup != null) {
			dataGroup.setPositionDate(date);
		}
	}

	public static void addFact(Symbol symbol, String category, Date date,
			Fact fact) {
		if (fact.getKey() == null) {
			return;
		}
		Data data = getData(symbol, category, date);
		if (data == null) {
			DataGroup dataGroup = getDataGroup(symbol, category);
			if (dataGroup == null) {
				// System.out.println("creating new datagroup for category "
				// + category);
				dataGroup = new DataGroup();
				dataGroup.setCategory(category);
				symbol.addDataGroup(dataGroup);
			}
			data = new Data();
			data.setDate(date);
			data.addFact(fact);
			dataGroup.addData(data);
			// System.out.println("creating new Data for date " + date);
			// System.out.println("Fact added : Fact " + fact);
		} else {
			data.addFact(fact);
			// facts is @Persistent(serialized = "true")
			// any changes to facts is not noticed by JDO
			// mark dirty explicitly
			JDOHelper.makeDirty(data, "facts");
			// System.out.println("Fact added to existing data : Fact " + fact);
		}
	}

	public static void updateSymbol(Symbol srcSymbol, Symbol dstSymbol) {
		for (DataGroup dataGroup : srcSymbol.getDataGroups()) {
			for (Data data : dataGroup.getDataList()) {
				for (Fact fact : data.getFacts()) {
					// dest Fact
					Fact dstFact = getFact(dstSymbol, dataGroup.getCategory(),
							data.getDate(), fact.getKey());
					if (dstFact == null) {
						// System.out.println("---Add new fact----");
						// System.out.println("Dest Fact null for category "
						// + dataGroup.getCategory() + " date "
						// + data.getDate() + " key " + fact.getKey());
						addFact(dstSymbol, dataGroup.getCategory(),
								data.getDate(), fact);
					} else {
						// System.out.println("---Alter fact value----");
						// System.out.println("Dest Fact exists for category "
						// + dataGroup.getCategory() + " date "
						// + data.getDate() + " key " + fact.getKey());
						dstFact.setValue(fact.getValue());
					}
				}
			}
		}
		// System.out.println("--Altered datasource symbol--");
		// for (DataGroup dataGroup : dsSym.getDataGroups()) {
		// System.out.println("Category " + dataGroup.getCategory());
		// for (Data data : dataGroup.getDataList()) {
		// System.out.println("Date " + data.getDate());
		// for (Fact fact : data.getFacts()) {
		// System.out.println(fact);
		// }
		// }
		// }
	}

}
