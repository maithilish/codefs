package in.fins.shared;

import java.io.Serializable;

public class Fact implements Serializable {

	private static final long serialVersionUID = 1L;
	private String key;
	private String value;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getRoundoff() {
		try {
			return String.valueOf(Math.round(new Double(value)));
		} catch (Exception e) {
			return value;
		}
	}

	@Override
	public String toString() {
		return "   Fact [key=" + key + ", value=" + value + "]";
	}

}
