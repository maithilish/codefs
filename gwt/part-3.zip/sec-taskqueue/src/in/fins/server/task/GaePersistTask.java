package in.fins.server.task;

import static com.google.appengine.api.taskqueue.TaskOptions.Builder.withUrl;
import in.fins.server.cache.ICache;
import in.fins.server.dao.DaoFactory;
import in.fins.server.dao.DaoFactory.ORM;
import in.fins.server.dao.IDao;
import in.fins.server.util.Utils;
import in.fins.shared.Symbol;

import java.io.IOException;
import java.util.Map;
import java.util.logging.Logger;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.api.taskqueue.Queue;
import com.google.appengine.api.taskqueue.QueueFactory;
import com.google.appengine.api.taskqueue.TaskOptions;
import com.google.appengine.api.taskqueue.TaskOptions.Method;

public class GaePersistTask extends HttpServlet implements ITask {

	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(GaePersistTask.class
			.getName());

	private DaoFactory daoFactory;

	@Override
	public void execute(Map<String, Object> parameters) throws Exception {
		String qName = (String) parameters.get("queueName");
		String symbolName = (String) parameters.get("symbolName");
		Queue queue = QueueFactory.getQueue(qName);
		TaskOptions task = withUrl("/fins/gaePersistTask").param("symbolName",
				symbolName).method(Method.POST);
		queue.add(task);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		try {
			ICache cache = Utils.createInstance(ICache.class,
					"in.fins.server.cache.GaeCache");
			String symbolName = req.getParameter("symbolName");
			cache.createCache();
			Symbol symbol = (Symbol) cache.get(symbolName);
			persistSymbol(symbol);
		} catch (Exception e) {
			log.warning(e.getMessage());
		}
	}

	public void persistSymbol(Symbol symbol) throws Exception {
		try {
			initDaoFactory();
			IDao<Symbol> symbolDao = daoFactory.getDao(Symbol.class);
			symbolDao.insert(symbol);
		} catch (Exception e) {
			log.warning(e.getMessage());
			throw e;
		}
	}

	private void initDaoFactory() throws Exception {
		try {
			if (daoFactory == null) {
				ServletContext servletContext = getServletContext();
				String ormStr = (String) servletContext.getAttribute("orm");
				ORM orm = DaoFactory.getOrmType(ormStr);
				daoFactory = DaoFactory.getDaoFactory(orm);
			}
		} catch (Exception e) {
			log.warning(e.getMessage());
			throw e;
		}
	}

}
