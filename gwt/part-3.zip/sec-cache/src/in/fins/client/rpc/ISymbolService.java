package in.fins.client.rpc;

import in.fins.shared.Data;
import in.fins.shared.DataGroup;
import in.fins.shared.Symbol;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

@RemoteServiceRelativePath("symbolService")
public interface ISymbolService extends RemoteService {

	public List<String> getSymbolNames() throws Exception;

	public Symbol getSymbol(String symbolName, Map<String, String[]> filterMap)
			throws Exception;

	public Data getData(String symbolName, String category, Date date,
			int offset, String[] filter) throws Exception;

	public DataGroup getDataGroup(String symbolName, String category,
			String[] filter) throws Exception;

}
