package in.fins.shared;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Data implements Comparable<Data>, Serializable {

	private static final long serialVersionUID = 1L;

	private long id;
	private Date date;
	private List<Fact> facts;

	public long getId() {
		return id;
	}

	@SuppressWarnings("unused")
	private void setId(long id) {
		this.id = id;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public List<Fact> getFacts() {
		return facts;
	}

	public void setFacts(List<Fact> facts) {
		this.facts = facts;
	}

	@Override
	public int compareTo(Data o) {
		return this.date.compareTo(o.date);
	}

	public void addFact(Fact fact) {
		if (facts == null) {
			facts = new ArrayList<Fact>();
		}
		facts.add(fact);
	}

	@Override
	public String toString() {
		return "  Data [date=" + date + "]";
	}

}
