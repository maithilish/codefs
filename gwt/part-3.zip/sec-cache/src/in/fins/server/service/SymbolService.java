package in.fins.server.service;

import in.fins.client.rpc.ISymbolService;
import in.fins.server.dao.DaoFactory;
import in.fins.server.dao.DaoFactory.ORM;
import in.fins.server.dao.IDao;
import in.fins.shared.Data;
import in.fins.shared.DataGroup;
import in.fins.shared.Symbol;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.servlet.ServletContext;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;

public class SymbolService extends RemoteServiceServlet implements
		ISymbolService {

	private static final Logger log = Logger.getLogger(SymbolService.class
			.getName());

	private static final long serialVersionUID = 1L;

	private DaoFactory daoFactory;

	public SymbolService() {
		super();
	}

	@Override
	public List<String> getSymbolNames() throws Exception {
		try {
			initDaoFactory();
			IDao<String> dao = daoFactory.getDao(String.class);
			List<String> list = dao.select(Symbol.class, String.class,
					"selectSymbolNames", null);
			return list;
		} catch (Exception e) {
			log.warning(e.getMessage());
			throw e;
		}
	}

	@Override
	public Symbol getSymbol(String symbolName, Map<String, String[]> filterMap)
			throws Exception {
		try {
			initDaoFactory();
			IDao<Symbol> dao = daoFactory.getDao(Symbol.class);
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("symbolName", symbolName);
			parameters.put("filterMap", filterMap);
			return dao.selectById(Symbol.class, parameters);
		} catch (Exception e) {
			log.warning(e.getMessage());
			throw e;
		}
	}

	@Override
	public Data getData(String symbolName, String category, Date date,
			int offset, String[] filter) throws Exception {
		try {
			initDaoFactory();
			IDao<Data> dao = daoFactory.getDao(Data.class);
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("symbolName", symbolName);
			parameters.put("category", category);
			parameters.put("date", date);
			parameters.put("offset", offset);
			parameters.put("filter", filter);
			return dao.selectById(Data.class, parameters);
		} catch (Exception e) {
			log.warning(e.getMessage());
			throw e;
		}
	}

	@Override
	public DataGroup getDataGroup(String symbolName, String category,
			String[] filter) throws Exception {
		try {
			initDaoFactory();
			IDao<DataGroup> dao = daoFactory.getDao(DataGroup.class);
			Map<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("symbolName", symbolName);
			parameters.put("category", category);
			parameters.put("filter", filter);
			return dao.selectById(DataGroup.class, parameters);
		} catch (Exception e) {
			log.warning(e.getMessage());
			throw e;
		}
	}

	private void initDaoFactory() throws Exception {
		try {
			if (daoFactory == null) {
				ServletContext servletContext = getServletContext();
				String ormStr = (String) servletContext.getAttribute("orm");
				if (ormStr == null) {
					ormStr = "JDO";
				}
				ORM orm = null;
				if (ormStr.equals("JDO")) {
					orm = ORM.JDO;
				}
				if (ormStr.equals("MyBatis")) {
					orm = ORM.MyBatis;
				}
				if (ormStr.equals("Hibernate")) {
					orm = ORM.Hibernate;
				}
				daoFactory = DaoFactory.getDaoFactory(orm);
			}
			log.info("Instance # [SymbolService] " + this.hashCode()
					+ " [DaoFactory] " + daoFactory.hashCode());
		} catch (Exception e) {
			log.warning(e.getMessage());
			throw e;
		}
	}

}
