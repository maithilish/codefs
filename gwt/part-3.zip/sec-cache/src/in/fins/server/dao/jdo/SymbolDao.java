package in.fins.server.dao.jdo;

import in.fins.server.dao.IDao;
import in.fins.shared.Symbol;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.persistence.PersistenceException;

public class SymbolDao<T> implements IDao<T> {

	private static final Logger log = Logger.getLogger(SymbolDao.class
			.getName());

	protected PersistenceManagerFactory pmf;

	public SymbolDao(PersistenceManagerFactory pmf) {
		this.pmf = pmf;
		if (pmf == null)
			log.warning("Loading JDO PersistaceManagerFactory failed.");

	}

	@SuppressWarnings("unchecked")
	@Override
	public T selectById(Class<T> clz, Map<?, ?> parameters)
			throws PersistenceException {
		PersistenceManager pm = pmf.getPersistenceManager();
		Symbol symbol;
		try {
			String id = (String) parameters.get("symbolName");
			Symbol sym = pm.getObjectById(Symbol.class, id);
			log.fine(sym.getName());
			/*
			 * pm.detachCopyAll will eagerly load the entire symbol. applyFilter
			 * access required datagroup/data/fact this lazy loads the symbol
			 */
			Map<String, String[]> filterMap = (Map<String, String[]>) parameters
					.get("filterMap");
			symbol = DaoHelper.applyFilter(sym, filterMap);
		} catch (PersistenceException e) {
			log.severe(e.getMessage());
			throw e;
		} finally {
			pm.close();
		}
		return (T) symbol;
	}

	@Override
	public List<T> select(Class<?> clz, Class<T> resultClz, String statement,
			Map<?, ?> parameters) throws PersistenceException {
		// TODO Auto-generated method stub
		return null;
	}
}
