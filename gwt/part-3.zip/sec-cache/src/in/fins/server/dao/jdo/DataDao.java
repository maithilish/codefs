package in.fins.server.dao.jdo;

import in.fins.server.dao.IDao;
import in.fins.shared.Data;
import in.fins.shared.Symbol;
import in.fins.shared.SymbolHelper;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.persistence.PersistenceException;

public class DataDao<T> implements IDao<T> {

	private static final Logger log = Logger.getLogger(DataDao.class.getName());

	protected PersistenceManagerFactory pmf;

	public DataDao(PersistenceManagerFactory pmf) {
		this.pmf = pmf;
		if (pmf == null)
			log.warning("Loading JDO PersistaceManagerFactory failed.");

	}

	@SuppressWarnings("unchecked")
	@Override
	public T selectById(Class<T> clz, Map<?, ?> parameters)
			throws PersistenceException {
		PersistenceManager pm = pmf.getPersistenceManager();
		Data filteredData;
		try {
			String id = (String) parameters.get("symbolName");
			String category = (String) parameters.get("category");
			Date date = (Date) parameters.get("date");
			int offset = (Integer) parameters.get("offset");
			String[] filter = (String[]) parameters.get("filter");
			log.fine("selectData Symbol " + id + " cat " + category + " date "
					+ date + " offset " + offset);
			Symbol sym = pm.getObjectById(Symbol.class, id);
			Date offsetDate = SymbolHelper.getOffsetDate(sym, category, date,
					offset);
			Data data = SymbolHelper.getData(sym, category, offsetDate);
			/*
			 * pm.detachCopyAll will eagerly load the entire symbol. applyFilter
			 * access required data/fact this lazy loads the symbol
			 */
			filteredData = DaoHelper.applyFilter(data, filter);
		} catch (PersistenceException e) {
			log.severe(e.getMessage());
			throw e;
		} finally {
			pm.close();
		}
		return (T) filteredData;
	}

	@Override
	public List<T> select(Class<?> clz, Class<T> resultClz, String statement,
			Map<?, ?> parameters) throws PersistenceException {
		// TODO Auto-generated method stub
		return null;
	}

}
