package in.fins.server.dao.mybatis;

import in.fins.server.dao.IDao;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.persistence.PersistenceException;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

public class Dao<T> implements IDao<T> {

	private static final Logger log = Logger.getLogger(Dao.class.getName());

	private SqlSessionFactory ssf;

	public Dao(SqlSessionFactory ssf) {
		this.ssf = ssf;
		if (ssf == null)
			log.warning("Loading MyBatis SqlSessionFactory failed.");
	}

	@Override
	public T selectById(Class<T> clz, Map<?, ?> parameters)
			throws PersistenceException {
		// not implementable as MyBatis requires a statement
		return null;
	}

	@Override
	public List<T> select(Class<?> clz, Class<T> resultClz, String namedQuery,
			Map<?, ?> parameters) {
		SqlSession session = ssf.openSession();
		try {
			List<T> list = null;
			if (parameters == null) {
				list = session.selectList("mappers." + namedQuery);
			} else {
				list = session.selectList("mappers." + namedQuery, parameters);
			}
			return list;
		} finally {
			session.close();
		}
	}

}
