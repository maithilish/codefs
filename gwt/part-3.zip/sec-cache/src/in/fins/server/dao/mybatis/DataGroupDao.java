package in.fins.server.dao.mybatis;

import in.fins.server.dao.IDao;
import in.fins.shared.DataGroup;
import in.fins.shared.Symbol;
import in.fins.shared.SymbolHelper;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.persistence.PersistenceException;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

public class DataGroupDao<T> implements IDao<T> {

	private static final Logger log = Logger.getLogger(DataGroupDao.class
			.getName());

	private SqlSessionFactory ssf;

	public DataGroupDao(SqlSessionFactory ssf) {
		this.ssf = ssf;
		if (ssf == null)
			log.warning("Loading MyBatis SqlSessionFactory failed.");
	}

	@SuppressWarnings("unchecked")
	@Override
	public T selectById(Class<T> clz, Map<?, ?> parameters)
			throws PersistenceException {
		SqlSession session = ssf.openSession();
		DataGroup filteredDataGroup;
		try {
			String symbolName = (String) parameters.get("symbolName");
			String category = (String) parameters.get("category");
			String[] filter = (String[]) parameters.get("filter");
			log.fine("selectDataGroup Symbol " + symbolName + " cat "
					+ category);
			Symbol sym = session.selectOne("mappers.selectSymbol", symbolName);
			DataGroup dataGroup = SymbolHelper.getDataGroup(sym, category);
			filteredDataGroup = DaoHelper.applyFilter(dataGroup, filter);
		} catch (PersistenceException e) {
			log.severe(e.getMessage());
			throw e;
		} finally {
			session.close();
		}
		return (T) filteredDataGroup;
	}

	@Override
	public List<T> select(Class<?> clz, Class<T> resultClz, String statement,
			Map<?, ?> parameters) throws PersistenceException {
		// TODO Auto-generated method stub
		return null;
	}

}
