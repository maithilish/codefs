package in.fins.server.dao;

import java.util.List;
import java.util.Map;

import javax.persistence.PersistenceException;

public interface IDao<T> {

	public T selectById(Class<T> clz, Map<?, ?> parameters)
			throws PersistenceException;

	public List<T> select(Class<?> clz, Class<T> resultClz, String statement,
			Map<?, ?> parameters) throws PersistenceException;

}
