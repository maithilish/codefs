package in.fins.shared;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SymbolHelper {

	public static DataGroup getDataGroup(Symbol symbol, String category) {
		return symbol.getDataGroup(category);
	}

	public static Data getData(Symbol symbol, String category, Date date) {
		DataGroup dataGroup = getDataGroup(symbol, category);
		if (dataGroup == null) {
			return null;
		}
		return dataGroup.getData(date);
	}

	public static void replaceData(Symbol symbol, String category, Data data) {
		Data existingData = getData(symbol, category, data.getDate());
		DataGroup dataGroup = getDataGroup(symbol, category);
		dataGroup.getDataList().remove(existingData);
		dataGroup.addData(data);
	}

	public static List<Fact> getFacts(Symbol symbol, String category, Date date) {
		Data data = getData(symbol, category, date);
		if (data == null) {
			return null;
		}
		return data.getFacts();
	}

	public static Fact getFact(Symbol symbol, String category, Date date,
			String key) {
		List<Fact> facts = getFacts(symbol, category, date);
		if (facts == null) {
			return null;
		}
		for (Fact fact : facts) {
			if (fact != null) {
				String k = fact.getKey();
				if (k != null && k.equals(key)) {
					return fact;
				}
			}
		}
		return null;
	}

	public static Date getLastDate(Symbol symbol, String category) {
		DataGroup dataGroup = getDataGroup(symbol, category);
		if (dataGroup == null) {
			return null;
		}
		return dataGroup.lastDate();
	}

	public static Date getPositionDate(Symbol symbol, String category) {
		DataGroup dataGroup = getDataGroup(symbol, category);
		if (dataGroup == null) {
			return null;
		}
		return dataGroup.getPositionDate();
	}

	public static Date getOffsetDate(Symbol symbol, String category, Date date,
			int offset) {
		DataGroup dataGroup = getDataGroup(symbol, category);
		if (dataGroup == null) {
			return null;
		}
		List<Date> dates = dataGroup.getDateList();
		int index = 0;
		for (int c = 0; c < dates.size(); c++) {
			if (dates.get(c).compareTo(date) == 0) {
				index = c;
			}
		}
		index = index + offset;
		if (index < 0) {
			index = 0;
		}
		if (index >= dates.size()) {
			index = dates.size() - 1;
		}
		return dates.get(index);
	}

	public static void setPositionDate(Symbol symbol, String category, Date date) {
		DataGroup dataGroup = getDataGroup(symbol, category);
		if (dataGroup != null) {
			dataGroup.setPositionDate(date);
		}
	}

	public static void addFact(Symbol symbol, String category, Date date,
			Fact fact) {
		Data data = getData(symbol, category, date);
		if (data == null) {
			DataGroup dataGroup = getDataGroup(symbol, category);
			if (dataGroup == null) {
				dataGroup = new DataGroup();
				dataGroup.setCategory(category);
				symbol.addDataGroup(dataGroup);
			}
			data = new Data();
			data.setDate(date);
			data.addFact(fact);
			dataGroup.addData(data);
		} else {
			data.addFact(fact);
		}
	}

	public static void setFacts(Symbol symbol, String category, Date date,
			List<Fact> facts) {
		Data data = getData(symbol, category, date);
		if (data == null) {
			DataGroup dataGroup = getDataGroup(symbol, category);
			if (dataGroup == null) {
				dataGroup = new DataGroup();
				dataGroup.setCategory(category);
				symbol.addDataGroup(dataGroup);
			}
			data = new Data();
			data.setDate(new Date(date.getTime()));
			dataGroup.addData(data);
		}
		data.setFacts(facts);
	}

	public static void updateSymbol(Symbol srcSymbol, Symbol dstSymbol) {
		for (DataGroup dataGroup : srcSymbol.getDataGroups()) {
			for (Data data : dataGroup.getDataList()) {
				for (Fact fact : data.getFacts()) {
					// dest Fact
					Fact dstFact = getFact(dstSymbol, dataGroup.getCategory(),
							data.getDate(), fact.getKey());
					if (dstFact == null) {
						addFact(dstSymbol, dataGroup.getCategory(),
								data.getDate(), fact);
					} else {
						dstFact.setValue(fact.getValue());
					}
				}
			}
		}
	}

	public static List<String> getCategories(Symbol symbol) {
		List<String> cats = new ArrayList<String>();
		for (DataGroup dataGroup : symbol.getDataGroups()) {
			cats.add(dataGroup.getCategory());
		}
		return cats;
	}
}
