package in.fins.shared;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class DataGroup implements Serializable {

	private static final long serialVersionUID = 1L;

	private String id;
	private String category;
	private List<Data> dataList;
	private Date positionDate;

	public String getId() {
		return id;
	}

	@SuppressWarnings("unused")
	private void setId(String id) {
		this.id = id;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public List<Data> getDataList() {
		return dataList;
	}

	public void setDataList(List<Data> dataList) {
		Collections.sort(dataList);
		this.dataList = dataList;
	}

	public Date getPositionDate() {
		return positionDate;
	}

	public void setPositionDate(Date date) {
		this.positionDate = date;
	}

	public Date lastDate() {
		// sorted dates
		List<Date> dates = getDateList();
		if (dates != null && dates.size() > 0) {
			return dates.get(dates.size() - 1);
		}
		return null;
	}

	public Date firstDate() {
		// sorted dates
		List<Date> dates = getDateList();
		if (dates != null && dates.size() > 0) {
			return dates.get(0);
		}
		return null;
	}

	public Data getData(Date date) {
		if (dataList == null) {
			return null;
		}
		for (Data data : dataList) {
			if (data.getDate().equals(date)) {
				return data;
			}
		}
		return null;
	}

	public List<Date> getDateList() {
		if (dataList == null) {
			return null;
		}
		List<Date> dateList = new ArrayList<Date>();
		for (Data data : dataList) {
			dateList.add(data.getDate());
		}
		Collections.sort(dateList);
		return dateList;
	}

	public void addData(Data data) {
		if (dataList == null) {
			dataList = new ArrayList<Data>();
		}
		dataList.add(data);
	}

	@Override
	public String toString() {
		return " DataGroup [category=" + category + "]";
	}

}
