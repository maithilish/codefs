package in.fins.server.dao.jdo;

public class DaoHelper extends in.fins.server.dao.DaoHelper {

}
