package in.fins.server.dao;

import in.fins.shared.Data;
import in.fins.shared.DataGroup;
import in.fins.shared.Fact;
import in.fins.shared.Symbol;
import in.fins.shared.SymbolHelper;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

public abstract class DaoHelper {

	private static final Logger log = Logger.getLogger(DaoHelper.class
			.getName());

	public static Symbol applyFilter(Symbol symbol,
			Map<String, String[]> filterMap) {
		Symbol filteredSymbol = new Symbol();
		filteredSymbol.setName(symbol.getName());
		filteredSymbol.setLabel(symbol.getLabel());
		for (String category : filterMap.keySet()) {
			try {
				Date lastDate = SymbolHelper.getLastDate(symbol, category);
				List<Fact> facts = SymbolHelper.getFacts(symbol, category,
						lastDate);
				List<Fact> filteredFacts = filterFacts(facts,
						filterMap.get(category));
				SymbolHelper.setFacts(filteredSymbol, category, lastDate,
						filteredFacts);
			} catch (Exception e) {
				log.warning(e.getMessage());
			}
		}
		return filteredSymbol;
	}

	public static Data applyFilter(Data data, String[] filter) {
		Data filteredData = new Data();
		filteredData.setDate(new Date(data.getDate().getTime()));
		filteredData.setFacts(filterFacts(data.getFacts(), filter));
		return filteredData;
	}

	public static DataGroup applyFilter(DataGroup dataGroup, String[] filter) {
		DataGroup filteredDataGroup = new DataGroup();
		filteredDataGroup.setCategory(dataGroup.getCategory());
		for (Data data : dataGroup.getDataList()) {
			filteredDataGroup.addData(applyFilter(data, filter));
		}
		return filteredDataGroup;
	}

	private static List<Fact> filterFacts(List<Fact> list, String[] filter) {
		// sorted in filter order hence new list
		List<Fact> filteredList = new ArrayList<Fact>();
		if (filter == null) {
			// return a blank list as items specified in filter are required
			return filteredList;
		}
		for (String l : filter) {
			for (Fact fact : list) {
				if (l.equals(fact.getKey())) {
					Fact newFact = new Fact();
					newFact.setKey(fact.getKey());
					newFact.setValue(fact.getValue());
					filteredList.add(newFact);
				}
			}
		}

		// index is required hence for loop
		for (int c = 0; c < filter.length; c++) {
			boolean found = false;
			for (Fact fact : list) {
				if (filter[c].equals(fact.getKey())) {
					found = true;
				}
			}
			if (found == false) {
				Fact missingFact = new Fact();
				missingFact.setKey(filter[c]);
				missingFact.setValue("");
				filteredList.add(c, missingFact);
			}
		}
		return filteredList;
	}

}
