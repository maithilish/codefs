package in.fins.server.dao.hibernate;

import in.fins.server.dao.IDao;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.persistence.PersistenceException;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Dao<T> implements IDao<T> {

	private static final Logger log = Logger.getLogger(Dao.class.getName());
	private SessionFactory sf;

	public Dao(SessionFactory sf) {
		this.sf = sf;
		if (sf == null)
			log.warning("Loading Hibernate PersistaceManagerFactory failed.");
	}

	@SuppressWarnings("unchecked")
	@Override
	public T selectById(Class<T> clz, Map<?, ?> parameters)
			throws PersistenceException {
		Session session = sf.openSession();
		T obj;
		try {
			String id = (String) parameters.get("id");
			obj = (T) session.load(clz, id);
		} catch (PersistenceException e) {
			log.severe(e.getMessage());
			throw e;
		} finally {
			session.close();
		}
		return obj;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> select(Class<?> clz, Class<T> resultClz, String namedQuery,
			Map<?, ?> parameters) {
		Session session = sf.openSession();
		List<T> list = null;
		try {
			Query query = session.getNamedQuery(namedQuery);
			// use named parameter style
			if (parameters != null) {
				for (Object key : parameters.keySet()) {
					query.setParameter((String) key, parameters.get(key));
				}
			}
			list = query.list();
		} finally {
			session.close();
		}
		return list;
	}

	@Override
	public void insert(T object) throws PersistenceException {
		throw new PersistenceException("This method is not implemented");
	}

}
