package in.fins.server.dao.mybatis;

import in.fins.server.dao.IDao;
import in.fins.shared.Data;
import in.fins.shared.DataGroup;
import in.fins.shared.Symbol;

import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Logger;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class DaoFactory extends in.fins.server.dao.DaoFactory {

	private static final Logger log = Logger.getLogger(DaoFactory.class
			.getName());

	private SqlSessionFactory ssf;

	public DaoFactory() {
		String resource = "META-INF/mybatis-config.xml";
		InputStream inputStream;
		try {
			inputStream = Resources.getResourceAsStream(resource);
			ssf = new SqlSessionFactoryBuilder().build(inputStream);
		} catch (IOException e) {
			log.warning(e.getMessage());
		}
	}

	@Override
	public <T> IDao<T> getDao(Class<T> clz) throws Exception {
		if (clz == Symbol.class) {
			log.fine("MyBatis SymbolDao returned");
			return (IDao<T>) new SymbolDao<T>(ssf);
		}
		if (clz == Data.class) {
			log.fine("MyBatis DataDao returned");
			return (IDao<T>) new DataDao<T>(ssf);
		}
		if (clz == DataGroup.class) {
			log.fine("MyBatis DataGroupDao returned");
			return (IDao<T>) new DataGroupDao<T>(ssf);
		}
		log.fine("MyBatis Generic Dao returned");
		return (IDao<T>) new Dao<T>(ssf);
	}

}
