package in.fins.server.dao.hibernate;

import in.fins.server.dao.IDao;
import in.fins.shared.DataGroup;
import in.fins.shared.Symbol;
import in.fins.shared.SymbolHelper;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.persistence.PersistenceException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class DataGroupDao<T> implements IDao<T> {

	private static final Logger log = Logger.getLogger(DataGroupDao.class
			.getName());

	private SessionFactory sf;

	public DataGroupDao(SessionFactory sf) {
		this.sf = sf;
		if (sf == null)
			log.warning("Loading Hibernate SessionFactory failed.");

	}

	@SuppressWarnings("unchecked")
	@Override
	public T selectById(Class<T> clz, Map<?, ?> parameters)
			throws PersistenceException {
		Session session = sf.openSession();
		DataGroup filteredDataGroup;
		try {
			String id = (String) parameters.get("symbolName");
			String category = (String) parameters.get("category");
			String[] filter = (String[]) parameters.get("filter");
			log.fine("selectDataGroup Symbol " + id + " cat " + category);
			Symbol sym = (Symbol) session.load(Symbol.class, id);
			DataGroup dataGroup = SymbolHelper.getDataGroup(sym, category);
			/*
			 * pm.detachCopyAll will eagerly load the entire symbol. applyFilter
			 * access required data/fact to lazy load the symbol
			 */
			filteredDataGroup = DaoHelper.applyFilter(dataGroup, filter);
		} catch (PersistenceException e) {
			log.severe(e.getMessage());
			throw e;
		} finally {
			session.close();
		}
		return (T) filteredDataGroup;
	}

	@Override
	public List<T> select(Class<?> clz, Class<T> resultClz, String statement,
			Map<?, ?> parameters) throws PersistenceException {
		throw new PersistenceException("This method is not implemented");
	}

	@Override
	public void insert(T dataGroup) throws PersistenceException {
		throw new PersistenceException("This method is not implemented");
	}

}
