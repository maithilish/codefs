package in.fins.server.util;

import java.util.logging.Logger;

public class Utils {

	private static final Logger log = Logger.getLogger(Utils.class.getName());

	public static <T> T createInstance(Class<T> inf, String className)
			throws Exception {
		ClassLoader classLoader = Utils.class.getClassLoader();
		try {
			Class<?> clazz = classLoader.loadClass(className);
			return inf.cast(clazz.newInstance());
		} catch (Exception e) {
			log.warning(e.getMessage());
			throw e;
		}
	}

}
