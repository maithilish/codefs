package in.fins.server.cache;

public interface ICache {

	public void createCache() throws Exception;

	public void put(String key, Object value);

	public Object get(String key);

	public void clear();
}
