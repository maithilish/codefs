package in.fins.server.cache;

import java.util.Collections;
import java.util.logging.Logger;

import net.sf.jsr107cache.Cache;
import net.sf.jsr107cache.CacheException;
import net.sf.jsr107cache.CacheFactory;
import net.sf.jsr107cache.CacheManager;

public class GaeCache implements ICache {

	private static final Logger log = Logger
			.getLogger(GaeCache.class.getName());

	private Cache cache;

	@Override
	public void createCache() throws Exception {
		try {
			if (cache == null) {
				CacheFactory cacheFactory = CacheManager.getInstance()
						.getCacheFactory();
				cache = cacheFactory.createCache(Collections.emptyMap());
			}
		} catch (CacheException e) {
			log.warning(e.getMessage());
			throw e;
		}
	}

	@Override
	public void put(String key, Object value) {
		cache.put(key, value);
	}

	@Override
	public Object get(String key) {
		return cache.get(key);
	}

	@Override
	public void clear() {
		cache.clear();
	}

}
