package in.fins.server.cache;

import java.util.HashMap;
import java.util.Map;

public class SimpleCache implements ICache {

	private Cache cache;

	@Override
	public void createCache() throws Exception {
		cache = Cache.INSTANCE;
	}

	@Override
	public void put(String key, Object value) {
		cache.put(key, value);
	}

	@Override
	public Object get(String key) {
		return cache.get(key);
	}

	@Override
	public void clear() {
		cache.clear();
	}

}

// Singleton Cache

class Cache {

	public static final Cache INSTANCE = new Cache();

	private Map<String, Object> cache;

	private Cache() {
		cache = new HashMap<String, Object>();
	}

	public void clear() {
		cache.clear();
	}

	public Object get(String key) {
		return cache.get(key);
	}

	public void put(String key, Object value) {
		cache.put(key, value);
	}
}