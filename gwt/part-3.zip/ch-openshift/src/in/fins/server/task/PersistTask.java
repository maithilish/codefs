package in.fins.server.task;

import in.fins.server.cache.ICache;
import in.fins.server.dao.DaoFactory;
import in.fins.server.dao.DaoFactory.ORM;
import in.fins.server.dao.IDao;
import in.fins.server.util.Utils;
import in.fins.shared.Symbol;

import java.util.Map;
import java.util.logging.Logger;

public class PersistTask implements ITask {

	private static final Logger log = Logger.getLogger(PersistTask.class
			.getName());
	private DaoFactory daoFactory;

	@Override
	public void execute(Map<String, Object> parameters) throws Exception {
		String ormName = (String) parameters.get("ormName");
		ORM orm = DaoFactory.getOrmType(ormName);
		daoFactory = DaoFactory.getDaoFactory(orm);
		String symbolName = (String) parameters.get("symbolName");
		ICache cache = Utils.createInstance(ICache.class,
				"in.fins.server.cache.SimpleCache");
		cache.createCache();
		Symbol symbol = (Symbol) cache.get(symbolName);
		persistSymbol(symbol);
	}

	public void persistSymbol(Symbol symbol) throws Exception {
		try {
			IDao<Symbol> symbolDao = daoFactory.getDao(Symbol.class);
			symbolDao.insert(symbol);
		} catch (Exception e) {
			e.printStackTrace();
			log.warning(e.getMessage());
			throw e;
		}
	}

}
