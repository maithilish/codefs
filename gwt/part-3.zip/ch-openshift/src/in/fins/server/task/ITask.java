package in.fins.server.task;

import java.util.Map;

public interface ITask {

	public void execute(Map<String, Object> parameters) throws Exception;

}
