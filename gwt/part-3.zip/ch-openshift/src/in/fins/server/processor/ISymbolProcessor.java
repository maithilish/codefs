package in.fins.server.processor;

import in.fins.shared.Symbol;

public interface ISymbolProcessor {

	public void processSymbol(Symbol symbol);
}
