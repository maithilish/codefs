package in.fins.server.processor;

import in.fins.shared.Fact;
import in.fins.shared.Symbol;
import in.fins.shared.SymbolHelper;

import java.io.IOException;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.Stack;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.commons.lang.time.DateUtils;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SymbolParser extends DefaultHandler {

	private Stack<Symbol> symbolStack;
	private Stack<Member> memberStack;
	private ISymbolProcessor symbolProcessor;

	public SymbolParser(InputSource inputSource,
			ISymbolProcessor symbolProcessor)
			throws ParserConfigurationException, SAXException, IOException {
		this.symbolProcessor = symbolProcessor;
		SAXParserFactory factory = SAXParserFactory.newInstance();
		SAXParser parser = factory.newSAXParser();
		parser.parse(inputSource, this);
	}

	@Override
	public void startDocument() throws SAXException {
		symbolStack = new Stack<Symbol>();
		memberStack = new Stack<Member>();
	}

	@Override
	public void startElement(String namespaceURI, String localName,
			String qualifiedName, Attributes attributes) throws SAXException {
		if (qualifiedName.equals("pagegroup")) {
			Symbol symbol = new Symbol();
			symbol.setName(attributes.getValue("name"));
			symbolStack.push(symbol);
		}
		if (qualifiedName.equals("data")) {
			Member member = new Member();
			memberStack.push(member);
		}
		if (qualifiedName.equals("member")) {
			memberStack.peek().setValues(attributes.getValue("page"),
					attributes.getValue("axis"), attributes.getValue("name"),
					attributes.getValue("value"));
		}
	}

	@Override
	public void endElement(String namespaceURI, String simpleName,
			String qualifiedName) throws SAXException {
		if (qualifiedName.equals("pagegroup")) {
			symbolProcessor.processSymbol(symbolStack.pop());
		}
		if (qualifiedName.equals("data")) {
			Member member = memberStack.pop();
			Fact fact = new Fact();
			fact.setKey(member.key);
			fact.setValue(member.value);
			if (member.category != null && member.date != null) {
				SymbolHelper.addFact(symbolStack.peek(), member.category,
						member.date, fact);
			}
		}
	}

}

class Member {

	String category;
	Date date;
	String key;
	String value;

	public void setValues(String page, String axis, String name, String value) {
		this.category = page;
		if (axis.equals("fact")) {
			this.value = value;
		}
		if (axis.equals("row")) {
			this.key = value;
		}
		if (axis.equals("col")) {
			try {
				this.date = getDate(value);
			} catch (ParseException e) {
				System.out.println("Col value " + value);
				e.printStackTrace();
			}
		}
	}

	private static Date getDate(String value) throws ParseException {
		if (value == null) {
			return null;
		}
		if (value.matches("[A-Za-z]{3} '[0-9]{2}")) {
			Date date = DateUtils.parseDate(value, new String[] { "MMM ''yy" });
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
			return cal.getTime();
		} else {
			return DateUtils.parseDate(value,
					new String[] { "E MMM dd HH:mm:ss z yyyy" });
		}
	}

	@Override
	public String toString() {
		return "Member [category=" + category + ", date=" + date + ", key="
				+ key + ", value=" + value + "]";
	}

}
