package in.fins.server.service;

import in.fins.server.cache.ICache;
import in.fins.server.processor.ISymbolProcessor;
import in.fins.server.processor.SymbolParser;
import in.fins.server.util.Utils;
import in.fins.shared.Symbol;
import in.fins.shared.SymbolHelper;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.zip.ZipInputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.fileupload.FileItemIterator;
import org.apache.commons.fileupload.FileItemStream;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class UploadService extends HttpServlet implements ISymbolProcessor {

	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(UploadService.class
			.getName());

	private List<Symbol> symbols;

	private int symbolCount;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		byte[] zipBytes = null;
		String fileName = null;
		String action = null;
		String contentType = null;
		String status = null;
		try {
			ServletFileUpload upload = new ServletFileUpload();
			FileItemIterator iter = upload.getItemIterator(req);
			while (iter.hasNext()) {
				FileItemStream item = iter.next();
				if (item.isFormField()) {
					if (item.getFieldName().equals("action")) {
						action = IOUtils.toString(item.openStream());
					}
				} else {
					contentType = item.getContentType();
					zipBytes = IOUtils.toByteArray(item.openStream());
					fileName = item.getName();
				}
			}
			if (action.equals("uploadAndParse")) {
				status = uploadAndParse(zipBytes, fileName, contentType);
			}
			if (action.equals("clearList")) {
				status = clearSymbols();
			}
			if (action.equals("cacheSymbols")) {
				status = cacheSymbols();
			}
			if (action.equals("clearCache")) {
				status = clearCache();
			}
		} catch (Exception e) {
			status = e.getMessage();
			log.warning(status);
		}
		resp.getWriter().write(status);
	}

	private String clearSymbols() {
		if (symbols != null) {
			symbols.clear();
		}
		return "Symbol List cleared";
	}

	private String uploadAndParse(byte[] zipBytes, String fileName,
			String contentType) throws IOException, Exception {
		if (symbols == null) {
			symbols = new ArrayList<Symbol>();
		}
		String status = null;
		if (StringUtils.isBlank(fileName)) {
			return "Select zip file to upload";
		}
		if (contentType.equals("application/zip")) {
			status = "Uploaded " + fileName + ". ";
			status += processZipFile(zipBytes);
		} else {
			status = "invalid file format";
		}
		return status;
	}

	private String cacheSymbols() throws Exception {
		if (symbols == null || symbols.size() == 0) {
			return "No symbols held. Upload file first";
		}
		String serverName = getServerName();
		ICache cache = null;
		if (serverName.equals("GAE")) {
			cache = Utils.createInstance(ICache.class,
					"in.fins.server.cache.GaeCache");
		} else {
			cache = Utils.createInstance(ICache.class,
					"in.fins.server.cache.SimpleCache");
		}
		cache.createCache();
		List<String> symbolNames = new ArrayList<String>();
		for (Symbol symbol : symbols) {
			cache.put(symbol.getName(), symbol);
			symbolNames.add(symbol.getName());
		}
		cache.put("symbolNames", symbolNames);
		int cacheCount = 0;
		// check cache consistency
		for (String name : symbolNames) {
			Object o = cache.get(name);
			if (o instanceof Symbol) {
				cacheCount++;
			}
		}
		String status = "Symbols held " + symbols.size() + " . Cached "
				+ cacheCount + " symbols ";
		if (cacheCount != symbolNames.size()) {
			status += ". Try Cache Symbols option again to rectify the inconsistency.";
		}
		return status;
	}

	private String clearCache() {
		String serverName = getServerName();
		String status = null;
		try {
			ICache cache = null;
			if (serverName.equals("GAE")) {
				cache = Utils.createInstance(ICache.class,
						"in.fins.server.cache.GaeCache");
			} else {
				cache = Utils.createInstance(ICache.class,
						"in.fins.server.cache.SimpleCache");
			}
			cache.createCache();
			cache.clear();
			status = "Cache cleared";
		} catch (Exception e) {
			status = e.getMessage();
		}
		return status;
	}

	private String processZipFile(byte[] zipBytes) throws Exception {
		ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(
				zipBytes));
		int entryCount = 0;
		try {
			while (zis.getNextEntry() != null) {
				byte[] xmlBytes = IOUtils.toByteArray(zis);
				InputSource xmlSource = new InputSource(
						new ByteArrayInputStream(xmlBytes));
				parseSymbols(xmlSource);
				zis.closeEntry();
				entryCount++;
			}
		} catch (IOException e) {
			throw e;
		}
		zis.close();
		return "Processed " + entryCount + " zip entries and created "
				+ symbols.size() + " Symbols ";
	}

	private void parseSymbols(InputSource xmlSource) throws Exception {
		try {
			symbolCount = 0;
			new SymbolParser(xmlSource, this);
			if (symbolCount == 0) {
				throw new Exception("Unable to find any Symbol in XML");
			}
		} catch (ParserConfigurationException e) {
			throw e;
		} catch (SAXException e) {
			throw new Exception(
					"Zip file has invalid contents [Exception throw by Parser : "
							+ e.getMessage() + "]");
		} catch (Exception e) {
			throw e;
		}
	}

	@Override
	public void processSymbol(Symbol symbol) {
		symbolCount++;
		mergeSymbol(symbol);
	}

	private void mergeSymbol(Symbol symbol) {
		boolean addFlg = true;
		for (Symbol dstSymbol : symbols) {
			if (symbol.getName().equals(dstSymbol.getName())) {
				SymbolHelper.updateSymbol(symbol, dstSymbol);
				addFlg = false;
			}
		}
		if (addFlg) {
			symbols.add(symbol);
		}
	}

	private String getServerName() {
		String serverName = getServletContext().getServerInfo();
		if (serverName.startsWith("Google App Engine")) {
			return "GAE";
		} else {
			return serverName;
		}
	}

}
