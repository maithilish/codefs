package in.fins.client.widget;

import in.fins.client.event.EventBus;
import in.fins.client.event.NameEvent;
import in.fins.client.rpc.ISymbolService;
import in.fins.client.rpc.ISymbolServiceAsync;

import java.util.List;
import java.util.logging.Logger;

import com.google.gwt.core.client.GWT;
import com.google.gwt.core.client.Scheduler;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.MultiWordSuggestOracle;
import com.google.gwt.user.client.ui.ResizeComposite;
import com.google.gwt.user.client.ui.SuggestBox;
import com.google.gwt.user.client.ui.SuggestOracle;
import com.google.gwt.user.client.ui.Widget;

public class AutoSuggest extends ResizeComposite {

	private static final Logger log = Logger.getLogger(AutoSuggest.class
			.getName());

	interface AutoSuggestBinder extends UiBinder<Widget, AutoSuggest> {
	}

	private static UiBinder<Widget, AutoSuggest> binder = GWT
			.create(AutoSuggestBinder.class);

	@UiField
	SuggestBox suggestBox;

	private Object eventSource;

	public AutoSuggest() {
		initWidget(binder.createAndBindUi(this));
		setSymbolNames();
	}

	@UiHandler("suggestBox")
	public void handleSelection(SelectionEvent<SuggestOracle.Suggestion> s) {
		log.fine("Selection : " + suggestBox.getText());
		EventBus.get().fireEventFromSource(new NameEvent(suggestBox.getText()),
				eventSource);
		suggestBox.setText("");
	}

	public void setEventSource(Object eventSource) {
		this.eventSource = eventSource;
	}

	private void setSymbolNames() {
		ISymbolServiceAsync symbolService = GWT.create(ISymbolService.class);

		symbolService.getSymbolNames(new AsyncCallback<List<String>>() {
			@Override
			public void onSuccess(List<String> list) {
				((MultiWordSuggestOracle) suggestBox.getSuggestOracle())
						.addAll(list);
				log.fine("Received symbol names via RPC and set to oracle");
			}

			@Override
			public void onFailure(Throwable caught) {
				log.warning(caught.getMessage());
			}
		});
	}

	public void requestFocus() {
		Scheduler.get().scheduleDeferred(new Scheduler.ScheduledCommand() {
			public void execute() {
				suggestBox.setFocus(true);
			}
		});
	}
}