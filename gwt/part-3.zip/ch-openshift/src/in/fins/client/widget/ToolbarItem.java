package in.fins.client.widget;

import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.user.client.ui.Image;

public class ToolbarItem extends Image {

	Object eventSource;

	public ToolbarItem(ImageResource imageResource) {
		super(imageResource);
		setStylePrimaryName("fins-Toolbar-Image");
	}

	public void setEventSource(Object eventSource) {
		this.eventSource = eventSource;
	}

	public Object getEventSource() {
		return eventSource;
	}
}
