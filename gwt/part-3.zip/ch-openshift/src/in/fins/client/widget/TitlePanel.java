package in.fins.client.widget;

import in.fins.client.event.NameEvent;
import in.fins.client.event.NameEvent.NameHandler;

import java.util.logging.Logger;

import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.Widget;

public class TitlePanel extends Composite implements NameHandler {

	private static final Logger log = Logger.getLogger(TitlePanel.class
			.getName());

	interface SimpleLabelBinder extends UiBinder<Widget, TitlePanel> {
	}

	private static UiBinder<Widget, TitlePanel> binder = GWT
			.create(SimpleLabelBinder.class);

	@UiField
	Label label;

	public TitlePanel() {
		initWidget(binder.createAndBindUi(this));
	}

	@Override
	public void onNameChange(NameEvent nameEvent) {
		log.fine("NameEvent " + nameEvent.getName());
		label.setText(nameEvent.getName());
	}
}
