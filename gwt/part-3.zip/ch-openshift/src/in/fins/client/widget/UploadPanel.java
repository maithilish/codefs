package in.fins.client.widget;

import in.fins.client.event.EventBus;
import in.fins.client.event.StatusEvent;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.FormPanel;
import com.google.gwt.user.client.ui.FormPanel.SubmitCompleteEvent;
import com.google.gwt.user.client.ui.Widget;

public class UploadPanel extends Composite {

	private static UploaderUiBinder uiBinder = GWT
			.create(UploaderUiBinder.class);

	interface UploaderUiBinder extends UiBinder<Widget, UploadPanel> {
	}

	@UiField
	FormPanel uploadForm;

	@UiField
	FormPanel clearListForm;

	public UploadPanel() {

		initWidget(uiBinder.createAndBindUi(this));

		uploadForm.setMethod(FormPanel.METHOD_POST);
		uploadForm.setEncoding(FormPanel.ENCODING_MULTIPART);

		clearListForm.setMethod(FormPanel.METHOD_POST);
		clearListForm.setEncoding(FormPanel.ENCODING_MULTIPART);
	}

	@UiHandler("uploadButton")
	void onUploadClick(ClickEvent event) {
		uploadForm.submit();
	}

	@UiHandler("uploadForm")
	void onUploadFormSubmitComplete(SubmitCompleteEvent event) {
		StatusEvent se = new StatusEvent(event.getResults());
		EventBus.get().fireEvent(se);
	}

	@UiHandler("clearListButton")
	void onClearListClick(ClickEvent event) {
		clearListForm.submit();
	}

	@UiHandler("clearListForm")
	void onClearListFormSubmitComplete(SubmitCompleteEvent event) {
		StatusEvent se = new StatusEvent(event.getResults());
		EventBus.get().fireEvent(se);
	}

}
