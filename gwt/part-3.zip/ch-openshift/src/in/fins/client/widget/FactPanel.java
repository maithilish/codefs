package in.fins.client.widget;

import in.fins.client.event.SymbolEvent;
import in.fins.client.event.SymbolEvent.SymbolHandler;
import in.fins.shared.Fact;
import in.fins.shared.Symbol;
import in.fins.shared.SymbolHelper;

import java.util.Date;
import java.util.List;

import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Widget;

public class FactPanel extends HorizontalPanel implements SymbolHandler {

	public FactPanel() {
		setStyleName("fins-KeyValuePanel");
		setVisible(false);
	}

	@Override
	public void onSymbolChange(SymbolEvent event) {
		setVisible(true);
		Symbol symbol = event.getSymbol();
		for (int c = 0; c < getWidgetCount(); c++) {
			Widget widget = getWidget(c);
			if (widget instanceof FactItem) {
				FactItem item = (FactItem) widget;
				Date date = SymbolHelper.getPositionDate(symbol,
						item.getCategory());
				List<Fact> facts = SymbolHelper.getFacts(symbol,
						item.getCategory(), date);
				item.setValue(getValue(facts, item.getMatchs()));
			}
		}
	}

	private static String getValue(List<Fact> factList, String... matchs) {
		if (matchs.length == 1) {
			String match = matchs[0];
			for (Fact fact : factList) {
				if (match.equals(fact.getKey())) {
					return fact.getValue();
				}
			}
			return null;
		} else {
			String delimit = "";
			String value = new String();
			for (String match : matchs) {
				for (Fact fact : factList) {
					if (match.equals(fact.getKey())) {
						value += delimit + fact.getValue();
						delimit = " / ";
					}
				}
			}
			return value;
		}
	}
}
