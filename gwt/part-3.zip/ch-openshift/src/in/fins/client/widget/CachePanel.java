package in.fins.client.widget;

import in.fins.client.event.EventBus;
import in.fins.client.event.StatusEvent;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.FormPanel;
import com.google.gwt.user.client.ui.FormPanel.SubmitCompleteEvent;
import com.google.gwt.user.client.ui.Widget;

public class CachePanel extends Composite {

	interface CachePanelBinder extends UiBinder<Widget, CachePanel> {
	}

	private static UiBinder<Widget, CachePanel> binder = GWT
			.create(CachePanelBinder.class);

	@UiField
	FormPanel cacheSymbolsForm;

	@UiField
	FormPanel clearForm;

	public CachePanel() {

		initWidget(binder.createAndBindUi(this));

		cacheSymbolsForm.setMethod(FormPanel.METHOD_POST);
		cacheSymbolsForm.setEncoding(FormPanel.ENCODING_MULTIPART);

		clearForm.setMethod(FormPanel.METHOD_POST);
		clearForm.setEncoding(FormPanel.ENCODING_MULTIPART);
	}

	@UiHandler("cacheSymbolsButton")
	void onCacheSymbolsClick(ClickEvent event) {
		cacheSymbolsForm.submit();
	}

	@UiHandler("clearButton")
	void onClearClick(ClickEvent event) {
		clearForm.submit();
	}

	@UiHandler("cacheSymbolsForm")
	void onCacheSymbolsFormSubmitComplete(SubmitCompleteEvent event) {
		StatusEvent se = new StatusEvent(event.getResults());
		EventBus.get().fireEvent(se);
	}

	@UiHandler("clearForm")
	void onClearFormSubmitComplete(SubmitCompleteEvent event) {
		StatusEvent se = new StatusEvent(event.getResults());
		EventBus.get().fireEvent(se);
	}
}
