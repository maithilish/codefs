package in.fins.client.widget;

import in.fins.client.event.DataGroupEvent;
import in.fins.client.event.DataGroupEvent.DataGroupHandler;
import in.fins.shared.DataGroup;
import in.fins.shared.Fact;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import com.google.gwt.cell.client.TextCell;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.user.cellview.client.Column;
import com.google.gwt.user.cellview.client.DataGrid;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HasHorizontalAlignment.HorizontalAlignmentConstant;
import com.google.gwt.user.client.ui.PopupPanel;
import com.google.gwt.user.client.ui.ResizeComposite;
import com.google.gwt.user.client.ui.Widget;

public class FactGrid extends ResizeComposite implements DataGroupHandler {

	private static final Logger log = Logger
			.getLogger(FactGrid.class.getName());

	private DataGrid<List<Fact>> dataGrid;

	public FactGrid() {
		dataGrid = new DataGrid<List<Fact>>();
		initWidget(dataGrid);
	}

	public void addColumn(String label, HorizontalAlignmentConstant align,
			boolean sortable, boolean roundoff) {
		IndexedColumn indexedColumn = new IndexedColumn(
				dataGrid.getColumnCount(), align, sortable, roundoff);
		dataGrid.addColumn(indexedColumn, label);
	}

	public List<List<Fact>> transpose(List<List<Fact>> factsList) {
		if (factsList.size() == 0) {
			return factsList;
		}

		List<List<Fact>> tList = new ArrayList<List<Fact>>();
		for (int i = 0; i < factsList.get(0).size(); i++) {
			List<Fact> tFacts = new ArrayList<Fact>();
			for (List<Fact> facts : factsList) {
				// facts at index are added to new list
				tFacts.add(facts.get(i));
			}
			tList.add(tFacts);
		}
		return tList;
	}

	public void setData(List<List<Fact>> factsList) {
		// fact at index 0 is duplicated
		// used as label for each row
		for (List<Fact> facts : factsList) {
			Fact labelFact = new Fact();
			labelFact.setKey("Label");
			labelFact.setValue(facts.get(0).getKey()); // key is used as label
			facts.add(0, labelFact);
		}
		dataGrid.setRowCount(factsList.size(), true);
		dataGrid.setRowData(0, factsList);
		dataGrid.clearTableWidth();
		dataGrid.redraw();
	}

	@Override
	public void onDataGroupChange(DataGroupEvent dataGroupEvent) {

		DataGroup dataGroup = dataGroupEvent.getDataGroup();
		log.fine("DataGroupEvent recd " + dataGroup);

		// reset factGrid
		int c = dataGrid.getColumnCount();
		while (--c >= 0) {
			dataGrid.removeColumn(c);
		}

		// first column to display the label
		addColumn("Item", HasHorizontalAlignment.ALIGN_LEFT, true, false);
		Column<List<Fact>, ?> ic = dataGrid.getColumn(0);
		ic.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_LEFT);
		ic.setCellStyleNames("gwt-Datagrid-Cell-Watchlist");
		dataGrid.setColumnWidth(ic, "150px");

		// add other columns for each date and
		// add facts to List<List<Fact>>

		List<List<Fact>> factsList = new ArrayList<List<Fact>>();

		DateTimeFormat fmt = DateTimeFormat.getFormat("MMM yy");
		List<Date> dates = dataGroup.getDateList();
		for (int i = dates.size() - 1; i >= 0; i--) {
			Date date = dates.get(i);
			addColumn(fmt.format(date), HasHorizontalAlignment.ALIGN_RIGHT,
					true, true);
			// add facts for the date to List<List<Fact>>
			factsList.add(dataGroup.getData(date).getFacts());
		}

		// transpose and set data to dataGrid
		List<List<Fact>> tList = transpose(factsList);
		setData(tList);

		// set minimumTableWidth
		int rows = dataGrid.getRowCount();
		int cols = dataGrid.getColumnCount();
		dataGrid.setMinimumTableWidth(cols * 80, Unit.PX);
		if (rows < 7) {
			rows = 7;
		}
		if (cols > 7) {
			cols = 7;
		}

		// set width and height of parent panel
		String width = cols * 80 + "px";
		String height = rows * 35 + "px";
		Widget parent = getParent();
		parent.setSize(width, height);

		// if parent is popup show and center
		if (parent instanceof PopupPanel) {
			((PopupPanel) parent).center();
		}
	}
}

class IndexedColumn extends Column<List<Fact>, String> {
	private int index;
	private boolean roundoff;

	public IndexedColumn(int index, HorizontalAlignmentConstant align,
			boolean sortable, boolean roundoff) {
		super(new TextCell());
		this.index = index;
		setHorizontalAlignment(align);
		this.roundoff = roundoff;
		setSortable(sortable);
	}

	@Override
	public String getValue(List<Fact> facts) {
		if (roundoff) {
			return facts.get(index).getRoundoff();
		}
		return facts.get(index).getValue();
	}
}
