package in.fins.client.widget;

import in.fins.client.event.EventBus;
import in.fins.client.event.StatusEvent;
import in.fins.client.rpc.ISymbolService;
import in.fins.client.rpc.ISymbolServiceAsync;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.Widget;

public class DataStorePanel extends Composite {

	private static DataStorePanelUiBinder uiBinder = GWT
			.create(DataStorePanelUiBinder.class);

	interface DataStorePanelUiBinder extends UiBinder<Widget, DataStorePanel> {
	}

	public DataStorePanel() {
		initWidget(uiBinder.createAndBindUi(this));
	}

	public DataStorePanel(String firstName) {
		initWidget(uiBinder.createAndBindUi(this));
	}

	@UiHandler("persistButton")
	void onInsertButtonClick(ClickEvent event) {
		ISymbolServiceAsync dataStoreService = GWT.create(ISymbolService.class);
		dataStoreService.persistSymbols("insert-queue",
				new AsyncCallback<String>() {

					@Override
					public void onSuccess(String result) {
						StatusEvent se = new StatusEvent(result);
						EventBus.get().fireEvent(se);
					}

					@Override
					public void onFailure(Throwable caught) {
						StatusEvent se = new StatusEvent(caught.getMessage());
						EventBus.get().fireEvent(se);
					}
				});
	}

}
