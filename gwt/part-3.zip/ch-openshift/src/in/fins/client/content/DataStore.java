package in.fins.client.content;

import com.google.gwt.core.client.GWT;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.Widget;

public class DataStore extends Composite {

	private static DataStoreUiBinder uiBinder = GWT
			.create(DataStoreUiBinder.class);

	interface DataStoreUiBinder extends UiBinder<Widget, DataStore> {
	}

	public DataStore() {
		initWidget(uiBinder.createAndBindUi(this));
	}

}
